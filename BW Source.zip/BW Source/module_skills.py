from header_common import *
from header_skills import *

from compiler import *
####################################################################################################################
#  Each skill contains the following fields:
#  1) Skill id (string): used for referencing skills in other files. The prefix skl_ is automatically added before each skill-id .
#  2) Skill name (string).
#  3) Skill flags (int). See header_skills.py for a list of available flags
#  4) Maximum level of the skill (int).
#  5) Skill description (string): used in character window for explaining the skills.
# 
####################################################################################################################

#Hardcoded skills are {names (indexes, beginning with 0)}:
# Trade (1)
# Leadership (2)
# Prisoner Management (3)
# First Aid (9)
# Surgery (10)
# Wound Treatment (11)
# Inventory Management (12)
# Spotting (13)
# Pathfinding (14)
# Tactics (15)
# Tracking (16)
# Trainer (17)
# Engineer (18)
# Horse Archery (24)
# Riding (25)
# Athletics (26)
# Shield (27)
# Weapon Master (28)
# Power Draw (34)
# Power Throw (35)
# Power Strike (36)
# Ironflesh (37)
#
# The effects of these skills can only be removed if the skill is disabled with sf_inactive flag.
# If you want to add a new skill, use the reserved skills or use non-hardcoded skills.
    
skills = [
("trade","Trade",sf_base_att_cha|sf_effects_party,10,"Every level of this skill reduces your trade penalty by 5%%. Let you invest in your own caravans and affects prisoner prices. (Party skill)"),
("leadership","Leadership",sf_base_att_cha,10,"Every point increases maximum number of troops you can command by 5, increases your party morale and reduces troop wages by 5%%. (Leader skill)"),
("prisoner_management", "Prisoner Management",sf_base_att_cha,10,"Every level increases maximum number of prisoners by %d, reduces the flee chances of prisoners and affects prisoner prices. (Leader skill)"), 

("reserved_1","Reserved Skill 2",sf_base_att_cha|sf_inactive,10,"This is a reserved skill."),     
("reserved_2","Reserved Skill 2",sf_base_att_cha|sf_inactive,10,"This is a reserved skill."),   
("reserved_3","Reserved Skill 3",sf_base_att_cha|sf_inactive,10,"This is a reserved skill."), 
("reserved_4","Reserved Skill 4",sf_base_att_cha|sf_inactive,10,"This is a reserved skill."), 
  
("persuasion","Persuasion", sf_base_att_cha,10,
"This skill helps you make other people accept your point of view, lowers the minimum level of relationship needed to get NPCs to do what you want and affects prisoner prices. (Personal skill)"),
("engineer","Mechanics",sf_base_att_int|sf_effects_party,10,"This skill allows you to repair, maintain, modify and build equipment and devices using the resources available. Adequate maintenance of your equipment will lower the chance of it breaking in battle. Each point of this skill reduces the probability of breaking by 7%%. Technician will also allow you to construct siege equipment and fief improvements more efficiently. (Party skill)"), #more damage high tech weapons / craft?
("first_aid", "First Aid",sf_base_att_int|sf_effects_party,10,"Heroes regain 5%% per skill level of hit-points lost during mission. (Party skill)"), 
("surgery","Surgery",sf_base_att_int|sf_effects_party,10,"Each point to this skill gives a 4%% chance that a mortally struck party member will be wounded rather than killed. (Party skill)"), 
("wound_treatment","Wound Treatment",sf_base_att_int|sf_effects_party,10,"Party healing speed is increased by 20%% per level of this skill. (Party skill)"), 
("inventory_management","Inventory Management",sf_base_att_int,10,"Increases inventory capacity by +6 per skill level. (Leader skill)"), 
("spotting","Spotting",sf_base_att_int|sf_effects_party,10,"Party seeing range is increased by 10%% per skill level. (Party skill)"),
("pathfinding","Navigation",sf_base_att_int|sf_effects_party,10,"Party map speed is increased by 3%% per skill level. (Party skill)"), 
("tactics","Tactics",sf_base_att_int|sf_effects_party,10,"Every two levels of this skill increases starting battle advantage by 1. (Party skill)"),
("tracking","Survival",sf_base_att_int|sf_effects_party,10,"Every level of Survival helps you and your party survive in this harsh environment and your Tracks become more informative. (Party skill)"), #survival food bonus
("trainer","Trainer",sf_base_att_int,10,"Every day, each hero with this skill adds some experience to every other member of the party whose level is lower than his/hers. Experience gained goes as: {0,4,10,16,23,30,38,46,55,65,80}. (Personal skill)"),

("reserved_5","Reserved Skill 5",sf_base_att_int|sf_inactive,10,"This is a reserved skill."), 
("reserved_6","Reserved Skill 6",sf_base_att_int|sf_inactive,10,"This is a reserved skill."), 
("reserved_7","Reserved Skill 7",sf_base_att_int|sf_inactive,10,"This is a reserved skill."), 
("reserved_8","Reserved Skill 8",sf_base_att_int|sf_inactive,10,"This is a reserved skill."), 

("looting","Looting",sf_base_att_agi|sf_effects_party,10,"This skill increases the amount of loot obtained. (Party skill)"), 

("horse_archery","Skirmisher",sf_base_att_agi|sf_inactive,10,"Reduces damage and accuracy penalties for archery and throwing from horseback. (Personal skill)"),

("riding","Riding",sf_base_att_agi,5,"Enables you to ride animals of higher difficulty levels and increases your riding speed and manuever. Max level is 5 (Personal skill)"), #/critical strike  mount damage

("athletics","Athletics",sf_base_att_agi,10,"Improves your running speed and increases your stamina. Helps you survive in this harsh environment. (Personal skill)"),
("shield","Prowess",sf_base_att_agi,10,"Each Prowess level increases the chance to land a critical hit by 1%% in melee. Reduces damage to shields (by 8%% per level) and improves shield speed and coverage. Also increases unarmed damage. (Personal skill)"),#damage resis   /more damage
("weapon_master","Weapon Master",sf_base_att_agi,10,"Makes it easier to learn weapon proficiencies and increases the proficiency limits. Limits go as: 60, 100, 140, 180, 220, 260, 300, 340, 380, 420. (Personal skill)"),
("reserved_9","Crafter",sf_base_att_int,10,"Crafter allows you to craft basic melee weapons (unfinished feature), improve guns and repair different things. Adequate maintenance of your equipment will lower the chance of it breaking in battle. Each point of this skill reduces the probability of breaking by 7%%. Each level increases damage with crafted weapons by 5%%. Max level is 10. (Personal skill)"), 

("reserved_10","Reserved Skill 10",sf_base_att_agi|sf_inactive,10,"This is a reserved skill."), 
("reserved_11","Reserved Skill 11",sf_base_att_agi|sf_inactive,10,"This is a reserved skill."), 
("reserved_12","Reserved Skill 12",sf_base_att_agi|sf_inactive,10,"This is a reserved skill."), 
("reserved_13","Reserved Skill 13",sf_base_att_agi|sf_inactive,10,"This is a reserved skill."), 
("power_draw","Power Draw",sf_base_att_str|sf_inactive,10,"Lets character use more powerful bows. Each point to this skill (up to four plus power-draw requirement of the bow) increases bow damage by 14%%. (Personal skill)"),
("power_throw","Power Throw",sf_base_att_str|sf_inactive,10,"Each point to this skill increases throwing damage by 10%%. (Personal skill)"),

("power_strike","Power Strike",sf_base_att_str,10,"Each point to this skill increases melee damage by 8%% and increases unarmed damage. (Personal skill)"),
("ironflesh","Ironflesh",sf_base_att_str,10,"Each point to this skill increases hit points by +2 and increases unarmed damage. (Personal skill)"), 
("reserved_14","Scavenger",sf_base_att_int|sf_effects_party,10,"The Scavenger skill allows the player to find useful items in the environment, including weapons, ammunition, and medical supplies. High skill level increases the chances of finding rare and valuable items, and allows for more efficient searching and spotting of hidden items. (Party skill)"), 
("reserved_15","Luck",sf_base_att_cha,10,"Luck affects your chances of success in various aspects. It can give an edge in finding valuable items, surviving dangerous situations and completing tasks. Helps to decide your fate. (Personal skill)"), 

("reserved_16","Reserved Skill 16",sf_base_att_str|sf_inactive,10,"This is a reserved skill."), 
("reserved_17","Reserved Skill 17",sf_base_att_str|sf_inactive,10,"This is a reserved skill."), 
("reserved_18","Reserved Skill 18",sf_base_att_str|sf_inactive,10,"This is a reserved skill."), 
]# modmerger_start version=201 type=2
try:
    component_name = "skills"
    var_set = { "skills" : skills }
    from modmerger import modmerge
    modmerge(var_set)
except:
    raise
# modmerger_end
