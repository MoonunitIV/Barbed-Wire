from header_common import *
from header_operations import *
from header_parties import *
from header_items import *
from header_skills import *
from header_triggers import *
from header_troops import *
from header_music import *
##diplomacy start+
from header_terrain_types import *
from module_factions import dplmc_factions_end
# from ID_info_pages import ip_morale
##diplomacy end+

from module_constants import *
from ID_skyboxes import *

from compiler import *
####################################################################################################################
# Simple triggers are the alternative to old style triggers. They do not preserve state, and thus simpler to maintain.
#
#  Each simple trigger contains the following fields:
# 1) Check interval: How frequently this trigger will be checked
# 2) Operation block: This must be a valid operation block. See header_operations.py for reference.
####################################################################################################################

simple_triggers = [
# This trigger is deprecated. Use "script_game_event_party_encounter" in module_scripts.py instead
  # (ti_on_party_encounter,[]),
# This trigger is deprecated. Use "script_game_event_simulate_battle" in module_scripts.py instead
  # (ti_simulate_battle,[]),

(ti_on_switch_to_map,[
  (try_begin),
    (eq,"$g_first_time",1),
    (music_set_situation, 0),
    (assign,"$g_first_time",0),
  (try_end),

  (stop_sound_channel, "$heartbeat"),
  # (stop_sound_channel, "$snd_channel"),
  (stop_all_sounds, 0),

  (party_get_current_terrain, ":terrain_type", "p_main_party"),
  (call_script, "script_warzone_ambience_sound",":terrain_type"),

  (assign, "$g_covers_active",0),
  (assign, "$g_player", -1),
  (assign, "$g_player_team", -1),
  (assign, "$g_player_x_agent_no", -1),
  (assign,"$g_rad_zone",0),
  # (assign,"$g_sandstorm",0),

  (try_begin),
    (eq,"$has_traded",1),

    (troop_clear_inventory, "trp_caravan_master"),

    (try_for_range, ":item_slot", ek_item_0, ek_head),
        (troop_get_inventory_slot, ":item_no", "trp_temp_troop", ":item_slot"),
        (gt, ":item_no", 0),
        (troop_add_item, "trp_caravan_master", ":item_no"),
    (try_end),
    (troop_get_inventory_capacity, ":inv_size", "trp_temp_troop"),
    (try_for_range, ":i_slot", 0, ":inv_size"),
        (troop_get_inventory_slot, ":item", "trp_temp_troop", ":i_slot"),
        (ge, ":item", 0),
        (troop_add_item, "trp_caravan_master", ":item"),
    (try_end),
    (troop_equip_items, "trp_caravan_master"),

    (store_troop_gold, ":gold", "trp_caravan_master"),
    (troop_remove_gold,"trp_caravan_master", ":gold"),

    (assign,"$has_traded",2),
  (try_end),

  (try_begin),
    (eq,"$g_player_scavenging",-1),
    (assign, "$g_player_scavenging", 0),
  (try_end),

  (set_fixed_point_multiplier, 1),
  (set_shader_param_float, "@vEnvironment", "$shader_env"),
  (set_shader_param_float, "@vMapCon", "$shader_map"),
  # (set_shader_param_int, "@bNightVision", 0),
  (set_fixed_point_multiplier, 100),

  (try_begin),	#krag robbery add this section
		(ge, "$robbery_loot", 1),
		(assign, ":robbery_renown", "$robbery_loot"),
		(val_div, ":robbery_renown",200),
		(call_script, "script_change_troop_renown", "trp_player", ":robbery_renown"),
		(party_get_slot,  ":number_of_robberies", "$current_town", slot_party_robbed_by_player),
		(val_add, ":number_of_robberies", 1),
		(party_set_slot, "$current_town", slot_party_robbed_by_player, ":number_of_robberies"),

		(str_store_party_name, s18,  "$current_town"),
		(assign, reg18, ":number_of_robberies"),

		(val_add, "$total_robberies", 1),
		(assign, reg19, "$total_robberies"),

		(assign, ":towns_robbed", 0),
		(assign, ":total_towns", 0),
		(try_for_range, ":town", towns_begin, towns_end),
			(val_add, ":total_towns", 1),
			(party_get_slot,  ":has_robbed", ":town", slot_party_robbed_by_player),
			(ge, ":has_robbed", 1),
			(val_add, ":towns_robbed", 1),
		(try_end),
		(assign, reg20, ":towns_robbed"),
		(assign, reg22, ":total_towns"),

		(val_add, "$total_robbery_loot", "$robbery_loot"),
		(assign, reg21, "$total_robbery_loot"),

		(try_begin),
			(gt, "$robbery_loot", "$highest_robbery_loot"),
			(assign, "$highest_robbery_loot", "$robbery_loot"),
		(try_end),
		(assign, reg23, "$highest_robbery_loot"),
		(store_div, reg24, "$total_robbery_loot", "$total_robberies"),

		(display_message, "@You have robbed {s18} {reg18} times, bringing you to {reg19} robberies across {reg20}/{reg22} towns. ^Total stolen is ${reg21}, with a highest take of ${reg23} and an average of ${reg24}.", message_positive),
		(assign, "$robbery_loot", 0), 	#used for guard confiscation when captured, reset it here.
		(try_begin),
			(eq, reg20, reg22),
			(gt, "$total_robbery_loot", 200000),
			(lt, "$total_robbery_loot", 250000),
			(display_message, "@You're the Jesse James of New Acron.",message_positive),
			(call_script, "script_change_troop_renown", "trp_player", 50),
		(try_end),
   (try_end),
   (try_begin),#krag robbery add this section
		(this_or_next|eq, "$talk_context", tc_escape),
		(this_or_next|eq, "$talk_context", tc_prison_break),
		(this_or_next|eq, "$talk_context", tc_hero_freed),
		(gt, "$robbery_in_progress", 0),
		(assign, "$robbery_in_progress", 0),
		(assign,"$has_shop_key",0),
		(assign, "$talk_context", 0),
		(assign, "$loud_robbery_in_progress", 0),
	(try_end),	
   (assign,"$has_castle_key",0),
   (try_begin),	#krag robbery add this section
		(ge, "$has_prison_key", 1),
		(try_for_range, ":prisoner", active_npcs_begin, kingdom_ladies_end),
			(troop_set_slot, ":prisoner", slot_troop_will_join_prison_break, 0),
		(try_end),
		(assign,"$has_prison_key",0),
   (try_end),
   
	#(call_script, "script_init_firearms", 0),# enable to test new ironsights
  ]),


(0,    # Updating in every frame
   [
     (try_begin),
      (eq,"$g_player_is_captive",1),
      (gt, "$capturer_party", 0),
      (party_is_active, "$capturer_party"),
      (party_relocate_near_party, "p_main_party", "$capturer_party", 0),
     (try_end),

    (str_store_string_reg, s90, s1), # make back up of s1 as it gets overwritten by game_get_date_text

    #Auto-menu
     (try_begin),
       (is_between, "$g_last_rest_center",  centers_begin, centers_end), #SB : proper rest conditions
       (party_get_battle_opponent, ":besieger_party", "$g_last_rest_center"),
       (gt, ":besieger_party", 0),
       (store_faction_of_party, ":encountered_faction", "$g_last_rest_center"),
       (store_relation, ":faction_relation", ":encountered_faction", "fac_player_supporters_faction"),
       (store_faction_of_party, ":besieger_party_faction", ":besieger_party"),
       (store_relation, ":besieger_party_relation", ":besieger_party_faction", "fac_player_supporters_faction"),
       (ge, ":faction_relation", 0),
       (lt, ":besieger_party_relation", 0),
       (start_encounter, "$g_last_rest_center"),
       (rest_for_hours, 0, 0, 0), #stop resting
     (else_try),
       (store_current_hours, ":cur_hours"),
       (assign, ":check", 0),
       (try_begin),
         (neq, "$g_check_autos_at_hour", 0),
         (ge, ":cur_hours", "$g_check_autos_at_hour"),
         (assign, ":check", 1),
         (assign, "$g_check_autos_at_hour", 0),
       (try_end),
       (this_or_next|eq, ":check", 1),
       (map_free),
       (try_begin),
         (ge,"$auto_menu",1),
         (jump_to_menu,"$auto_menu"),
         (assign,"$auto_menu",-1),
       (else_try),
         (ge,"$auto_enter_town",1),
         (start_encounter, "$auto_enter_town"),
       (else_try),
         (ge,"$auto_besiege_town",1),
         (start_encounter, "$auto_besiege_town"),
       (else_try),
         (ge,"$g_camp_mode", 1),
         (assign, "$g_camp_mode", 0),
         (assign, "$g_infinite_camping", 0),
         (assign, "$g_player_icon_state", pis_normal),

         (rest_for_hours, 0, 0, 0), #stop camping

         (display_message, "@Breaking camp...", message_alert), #SB : colorize
       (else_try), #SB : restore after leaving town with disguises
         (gt, "$sneaked_into_town", disguise_none),
         (eq, "$g_dplmc_player_disguise", 1),
         (display_message, "@Removing disguise...", message_alert), #SB : colorize
         (try_begin),
           (eq, "$g_dplmc_player_disguise", 1),
           (set_show_messages, 0),
           #equipment is deposited back to inventory, it starts off blank
           (try_for_range, ":i_slot", ek_item_0, ek_food + 1),
             (troop_get_inventory_slot, ":item", "trp_player", ":i_slot"),
             (neq, ":item", -1),
             (troop_get_inventory_slot_modifier, ":imod", "trp_player", ":i_slot"),
             (troop_add_item, "trp_random_town_sequence", ":item", ":imod"),
           (try_end),
           #less efficient, but merge and respect original player inventory's order
           (call_script, "script_move_inventory_and_gold", "trp_player", "trp_random_town_sequence", 0), #do not move gold
           (call_script, "script_dplmc_copy_inventory", "trp_random_town_sequence", "trp_player"),
           (call_script, "script_troop_transfer_gold", "trp_random_town_sequence", "trp_player", 0), #move remaining gold now
           (set_show_messages, 1),
         (try_end),
         (assign, "$sneaked_into_town", disguise_none),
       (try_end),
     (try_end),

    #Notification menus
     (try_begin),
         (troop_slot_ge, "trp_notification_menu_types", 0, 1),
         (troop_get_slot, ":menu_type", "trp_notification_menu_types", 0),
         (troop_get_slot, "$g_notification_menu_var1", "trp_notification_menu_var1", 0),
         (troop_get_slot, "$g_notification_menu_var2", "trp_notification_menu_var2", 0),
         (jump_to_menu, ":menu_type"),
         (assign, ":end_cond", 2),
         (try_for_range, ":cur_slot", 1, ":end_cond"),
           (try_begin),
             (troop_slot_ge, "trp_notification_menu_types", ":cur_slot", 1),
             (val_add, ":end_cond", 1),
           (try_end),
           (store_sub, ":cur_slot_minus_one", ":cur_slot", 1),
           (troop_get_slot, ":local_temp", "trp_notification_menu_types", ":cur_slot"),
           (troop_set_slot, "trp_notification_menu_types", ":cur_slot_minus_one", ":local_temp"),
           (troop_get_slot, ":local_temp", "trp_notification_menu_var1", ":cur_slot"),
           (troop_set_slot, "trp_notification_menu_var1", ":cur_slot_minus_one", ":local_temp"),
           (troop_get_slot, ":local_temp", "trp_notification_menu_var2", ":cur_slot"),
           (troop_set_slot, "trp_notification_menu_var2", ":cur_slot_minus_one", ":local_temp"),
         (try_end),
     (try_end),

    # Decide faction ai flag check
     (try_begin),
       (eq, "$g_recalculate_ais", 1),
       (assign, "$g_recalculate_ais", 0),
       (call_script, "script_recalculate_ais"),
     (try_end),

     (try_begin),
       (set_fixed_point_multiplier, 1000), #Extra Precision
       (mouse_get_position, pos1),
       (position_get_x, ":mouse_x", pos1),
       (position_get_y, ":mouse_y", pos1),
       (set_fixed_point_multiplier, 100),

       (try_begin),
            (le,":mouse_y",40),
            (gt,":mouse_x",803),
            (neg|troop_slot_ge, "trp_player", slot_troop_prisoner_of_party, 0),
            (key_clicked, key_right_mouse_button),

            (try_begin),
              (eq,"$info_sys",0),
              (assign,"$info_sys",1),
            (else_try),
              (eq,"$info_sys",1),
              (assign,"$info_sys",0),
            (try_end),
       (else_try),
           (key_clicked, key_enter),
            (neg|troop_slot_ge, "trp_player", slot_troop_prisoner_of_party, 0),

            (try_begin),
              (eq,"$info_sys",0),
              (assign,"$info_sys",1),
            (else_try),
              (eq,"$info_sys",1),
              (assign,"$info_sys",0),
            (try_end),
       (try_end),
     (try_end),

      (try_begin), #decide vehicle or not
        (assign,":car",-1),
        (assign,":driving",-1),
        (assign,"$car_condition",0),
        (assign,"$car_gasoline",0),
        (troop_get_inventory_capacity, ":inv_size", "trp_player"),
        (try_for_range, ":item_slot", 0, ":inv_size"),
          (eq,":car",-1),
          (troop_get_inventory_slot, ":item_no", "trp_player", ":item_slot"),
          (ge, ":item_no", 0),
          (is_between, ":item_no", vehicles_begin, vehicles_end),
          (troop_get_inventory_slot_modifier, ":imod", "trp_player", ":item_slot"),
          (assign,":car",":item_no"),
          (try_begin),      #  imodbits_car    = imodbit_cracked | imodbit_rusty | imodbit_bent | imodbit_chipped | imodbit_battered | imodbit_poor | imodbit_crude | imodbit_old | imodbit_cheap

            (eq, ":imod", imod_cracked),
            (assign,"$car_condition",-1),
          (else_try),
            (eq, ":imod", imod_rusty),
            (assign,"$car_condition",10),
          (else_try),
            (eq, ":imod", imod_bent),
            (assign,"$car_condition",15),
          (else_try),
            (eq, ":imod", imod_chipped),
            (assign,"$car_condition",20),
          (else_try),
            (eq, ":imod", imod_battered),
            (assign,"$car_condition",25),
          (else_try),
            (eq, ":imod", imod_poor),
            (assign,"$car_condition",30),
          (else_try),
            (eq, ":imod", imod_crude),
            (assign,"$car_condition",35),
          (else_try),
            (eq, ":imod", imod_old),
            (assign,"$car_condition",40),
          (else_try),
            (eq, ":imod", imod_cheap),
            (assign,"$car_condition",45),
          (else_try),
            (assign,"$car_condition", 50),
          (try_end),
        (try_end),
        # (ge,":car",0),
        # (assign,":gasoline",0),
        (troop_get_inventory_capacity, ":inv_size", "trp_player"),
        (try_for_range, ":item_slot", 0, ":inv_size"),
          # (neq,":gasoline",1),
          (troop_get_inventory_slot, ":item_no", "trp_player", ":item_slot"),
          (ge, ":item_no", 0),
          (eq, ":item_no", "itm_gasoline"),
          (troop_inventory_slot_get_item_amount, ":cur_amount", "trp_player", ":item_slot"),
          (val_add,"$car_gasoline",":cur_amount"),
        (try_end),
        (ge,":car",0),
        (try_begin),
          (ge,"$car_gasoline",1),
          (ge,"$car_condition", 10),

          (assign,":driving",1),
        (else_try),
          (jump_to_menu, "mnu_vehicle_disembark"),
        (try_end),
      (try_end),

      (try_begin),
        # (troop_get_inventory_slot, ":cur_horse", "trp_player", ek_horse), #horse slot
        (assign, ":new_icon", -1), #assign map icon to player

        (try_begin),
          (eq, "$g_player_icon_state", pis_normal),
          (try_begin),
            (ge, ":driving", 1),
            (try_begin),
              (eq,":car","itm_pickup_a"),
              (assign, ":new_icon", "icon_map_pickup_a"),
            (else_try),
              (eq,":car","itm_pickup_b"),
              (assign, ":new_icon", "icon_map_pickup_b"),
            (else_try),
              (eq,":car","itm_pickup_c"),
              (assign, ":new_icon", "icon_map_pickup_c"),
            (else_try),
              (eq,":car","itm_jeep_beige"),
              (assign, ":new_icon", "icon_map_jeep_beige"),
            (else_try),
              (eq,":car","itm_jeep_black"),
              (assign, ":new_icon", "icon_map_jeep_black"),
            (else_try),
              (eq,":car","itm_jeep_green"),
              (assign, ":new_icon", "icon_map_jeep_green"),
            (else_try),
              (eq,":car","itm_jeep_greenb"),
              (assign, ":new_icon", "icon_map_jeep_greenb"),
            (else_try),
              (eq,":car","itm_jeep_tan"),
              (assign, ":new_icon", "icon_map_jeep_tan"),
            (try_end),
          (else_try),

            # (ge, ":cur_horse", 0),
            # (assign, ":new_icon", "icon_player_horseman"),
          # (else_try),
            (assign, ":new_icon", "icon_player"),
          (try_end),
        (else_try),
          (eq, "$g_player_icon_state", pis_camping),
          (party_get_num_companions, ":count", "p_main_party"),
          (try_begin),
            (le,":count",50),
            (assign, ":new_icon", "icon_map_camp_1"),
          (else_try),
            (assign, ":new_icon", "icon_map_camp_2"),
          (try_end),
        (else_try),
          (eq, "$g_player_icon_state", pis_ship),
          (assign, ":new_icon", "icon_ship"),
        (try_end),
        (neq, ":new_icon", "$g_player_party_icon"),
        (assign, "$g_player_party_icon", ":new_icon"),
        (party_set_icon, "p_main_party", ":new_icon"),
      (try_end),

      (try_begin),
        #time
        (store_time_of_day, reg5),
        (store_current_day, reg7),
        (val_add, reg7,1),
        (store_current_hours, ":hours"),
        (call_script, "script_game_get_date_text", 0, ":hours"),

        #weather
        (get_global_cloud_amount, "$g_cloud"),
        (get_global_haze_amount, "$g_fog"),

        # (assign, reg8,"$g_temperature"),
        # (assign, ":final_temperature","$g_temperature"),
        # (val_mul, ":final_temperature", 9),
        # (val_div, ":final_temperature", 5),
        # (val_add, ":final_temperature", 32),
        # (assign, reg12, ":final_temperature"),

        (assign,"$g_rad_zone",0),
        (try_for_range, ":map", centers_begin, arena_end),
          (try_begin),
            (neq,"$g_rad_zone",1),
            (party_slot_eq, ":map", slot_party_radzone, 1),
            (store_distance_to_party_from_party, ":dist", "p_main_party", ":map"),
            (lt,":dist", 10),
            (assign,"$g_rad_zone",1),
          (try_end),
          (try_begin),
            (party_slot_eq, ":map", slot_party_invisible, 1),

            (store_distance_to_party_from_party, ":dist", "p_main_party", ":map"),
            (lt,":dist", 20),

            (party_set_flags, ":map", pf_always_visible, 1),
            (party_set_slot, ":map", slot_party_invisible, 0),
            (play_sound, "snd_marker_added"),
          (try_end),
        (try_end),

        (try_begin),
          (eq,"$g_rad_zone",1),
          #(str_store_string, s73, "@Alert: High radioactivity!"),
          (str_store_string, s73, "@Alert: Dust storm!"),
        (else_try),
          (str_store_string, s73, "str_empty_string"),
        (try_end),

        (try_begin),
          (eq,"$g_sandstorm",1),
          # (try_begin),
            # (gt,"$g_cloud",25),
            # (assign,"$g_sandstorm",0),
          # (try_end),
          # (eq,"$g_sandstorm",1),
          (str_store_string, s72, "@Alert: Sandstorm!"),
        (else_try),
          (str_store_string, s72, "str_empty_string"),
        (try_end),

        (try_begin),
          (lt,"$g_fog",50),
          (str_store_string, s71, "@ "),
        (else_try),
          (lt,"$g_fog",75),
          (str_store_string, s71, "@ / Foggy "),
        (else_try),
          (str_store_string, s71, "@ / Fog "),
        (try_end),

        (try_begin),
          (le,"$g_cloud",15),
          (try_begin),
            (is_between, reg5, 4, 20),
            (str_store_string, s70, "@Sunshine"),
          (else_try),
            (str_store_string, s70, "@Clear Night"),
          (try_end),
        (else_try),
          (le,"$g_cloud",50),
          (str_store_string, s70, "@Few clouds"),
        (else_try),
          (le,"$g_cloud",85),
          (str_store_string, s70, "@Cloudy"),
        (else_try),
          (str_store_string, s70, "@Stormy"),
        (try_end),

        (try_begin),
          (eq,"$g_rain",1),
          # (try_begin),
            # (le,"$g_cloud",50),
            # (assign,"$g_rain",0),
          # (try_end),
          # (eq,"$g_rain",1),
          (str_store_string, s78, "@/ Raining"),
        (else_try),
          (str_store_string, s78, "str_empty_string"),
        (try_end),

        #needs
        (troop_get_slot, reg6, "trp_player", slot_troop_condition_hunger),
        (troop_get_slot, reg1, "trp_player", slot_troop_condition_thirst),
        (troop_get_slot, reg2, "trp_player", slot_troop_condition_rest),

        (try_begin),
          (gt,reg6,100),
          (troop_set_slot,"trp_player", slot_troop_condition_hunger, 100),
        (else_try),
          (lt,reg6,-100),
          (troop_set_slot,"trp_player", slot_troop_condition_hunger, -100),
        (try_end),
        (try_begin),
          (gt,reg1,100),
          (troop_set_slot,"trp_player", slot_troop_condition_thirst, 100),
        (else_try),
          (lt,reg1,-100),
          (troop_set_slot,"trp_player", slot_troop_condition_thirst, -100),
        (try_end),
        (try_begin),
          (gt,reg2,100),
          (troop_set_slot,"trp_player", slot_troop_condition_rest, 100),
        (else_try),
          (lt,reg2,-100),
          (troop_set_slot,"trp_player", slot_troop_condition_rest, -100),
        (try_end),

        # (assign,reg3,0),
        (store_add,reg3,reg6,reg1),
        (val_mul,reg3,2),
        (val_add,reg3,reg2),
        (val_div,reg3,5),
        (troop_set_slot,"trp_player", slot_troop_condition, reg3),

        #hunger
        (try_begin),
          (le,reg6,10),
          (str_store_string, s74, "@Starving"),
        (else_try),
          (le,reg6,25),
          (str_store_string, s74, "@Hungry"),
        (else_try),
          (le,reg6,50),
          (str_store_string, s74, "@Bit hungry"),
        (else_try),
          (le,reg6,75),
          (str_store_string, s74, "@Fine"),
        (else_try),
          (str_store_string, s74, "@Well fed"),
        (try_end),

        #thurst
        (try_begin),
          (le,reg1,10),
          (str_store_string, s75, "@Dying of thirst"),
        (else_try),
          (le,reg1,25),
          (str_store_string, s75, "@Thirsty"),
        (else_try),
          (le,reg1,50),
          (str_store_string, s75, "@Bit thirsty"),
        (else_try),
          (str_store_string, s75, "@Fine"),
        (try_end),

        #tired	#slot_troop_condition_rest
        (try_begin),
          (le,reg2,0),
          (str_store_string, s77, "@Deadly tired"),
        (else_try),
          (le,reg2,25),
          (str_store_string, s77, "@Tired"),
        (else_try),
          (le,reg2,60),
          (str_store_string, s77, "@Normal"),
        (else_try),
          (le,reg2,95),
          (str_store_string, s77, "@Fit"),
        (else_try),
          (str_store_string, s77, "@Well rested"),
        (try_end),

        #condition
        (try_begin),
          (le,reg3,10),
          (str_store_string, s76, "@Critical"),
        (else_try),
          (le,reg3,25),
          (str_store_string, s76, "@Bad"),
        (else_try),
          (le,reg3,75),
          (str_store_string, s76, "@Normal"),
        (else_try),
          (le,reg3,99),
          (str_store_string, s76, "@Fine"),
        (else_try),
          (str_store_string, s76, "@Good"),
        (try_end),
        #bonus
        (troop_get_slot, reg4, "trp_player", slot_troop_food_bonus),
        #wounded
        (try_begin),
          (ge,"$g_player_tigh_wound",1),
          (str_store_string, s83, "str_wound_thigh"),
          (try_begin),
            (eq,"$g_player_tigh_wound",2),
            (str_store_string, s79, "@{s83} (treated)"),
          (else_try),
            (str_store_string, s79, "@{s83}"),
          (try_end),
        (else_try),
          (ge,"$g_player_calf_wound",1),
          (str_store_string, s83, "str_wound_calf"),
          (try_begin),
            (eq,"$g_player_calf_wound",2),
            (str_store_string, s79, "@{s83} (treated)"),
          (else_try),
            (str_store_string, s79, "@{s83}"),
          (try_end),
        (else_try),
          (ge,"$g_player_foot_wound",1),
          (str_store_string, s83, "str_wound_foot"),
          (try_begin),
            (eq,"$g_player_foot_wound",2),
            (str_store_string, s79, "@{s83} (treated)"),
          (else_try),
            (str_store_string, s79, "@{s83}"),
          (try_end),
        (else_try),
          (ge,"$g_player_spine_wound",1),
          (str_store_string, s83, "str_wound_spine"),
          (try_begin),
            (eq,"$g_player_spine_wound",2),
            (str_store_string, s79, "@{s83} (treated)"),
          (else_try),
            (str_store_string, s79, "@{s83}"),
          (try_end),
        (else_try),
          (ge,"$g_player_thorax_wound",1),
          (str_store_string, s83, "str_wound_thorax"),
          (try_begin),
            (eq,"$g_player_thorax_wound",2),
            (str_store_string, s79, "@{s83} (treated)"),
          (else_try),
            (str_store_string, s79, "@{s83}"),
          (try_end),
        (else_try),
          (ge,"$g_player_head_wound",1),
          (str_store_string, s83, "str_wound_head"),
          (try_begin),
            (eq,"$g_player_head_wound",2),
            (str_store_string, s79, "@{s83} (treated)"),
          (else_try),
            (str_store_string, s79, "@{s83}"),
          (try_end),
        (else_try),
          (ge,"$g_player_shoulder_wound",1),
          (str_store_string, s83, "str_wound_shoulder"),
          (try_begin),
            (eq,"$g_player_shoulder_wound",2),
            (str_store_string, s79, "@{s83} (treated)"),
          (else_try),
            (str_store_string, s79, "@{s83}"),
          (try_end),
        (else_try),
          (ge,"$g_player_arm_wound",1),
          (str_store_string, s83, "str_wound_arm"),
          (try_begin),
            (eq,"$g_player_arm_wound",2),
            (str_store_string, s79, "@{s83} (treated)"),
          (else_try),
            (str_store_string, s79, "@{s83}"),
          (try_end),
        (else_try),
          (ge,"$g_player_hand_wound",1),
          (str_store_string, s83, "str_wound_hand"),
          (try_begin),
            (eq,"$g_player_hand_wound",2),
            (str_store_string, s79, "@{s83} (treated)"),
          (else_try),
            (str_store_string, s79, "@{s83}"),
          (try_end),
        (else_try),
          (troop_is_wounded, "trp_player"),
          (str_store_string, s79, "@Wounded"),
        (else_try),
          (str_store_string, s79, "str_empty_string"),
        (try_end),

        #closest center
        # (call_script, "script_get_closest_walled_center", "p_main_party"),
        (assign, ":min_distance", 9999999),
        (assign, reg15, -1),
        (try_for_range, ":center_no", centers_begin, arena_end),
          (party_slot_eq, ":center_no", slot_party_invisible, 0),
          (store_distance_to_party_from_party, ":party_distance", "p_main_party", ":center_no"),
          (lt, ":party_distance", ":min_distance"),
          (assign, ":min_distance", ":party_distance"),
          (assign, reg15, ":center_no"),
        (try_end),
        (str_store_party_name, s80, reg15),

        # (store_troop_health, reg7, "trp_player"),

        #morale
        (party_get_morale, reg9, "p_main_party"),

        #camp
        (call_script, "script_camp_quality"),
        (assign, reg10, "$g_camp_quality"),
        (try_begin),
          (le,reg10,25),
          (str_store_string, s81, "@Depleted"),
        (else_try),
          (le,reg10,50),
          (str_store_string, s81, "@Scarce"),
        (else_try),
          (le,reg10,70),
          (str_store_string, s81, "@Mediocre"),
        (else_try),
          (le,reg10,90),
          (str_store_string, s81, "@Adequate"),
        (else_try),
          (str_store_string, s81, "@Well-equipped"),
        (try_end),

        #vehicle
        (try_begin),
          (eq, "$car_condition", 0),
          (str_store_string, s82, "str_empty_string"),
        (else_try),
          (eq, "$car_condition", -1),
          (str_store_string, s82, "@Vehicle condition: Non-Operational"),
        (else_try),
          (eq, "$car_condition", 10),
          (str_store_string, s82, "@@Vehicle condition: Rusty"),
        (else_try),
          (eq, "$car_condition", 15),
          (str_store_string, s82, "@Vehicle condition: Bent"),
        (else_try),
          (eq, "$car_condition", 20),
          (str_store_string, s82, "@Vehicle condition: Chipped"),
        (else_try),
          (eq, "$car_condition", 25),
          (str_store_string, s82, "@Vehicle condition: Battered"),
        (else_try),
          (eq, "$car_condition", 30),
          (str_store_string, s82, "@Vehicle condition: Poor"),
        (else_try),
          (eq, "$car_condition", 35),
          (str_store_string, s82, "@Vehicle condition: Crude"),
        (else_try),
          (eq, "$car_condition", 40),
          (str_store_string, s82, "@Vehicle condition: Old"),
        (else_try),
          (eq, "$car_condition", 45),
          (str_store_string, s82, "@Vehicle condition: Cheap"),
        (else_try),
          (eq, "$car_condition", 50),
          (str_store_string, s82, "@Vehicle condition: Normal"),
        (try_end),
        (assign,reg11,"$car_gasoline"),

        (str_store_troop_name, s84, "trp_player"),
        (store_character_level, reg13,  "trp_player"),
        (store_troop_gold, reg14, "trp_player"),

        (assign,":display",0),
        (try_begin),
          (eq,"$info_sys",1),
          (assign,":display",1),
        (else_try),
          (le,":mouse_y",40),
          (gt,":mouse_x",803),
          (assign,":display",1),
        (try_end),
        (eq,":display",1),

        (set_fixed_point_multiplier, 1),
        (set_shader_param_float, "@vMapUI", shader_set_2),

        (set_fixed_point_multiplier, 100),
        #text
        (tutorial_message_set_size, 18, 18),
        (tutorial_message_set_position,1075, 375),
        # (tutorial_message_set_position,1075, 300),
        (tutorial_message_set_center_justify, 0),
        (tutorial_message_set_background, 0),
        (tutorial_message,"@"
          +"Name: {s84}^^"
          +"LVL: {reg13}^"
          +"Money: {reg14} $^^"
          +"Location: near {s80}^"
          +"{s73}{s72}^^"
          +"Weather: {s70}{s71}{s78}^"
          +"Overall Condition: {s76}^"
          +"{s79}^"
          +"Hunger: {s74} (Bonus: {reg4})^"
          +"Thirst: {s75}^"
          +"Rest: {s77}^^"
          +"Party Morale: {reg9}^"
          +"Equipment: {s81} ({reg10})^"
          +"Gasoline: {reg11}^"
          +"{s82}", amber_bright),

##            (get_player_agent_kill_count, reg22, 0),# (get_player_agent_kill_count, reg23, 1),# (get_player_agent_own_troop_kill_count, reg24, 1),# party_get_current_terrain             = 1608  # (party_get_current_terrain, <destination>, <party_id>),

        #death
        (try_begin),
          (lt, "$cheat_mode", 1),

          # (this_or_next|le,reg6,-100),
          # (le,reg1,-100),
          # (this_or_next|le,reg1,-100),
          # (this_or_next|le,reg2,-100),
          # (le,reg2,-100),
          (le,reg3,-50),
          (store_random_in_range,":rnd",0,100),
          (eq,":rnd",1),
          (jump_to_menu, "mnu_player_death"),
        (try_end),
      (else_try),
        (set_fixed_point_multiplier, 1),
        (set_shader_param_float, "@vMapUI", shader_set_1),

        (set_fixed_point_multiplier, 100),

        (clear_omitted_keys),

        (tutorial_message, -1),
      (try_end),
     # (try_end),

      (try_begin),
        (key_clicked, key_page_up),
        (key_is_down, key_page_up),
        # (key_clicked, key_r),
        # (key_is_down, key_r),
        (call_script, "script_musicplayer",0),

      (else_try),
        (key_clicked, key_page_down),
        (key_is_down, key_page_down),
        # (key_clicked, key_t),
        # (key_is_down, key_t),

        (call_script, "script_musicplayer",1),
      (try_end),

      (str_store_string_reg, s1, s90), # make back up of s1 as it gets overwritten by game_get_date_text
    ]),


# Attach Lord Parties to the town they are in
(0.1,
   [
       (try_for_range, ":troop_no", heroes_begin, heroes_end),
         (this_or_next|troop_slot_eq, ":troop_no", slot_troop_occupation, slto_inactive), #SB : fix stuck defector bug
         (troop_slot_eq, ":troop_no", slot_troop_occupation, slto_kingdom_hero),
         (troop_get_slot, ":troop_party_no", ":troop_no", slot_troop_leaded_party),
         (ge, ":troop_party_no", 1),
         (party_is_active, ":troop_party_no"),

         (party_get_attached_to, ":cur_attached_town", ":troop_party_no"),
         (lt, ":cur_attached_town", 1),
         (party_get_cur_town, ":destination", ":troop_party_no"),
         (is_between, ":destination", centers_begin, centers_end),
         (call_script, "script_get_relation_between_parties", ":destination", ":troop_party_no"),
         (try_begin),
           (ge, reg0, 0),
           (party_attach_to_party, ":troop_party_no", ":destination"),
         (else_try),
           (party_set_ai_behavior, ":troop_party_no", ai_bhvr_hold),
         (try_end),

         (try_begin),
           (this_or_next|party_slot_eq, ":destination", slot_party_type, spt_town),
           (party_slot_eq, ":destination", slot_party_type, spt_castle),
           (store_faction_of_party, ":troop_faction_no", ":troop_party_no"),
           (store_faction_of_party, ":destination_faction_no", ":destination"),
           (eq, ":troop_faction_no", ":destination_faction_no"),
           (party_get_num_prisoner_stacks, ":num_stacks", ":troop_party_no"),
           (gt, ":num_stacks", 0),
           (assign, "$g_move_heroes", 1),
           (call_script, "script_party_prisoners_add_party_prisoners", ":destination", ":troop_party_no"),#Moving prisoners to the center
           (assign, "$g_move_heroes", 1),
           (call_script, "script_party_remove_all_prisoners", ":troop_party_no"),
         (try_end),
       (try_end),
    ]),


(0.5,
    [
#Individual lord political calculations
#Check for lords without fiefs, auto-defections, etc
     (try_begin),
        ##diplomacy start+
        #This is fairly complicated, and it was getting nearly unreadable so I reformatted it.
        #The old version is visible in version control.
        (assign, ":save_reg0", reg0),
        (val_add, "$g_lord_long_term_count", 1),
        (try_begin),
            (neg|is_between, "$g_lord_long_term_count", active_npcs_including_player_begin, active_npcs_end),
            (assign, "$g_lord_long_term_count", active_npcs_including_player_begin),
        (try_end),

        ##Add political calculations for faction ladies.  Just extending the range would
        ##slow down the political calculations cycle, which would have possibly-unforeseen results.
        ##Instead, add a second iteration to deal with extensions.
        (try_for_range, ":iteration", 0, 2),
            (assign, ":troop_no", "$g_lord_long_term_count"),
            (try_begin),
                (eq, ":iteration", 1),
                (val_sub, ":troop_no", active_npcs_including_player_begin),
                (val_add, ":troop_no", active_npcs_end),
            (try_end),
            #Crude check to make sure that a careless modder (i.e. me) didn't decide it
            #would be a good idea to redefine active_npcs to include kingdom_ladies,
            #which would make the second iteration run off the end of the heroes list.
            (is_between, ":troop_no", active_npcs_including_player_begin, heroes_end),

            #Special handling for trp_player, and get the troop's faction
            (try_begin),
                (eq, ":troop_no", "trp_kingdom_heroes_including_player_begin"),
                (assign, ":troop_no", "trp_player"),
                (assign, ":faction", "$players_kingdom"),
            (else_try),
                (store_faction_of_troop, ":faction", ":troop_no"),
            (try_end),

            (try_begin),
                (eq, "$cheat_mode", 1),
                (str_store_troop_name, s9, ":troop_no"),
                (display_message, "@{!}DEBUG -- Doing political calculations for {s9}"),
            (try_end),

            #Tally the fiefs owned by the hero, and cache the value in slot.
            #If a lord owns no fiefs, his relations with his liege may deteriorate.
            (try_begin),
                (assign, reg0, 1),#Center points + 1
                (try_for_range, ":center", centers_begin, centers_end),
                    (party_slot_eq, ":center", slot_town_lord, ":troop_no"),
                    (try_begin),
                        (is_between, ":center", towns_begin, towns_end),
                        (val_add, reg0, 4),#3 points per town #increased these to compensate for less fiefs - krag
                    (else_try),
                        (is_between, ":center", walled_centers_begin, walled_centers_end),
                        (val_add, reg0, 3),#2 points per fort
                    (else_try),
                        (val_add, reg0, 2),#1 point per village
                    (try_end),
                (try_end),
                #Update cached total
                (troop_set_slot, ":troop_no", dplmc_slot_troop_center_points_plus_one, reg0),
                #If a lord has no fiefs, relation loss potentially results. #reduce this as we have less fiefs than lords - krag
                #Do not apply this to the player.
                (eq, reg0, 1),
                (troop_slot_eq, ":troop_no", slot_troop_occupation, slto_kingdom_hero),
                (neq, ":troop_no", "trp_player"),

                #Don't apply this to the leader
                (faction_get_slot, ":faction_leader", ":faction", slot_faction_leader),
                (gt, ":faction_leader", -1),
                (neq, ":faction_leader", ":troop_no"),
                (neg|troop_slot_eq, ":faction_leader", slot_troop_spouse, ":troop_no"),
                (neg|troop_slot_eq, ":troop_no", slot_troop_spouse, ":faction_leader"),

                (troop_get_slot, ":troop_reputation", ":troop_no", slot_lord_reputation_type),
                (try_begin),
                    (this_or_next|eq, ":troop_reputation", lrep_quarrelsome),
                    (this_or_next|eq, ":troop_reputation", lrep_selfrighteous),
                    (this_or_next|eq, ":troop_reputation", lrep_cunning),
                    (eq, ":troop_reputation", lrep_debauched),
                    (call_script, "script_troop_change_relation_with_troop", ":troop_no", ":faction_leader", -4),
                    (val_add, "$total_no_fief_changes", -1),#was 4
                # (else_try),
                    # (this_or_next|eq, ":troop_reputation", lrep_ambitious),#add support for lady personalities
                    # (eq, ":troop_reputation", lrep_martial),
                    # (call_script, "script_troop_change_relation_with_troop", ":troop_no", ":faction_leader", -2),
                    # (val_add, "$total_no_fief_changes", -2),
                (try_end),
            (try_end),

            #Auto-indictment or defection
            (try_begin),
                (this_or_next|troop_slot_eq, ":troop_no", slot_troop_occupation, slto_kingdom_hero),
                (eq, ":troop_no", "trp_player"),

                #There must be a valid faction leader.  The faction leader won't defect from his own faction.
                #To avoid certain potential complications, also skip the defection/indictment check for the
                #spouse of the faction leader.  (Code to make that possible can be added elsewhere if
                #necessary.)
                (faction_get_slot, ":faction_leader", ":faction", slot_faction_leader),
                (gt, ":faction_leader", -1),
                (neq, ":troop_no", ":faction_leader"),
                (neg|troop_slot_eq, ":troop_no", slot_troop_spouse, ":faction_leader"),
                (neg|troop_slot_eq, ":faction_leader", slot_troop_spouse, ":troop_no"),

              #I don't know why these are necessary, but they appear to be
                (neg|is_between, ":troop_no", kings_begin, kings_end), #SB : range consts
                # (neg|is_between, ":troop_no", pretenders_begin, pretenders_end),

              (assign, ":num_centers", 0),
              (try_for_range,":cur_center", walled_centers_begin, walled_centers_end),
                (store_faction_of_party, ":faction_of_center", ":cur_center"),
                (eq, ":faction_of_center", ":faction"),
                (val_add, ":num_centers", 1),
              (try_end),

              #we are counting num_centers to allow defection although there is high relation between faction leader and troop.
              #but this rule should not applied for player's faction and player_supporters_faction so thats why here 1 is added to num_centers in that case.
              (try_begin),
                (this_or_next|eq, ":faction", "$players_kingdom"),
                (eq, ":faction", "fac_player_supporters_faction"),
                (val_add, ":num_centers", 1),
              (try_end),

                (call_script, "script_troop_get_relation_with_troop", ":troop_no", ":faction_leader"),
                (this_or_next|le, reg0, -75), #was -75 50
                (eq, ":num_centers", 0), #if there is no walled centers that faction has defection happens 100%.

                (call_script, "script_cf_troop_can_intrigue", ":troop_no", 0), #Should include battle, prisoner, in a fort with others
                (store_random_in_range, ":who_moves_first", 0, 2),

                #The more centralized the faction, the greater the chance the liege will indict
                #the lord before he defects.
                (faction_get_slot, reg0, ":faction", dplmc_slot_faction_centralization),
                (val_clamp, reg0, -3, 4),
                (val_add, reg0, 10),#7 minimum, 13 maximum
                (store_random_in_range, ":random", 0, reg0),
                #Random  < 5: The lord defects
                #Random >= 5: The liege indicts the lord for treason

                (try_begin),
                  (this_or_next|eq, ":num_centers", 0), #Thanks Caba`drin & Osviux
                  (neq, ":who_moves_first", 0),
                  (lt, ":random", 5),
                  (neq, ":troop_no", "trp_player"),
                  #do a defection
                  (try_begin),
                    (neq, ":num_centers", 0),
                    #Note that I assign the troop number instead of 1 as is done in Native
                    (assign, "$g_give_advantage_to_original_faction", ":troop_no"),
                  (try_end),
                #(assign, "$g_give_advantage_to_original_faction", 1),

                  (store_faction_of_troop, ":orig_faction", ":troop_no"),
                  (call_script, "script_lord_find_alternative_faction", ":troop_no"),
                  (assign, ":new_faction", reg0),
                  (assign, "$g_give_advantage_to_original_faction", 0),
                  (try_begin),
                    (neq, ":new_faction", ":orig_faction"),
                    (is_between, ":new_faction", kingdoms_begin, kingdoms_end),
                    (str_store_troop_name_link, s1, ":troop_no"),
                    (str_store_faction_name_link, s2, ":new_faction"),
                    (str_store_faction_name_link, s3, ":faction"),
                    (call_script, "script_change_troop_faction", ":troop_no", ":new_faction"),
                    (try_begin),
                      (ge, "$cheat_mode", 1),
                      (str_store_troop_name, s4, ":troop_no"),
                      (display_message, "@{!}DEBUG - {s4} faction changed in defection"),
                    (try_end),
                    (call_script, "script_dplmc_store_troop_is_female", ":troop_no"),
                    (assign, reg4, reg0),
                    #SB : factionalize colors
                    (str_store_string, s4, "str_lord_defects_ordinary"),
                    (faction_get_color, ":color", ":new_faction"),
                    (display_log_message, s4, ":color"),
                    (try_begin),
                      (eq, "$cheat_mode", 1),
                      (this_or_next|eq, ":new_faction", "$players_kingdom"),
                      (eq, ":faction", "$players_kingdom"),
                      (call_script, "script_add_notification_menu", "mnu_notification_lord_defects", ":troop_no", ":faction"),
                    (try_end),
                  (try_end),
                (else_try),
                  (neq, ":faction_leader", "trp_player"),
                  (call_script, "script_troop_get_relation_with_troop", ":troop_no", ":faction_leader"),
                  (le, reg0, -50), #was -75
                  (call_script, "script_indict_lord_for_treason", ":troop_no", ":faction"),
                (try_end),

                #Update :faction if it has changed
                (try_begin),
                    (eq, ":troop_no", "trp_player"),
                    (assign, reg0, "$players_kingdom"),
                (else_try),
                    (store_faction_of_troop, reg0, ":troop_no"),
                (try_end),
                (neq, reg0, ":faction"),#Fall through if indictment/defection didn't happen
                (assign, ":faction", reg0),
            (else_try),  #Take a stand on an issue
                (neq, ":troop_no", "trp_player"),
                (troop_slot_eq, ":troop_no", slot_troop_occupation, slto_kingdom_hero),
                (faction_slot_ge, ":faction", slot_faction_political_issue, 1),
                #This bit of complication is needed for savegame compatibility -- if zero is in the slot, they'll choose anyway
                (neg|troop_slot_ge, ":troop_no", slot_troop_stance_on_faction_issue, 1),
                (this_or_next|troop_slot_eq, ":troop_no", slot_troop_stance_on_faction_issue, -1),
                    (neq, "$players_kingdom", ":faction"),

                (call_script, "script_npc_decision_checklist_take_stand_on_issue", ":troop_no"),
                (troop_set_slot, ":troop_no", slot_troop_stance_on_faction_issue, reg0),
            (else_try),
                #OPTIONAL CHANGE (AI CHANGES HIGH):
                (ge, "$g_dplmc_ai_changes", DPLMC_AI_CHANGES_HIGH),
                #If an AI faction has fiefless lords and no free fiefs, the warlord
                #will consider giving up a village.  The warlord will not give up fiefs if
                #doing so would give him less territory than another lord of his faction.
                #(For simplicity, the AI will not do this while a marshall appointment
                #is pending.)
                (faction_slot_eq, ":faction", slot_faction_leader, ":troop_no"),
                (neq, ":troop_no", "trp_player"),
                #With fewer than 3 points we don't need to bother continuing, since 2 points means he only owns a single village.
             (troop_get_slot, ":local_temp", ":troop_no", dplmc_slot_troop_center_points_plus_one),
                (ge, ":local_temp", 3),
                #Don't do this while other business is pending
                (neg|faction_slot_ge, ":faction", slot_faction_political_issue, 1),
                #Find the fiefless lord of his faction that the warlord likes best.
                #Terminate the search early if he finds another lord whose fiefs
                #equal or exceed his own, or a lord whose fief point slot is not
                #initialized.
                (assign, ":end_cond", heroes_end),
                (assign, ":any_found", -200),
                (assign, ":best_active_npc", -1),
                (try_for_range, ":active_npc", heroes_begin, ":end_cond"),
                    (neq, ":active_npc", ":troop_no"),
                    (troop_slot_eq, ":active_npc", slot_troop_occupation, slto_kingdom_hero),
                    (store_faction_of_troop, reg0, ":active_npc"),
                    (eq, reg0, ":faction"),
                    (troop_get_slot, reg0, ":active_npc", dplmc_slot_troop_center_points_plus_one),
                    (try_begin),
                        #Terminate.  The warlord cannot give up any points without being outfieffed (if he isn't already)
                        (ge, reg0, ":local_temp"),
                        (assign, ":end_cond", ":active_npc"),
                    (else_try),
                        #Terminate.  The first pass of political calculations aren't done, or things are in flux.
                        (lt, reg0, 1),
                        (assign, ":end_cond", ":active_npc"),
                    (else_try),
                        (eq, reg0, 1),
                        (call_script, "script_troop_get_relation_with_troop", ":troop_no", ":active_npc"),
                        (gt, reg0, ":any_found"),
                        (assign, ":any_found", reg0),
                        (assign, ":best_active_npc", ":active_npc"),
                    (try_end),
                (try_end),
                (eq, ":end_cond", heroes_end),
                (is_between, ":best_active_npc", heroes_begin, heroes_end),
                (gt, ":any_found", -10),
                #Give up the least prosperous fief.
                (assign, ":local_temp", 101),
                (assign, ":any_found", -1),
                (try_for_range, ":center", villages_begin, villages_end),
                    (party_slot_eq, ":center", slot_town_lord, ":troop_no"),
                    (party_get_slot, reg0, ":center", slot_town_prosperity),
                    (this_or_next|eq, ":any_found", -1),
                    (lt, reg0, ":local_temp"),
                    (assign, ":local_temp", reg0),
                    (assign, ":any_found", ":center"),
                (try_end),
                #Clear village's lord
                (is_between, ":any_found", centers_begin, centers_end),
                (party_set_slot, ":any_found", slot_town_lord, -1),
                (troop_get_slot, reg0, ":troop_no", dplmc_slot_troop_center_points_plus_one),
                (val_sub, reg0, 1),
                (troop_set_slot, ":troop_no", dplmc_slot_troop_center_points_plus_one, reg0),
                (str_store_party_name_link, s4, ":any_found"),
                (str_store_troop_name_link, s5, ":troop_no"),
                (str_store_faction_name_link, s7, ":faction"),
                (faction_get_color, ":color", ":faction"), #SB : color message
                (display_log_message, "@{s5} has decided to grant {s4} to another lord of the {s7}.", ":color"),
                #Reset faction issue
                (try_for_range, ":active_npc", heroes_begin, heroes_end),
                    (store_faction_of_troop, reg0, ":active_npc"),
                    (eq, reg0, ":faction"),
                    (troop_set_slot, ":troop_no", slot_troop_stance_on_faction_issue, -1),
                (try_end),
                (store_current_hours, reg0),
                (faction_set_slot, ":faction", slot_faction_political_issue_time, reg0),
                (faction_set_slot, ":faction", slot_faction_political_issue, ":any_found"),
                #Set the liege's position on the issue, since he gave up the village with
                #something specific in mind.
                (troop_set_slot, ":troop_no", slot_troop_stance_on_faction_issue, ":best_active_npc"),
            (try_end),

            #Reduce grudges over time
            (try_begin),
                #Skip this for the dead
                (neg|troop_slot_eq, ":troop_no", slot_troop_occupation, dplmc_slto_dead),
                #Do not perform this for faction ladies, since it will potentially mess up courtship.
                (neg|troop_slot_eq, ":troop_no", slot_troop_occupation, slto_kingdom_lady),

                (try_for_range, ":active_npc", heroes_begin, heroes_end),
                    (neq, ":active_npc", ":troop_no"),
                    (neg|troop_slot_eq, ":active_npc", slot_troop_occupation, slto_kingdom_lady),#Don't do for ladies
                    (neg|troop_slot_eq, ":active_npc", slot_troop_occupation, dplmc_slto_dead),#Don't do for the dead

                    #Fix: there are some NPCs that have "initial" relations with the player set,
                    #but they can decay before ever meeting him, so keep them until the first meeting.
                    (this_or_next|neq, ":troop_no", "trp_player"),
                    (troop_slot_ge, ":troop_no", slot_troop_met, 1),

                    (call_script, "script_troop_get_relation_with_troop", ":troop_no", ":active_npc"),
                    (lt, reg0, 0),
                    (store_sub, ":chance_of_convergence", 0, reg0),
                    (store_random_in_range, ":random", 0, 300),
                    (lt, ":random", ":chance_of_convergence"),
                    (call_script, "script_troop_change_relation_with_troop", ":troop_no", ":active_npc", 1),
                    (val_add, "$total_relation_changes_through_convergence", 1),
                (try_end),

                #Accelerate forgiveness for lords in exile (with their original faction only)
                (neq, ":troop_no", "trp_player"),
                (troop_slot_eq, ":troop_no", slot_troop_occupation, dplmc_slto_exile),
                (troop_get_slot, ":original_faction", ":troop_no", slot_troop_original_faction),
                (gt, ":original_faction", 0),

                (try_for_range, ":active_npc", heroes_begin, heroes_end),
                    (neq, ":active_npc", ":troop_no"),
                    (neg|troop_slot_eq, ":active_npc", slot_troop_occupation, slto_kingdom_lady),#Don't do for ladies
                    (neg|troop_slot_eq, ":active_npc", slot_troop_occupation, dplmc_slto_dead),#Don't do for the dead
                    #Only apply to heroes with the same original faction
                    (troop_slot_eq, ":active_npc", slot_troop_original_faction, ":original_faction"),
                    (call_script, "script_troop_get_relation_with_troop", ":troop_no", ":active_npc"),
                    (lt, reg0, 0),
                    (store_sub, ":chance_of_convergence", 0, reg0),
                    (store_random_in_range, ":random", 0, 300),
                    (lt, ":random", ":chance_of_convergence"),
                    (call_script, "script_troop_change_relation_with_troop", ":troop_no", ":active_npc", 1),
                    (val_add, "$total_relation_changes_through_convergence", 1),
                (try_end),
            (try_end),
        #Finish loop over the ":iteration" variable.
        (try_end),
        (assign, reg0, ":save_reg0"),
        ##diplomacy end+
     (try_end),

# Make heroes running away from someone retreat to friendly centers
     (try_begin),
       (try_for_range, ":cur_troop", heroes_begin, heroes_end),
         (troop_slot_eq, ":cur_troop", slot_troop_occupation, slto_kingdom_hero),
         (troop_get_slot, ":cur_party", ":cur_troop", slot_troop_leaded_party),
         (gt, ":cur_party", 0),
         (try_begin),
           (party_is_active, ":cur_party"),
           (try_begin),
             (get_party_ai_current_behavior, ":ai_bhvr", ":cur_party"),
             (eq, ":ai_bhvr", ai_bhvr_avoid_party),

			 #Certain lord personalities will not abandon a battlefield to flee to a fort
			 (assign, ":continue", 1),
			 (try_begin),
				(this_or_next|troop_slot_eq, ":cur_troop", slot_lord_reputation_type, lrep_upstanding),
					(troop_slot_eq, ":cur_troop", slot_lord_reputation_type, lrep_martial),
				(get_party_ai_current_object, ":ai_object", ":cur_party"),
				(party_is_active, ":ai_object"),
				(party_get_battle_opponent, ":battle_opponent", ":ai_object"),
				(party_is_active, ":battle_opponent"),
				(assign, ":continue", 0),
			 (try_end),
			 (eq, ":continue", 1),


             (store_faction_of_party, ":party_faction", ":cur_party"),
             (party_get_slot, ":commander_party", ":cur_party", slot_party_commander_party),
             (faction_get_slot, ":faction_marshall", ":party_faction", slot_faction_marshall),
             (neq, ":faction_marshall", ":cur_troop"),
             (assign, ":continue", 1),
             (try_begin),
               (ge, ":faction_marshall", 0),
               (troop_get_slot, ":faction_marshall_party", ":faction_marshall", slot_troop_leaded_party),
               (party_is_active, ":faction_marshall_party", 0),
               (eq, ":commander_party", ":faction_marshall_party"),
               (assign, ":continue", 0),
             (try_end),
             (eq, ":continue", 1),
             (assign, ":done", 0),
             (try_for_range, ":cur_center", walled_centers_begin, walled_centers_end),
               (eq, ":done", 0),
               (party_slot_eq, ":cur_center", slot_center_is_besieged_by, -1),
               (store_faction_of_party, ":center_faction", ":cur_center"),
               (store_relation, ":cur_relation", ":center_faction", ":party_faction"),
               (gt, ":cur_relation", 0),
               (store_distance_to_party_from_party, ":cur_distance", ":cur_party", ":cur_center"),
               (lt, ":cur_distance", 20),
               (party_get_position, pos1, ":cur_party"),
               (party_get_position, pos2, ":cur_center"),
               (neg|position_is_behind_position, pos2, pos1),
               (call_script, "script_party_set_ai_state", ":cur_party", spai_retreating_to_center, ":cur_center"),
               (assign, ":done", 1),
             (try_end),
           (try_end),
         (else_try),
           (troop_set_slot, ":cur_troop", slot_troop_leaded_party, -1),
         (try_end),
       (try_end),
     (try_end),

# Centers give alarm if the player is around
     (try_begin),
       (store_current_hours, ":cur_hours"),
       (store_mod, ":cur_hours_mod", ":cur_hours", 11),
       (store_sub, ":hour_limit", ":cur_hours", 5),
       (party_get_num_companions, ":num_men", "p_main_party"),
       (party_get_num_prisoners, ":num_prisoners", "p_main_party"),
       (val_add, ":num_men", ":num_prisoners"),
       (convert_to_fixed_point, ":num_men"),
       (store_sqrt, ":num_men_effect", ":num_men"),
       (convert_from_fixed_point, ":num_men_effect"),
       (try_begin),
         (eq, ":cur_hours_mod", 0),
         #Reduce alarm by 2 in every 11 hours.
         (try_for_range, ":cur_faction", kingdoms_begin, kingdoms_end),
           (faction_get_slot, ":player_alarm", ":cur_faction", slot_faction_player_alarm),
           (val_sub, ":player_alarm", 1),
           (val_max, ":player_alarm", 0),
           (faction_set_slot, ":cur_faction", slot_faction_player_alarm, ":player_alarm"),
         (try_end),
       (try_end),
       (eq, "$g_player_is_captive", 0),
       (try_for_range, ":cur_center", centers_begin, centers_end),
         (store_faction_of_party, ":cur_faction", ":cur_center"),
         (store_relation, ":reln", ":cur_faction", "fac_player_supporters_faction"),
         (lt, ":reln", 0),
         (store_distance_to_party_from_party, ":dist", "p_main_party", ":cur_center"),
         (lt, ":dist", 5),
         (store_mul, ":dist_sqr", ":dist", ":dist"),
         (store_sub, ":dist_effect", 20, ":dist_sqr"),
         (store_sub, ":reln_effect", 20, ":reln"),
         (store_mul, ":total_effect", ":dist_effect", ":reln_effect"),
         (val_mul, ":total_effect", ":num_men_effect"),
         (store_div, ":spot_chance", ":total_effect", 10),
         (store_random_in_range, ":random_spot", 0, 1000),
         (lt, ":random_spot", ":spot_chance"),
         (faction_get_slot, ":player_alarm", ":cur_faction", slot_faction_player_alarm),
         (val_add, ":player_alarm", 1),
         (val_min, ":player_alarm", 100),
         (faction_set_slot, ":cur_faction", slot_faction_player_alarm, ":player_alarm"),
         (try_begin),
           (neg|party_slot_ge, ":cur_center", slot_center_last_player_alarm_hour, ":hour_limit"),
           (str_store_party_name_link, s1, ":cur_center"),
           (display_message, "@Your party is spotted by {s1}."),
           (party_set_slot, ":cur_center", slot_center_last_player_alarm_hour, ":cur_hours"),
         (try_end),
       (try_end),
     (try_end),

     (try_begin),
     (try_end),
   ]),


(1,
   [
     (try_begin),
      (gt,"$auto_besiege_town",0),
      (gt,"$g_player_besiege_town", 0),
      (ge, "$g_siege_method", 1),
      (store_current_hours, ":cur_hours"),
      (eq, "$g_siege_force_wait", 0),
      (ge, ":cur_hours", "$g_siege_method_finish_hours"),
      (neg|is_currently_night),
      #SB : add adjusted renown for ladder construction
      (try_begin), #we should have stored the original npc but composition is unlikely to change
        (call_script, "script_get_max_skill_of_player_party", "skl_engineer"),
        (assign, ":troop_no", reg1),
        (neq, ":troop_no", "trp_player"),
        # (is_between, ":troop_no", companions_begin, companions_end),
        (store_mul, ":renown", "$g_siege_method", dplmc_companion_skill_renown + 1),
        (call_script, "script_change_troop_renown", ":troop_no", ":renown"),
      (try_end),
      (rest_for_hours, 0, 0, 0), #stop resting
     (try_end),

#Music,	#disabled as changes too frequently and abruptly
     # (try_begin),
       # (map_free),
        # (party_get_current_terrain, ":terrain_type", "p_main_party"),
        # (call_script, "script_warzone_ambience_sound",":terrain_type"),
        # # (call_script, "script_music_set_situation_with_culture", mtf_sit_travel),
     # (try_end),

#SB : debug block
     (try_begin),
        (ge, "$cheat_mode", 1),
        (troop_is_hero, "$g_talk_troop"),
        (str_store_troop_name, s17, "$g_talk_troop"),
        (troop_get_slot, reg17, "$g_talk_troop", slot_troop_wealth),
        (try_begin),
          (neq, reg17, "$demanded_money"),
          (display_message, "@{s17} has {reg17} falors"),
        (try_end),
        (assign, "$demanded_money", reg17),
     (try_end),

     (try_begin),
        (gt, "$g_reset_mission_participation", 1),

        (try_for_range, ":troop", active_npcs_begin, kingdom_ladies_end),
          (troop_set_slot, ":troop", slot_troop_mission_participation, 0),
        (try_end),
     (try_end),

#Player raiding a village
# This trigger will check if player's raid has been completed and will lead control to village menu.
     (try_begin),
      (ge,"$g_player_raiding_village",1),
      (try_begin),
        (neq, "$g_player_is_captive", 0),
        #(rest_for_hours, 0, 0, 0), #stop resting - abort
        (assign,"$g_player_raiding_village",0),
      (else_try),
        (map_free), #we have been attacked during raid
        (assign,"$g_player_raiding_village",0),
      (else_try),
        (this_or_next|party_slot_eq, "$g_player_raiding_village", slot_village_state, svs_looted),
        (party_slot_eq, "$g_player_raiding_village", slot_village_state, svs_deserted),
        (start_encounter, "$g_player_raiding_village"),
        (rest_for_hours, 0),
        (assign,"$g_player_raiding_village",0),
        (assign,"$g_player_raid_complete",1),
      (else_try),
        (party_slot_eq, "$g_player_raiding_village", slot_village_state, svs_being_raided),
        (try_begin), #SB : turbo
          (this_or_next|key_is_down, key_left_shift),
          (key_is_down, key_right_shift),
          (rest_for_hours, 3, 15, 1),
        (else_try),
          (rest_for_hours, 3, 5, 1),
        (try_end),
      (else_try),
        (rest_for_hours, 0, 0, 0), #stop resting - abort
        (assign,"$g_player_raiding_village",0),
        (assign,"$g_player_raid_complete",0),
      (try_end),
     (try_end),

# Process alarms - perhaps break this down into several groups, with a modula
#this now calls 1/3 of all centers each time, thus hopefully lightening the CPU load
     (try_begin),
        (call_script, "script_process_alarms"),
        (call_script, "script_allow_vassals_to_join_indoor_battle"),
        (call_script, "script_process_kingdom_parties_ai"),
     (try_end),

#rest
     (try_begin),
        (eq, "$g_player_is_captive", 0),

        # (party_get_attached_to, ":attachment", "p_main_party"),
        (try_begin),
            (neg|map_free),
            (troop_get_slot, ":rest", "trp_player", slot_troop_condition_rest),
            (val_add,":rest",10),
            (troop_set_slot,"trp_player", slot_troop_condition_rest, ":rest"),
        (else_try),
            (eq, "$g_player_icon_state", pis_camping),
            (troop_get_slot, ":rest", "trp_player", slot_troop_condition_rest),
            (val_add,":rest",10),
            (troop_set_slot,"trp_player", slot_troop_condition_rest, ":rest"),
        (else_try),
            (troop_get_slot, ":rest", "trp_player", slot_troop_condition_rest),
            (store_skill_level, ":tracking", "skl_tracking", "trp_player"),
            # (store_skill_level, ":pathfinding", "skl_pathfinding", "trp_player"),
            (store_skill_level, ":athletics", "skl_athletics", "trp_player"),
            (store_add,":rest_value", ":athletics",":tracking"),
            # (val_add,":rest_value", ":pathfinding"),
            (val_div,":rest_value",2),
			
			(try_begin),
				(is_between,"$g_player_party_icon","icon_map_jeep_beige","icon_map_uruk"),
				(troop_get_inventory_capacity, ":capacity", "trp_player"),
				(try_for_range, ":item_slot", 0, ":capacity"),
				  (troop_get_inventory_slot, ":item_no", "trp_player", ":item_slot"),
				  #(ge, ":item_no", 0),
				  (is_between, ":item_no", vehicles_begin,vehicles_end),
				  (val_add,":rest_value",1),
				(try_end),
			(try_end),
			
            (store_sub,":rest_mod",10,":rest_value"),
            (val_clamp,":rest_mod",2,9),
            (val_sub,":rest",":rest_mod"),

            (troop_set_slot,"trp_player", slot_troop_condition_rest, ":rest"),
        (try_end),
     (try_end),

# Guard peasants against bandits
     (try_begin),
        (check_quest_active, "qst_guard_peasants_against_bandits"),
        (neg|check_quest_concluded, "qst_guard_peasants_against_bandits"),
        # (eq, "$qst_guard_peasants_against_bandits_currently_activ", 1),

        (quest_get_slot, ":center_no", "qst_guard_peasants_against_bandits", slot_quest_target_center),

        (assign,":end",0),
        (try_begin),
            (store_distance_to_party_from_party, ":cur_distance", "p_main_party", ":center_no"),
            (gt, ":cur_distance", 10),
             (display_message, "@Distance to big...", message_alert), #SB : colorize

            (call_script, "script_abort_quest", "qst_guard_peasants_against_bandits", 0),
            (assign,":end",1),
        (try_end),
        (eq,":end",0),

        (assign,":end",0),
        (try_for_parties, ":party_no"),
            (gt, ":party_no", centers_end),
            (neq, ":party_no", "p_main_party"),
            (party_is_active, ":party_no"),
            (store_faction_of_party, ":party_faction", ":party_no"),
            (this_or_next|eq, ":party_faction", "fac_infected"),
            (this_or_next|eq, ":party_faction", "fac_mutants"),
            (eq, ":party_faction", "fac_outlaws"),
            (store_distance_to_party_from_party, ":cur_distance", ":party_no", ":center_no"),
            (le, ":cur_distance", 1),
                     (display_message, "@Party reached village...", message_alert), #SB : colorize

            (call_script, "script_abort_quest", "qst_guard_peasants_against_bandits", 0),
            (assign,":end",1),
        (try_end),
        (eq,":end",0),

        (val_add, "$qst_guard_peasants_against_bandits_currently_activ_hours", 1),
        (ge, "$qst_guard_peasants_against_bandits_currently_activ_hours", 24),
        (call_script, "script_succeed_quest", "qst_guard_peasants_against_bandits"),
     (try_end),

# Taking falors from player while resting in not owned centers
     (try_begin),
        (neg|map_free),
        (is_currently_night),
    #    (ge, "$g_last_rest_center", 0),
        (is_between, "$g_last_rest_center", centers_begin, centers_end),
        # (neg|party_slot_eq, "$g_last_rest_center", slot_town_lord, "trp_player"),

    ##diplomacy begin
        (party_get_slot, ":town_lord", "$g_last_rest_center", slot_town_lord),
        (assign, ":affiliated", 0), #SB : use local, not register to track
        (try_begin),
          (is_between, ":town_lord", lords_begin, kingdom_ladies_end),
          (call_script, "script_dplmc_is_affiliated_family_member", ":town_lord"),
          (neq, reg0, 0),
          #SB : moved this to when you start
          # (display_message, "@You are within the walls of an affiliated family member and don't have to pay for accommodation."),
          (assign, ":affiliated", 1),
        (try_end),
        # (eq, ":affiliated", 0),
    ##diplomacy end

        (store_faction_of_party, ":last_rest_center_faction", "$g_last_rest_center"),
        # (neq, ":last_rest_center_faction", "fac_player_supporters_faction"),
        (store_current_hours, ":cur_hours"),
        (ge, ":cur_hours", "$g_last_rest_payment_until"),
        (store_add, "$g_last_rest_payment_until", ":cur_hours", 24),
        (store_troop_gold, ":gold", "trp_player"),

        # (val_add, ":total_cost", 1),
        (try_begin), #SB : non-paying conditions
          (this_or_next|eq, ":affiliated", 1),
          (this_or_next|eq, ":town_lord", "trp_player"),
          (eq, ":last_rest_center_faction", "fac_player_supporters_faction"),
          (assign, ":total_cost", 0),
        (else_try), #SB : calculate extra accomodation costs for wounded + mounts
          (party_get_num_companions, ":num_men", "p_main_party"),
          (try_begin),
            (lt, "$g_dplmc_gold_changes", DPLMC_GOLD_CHANGES_MEDIUM),
            (store_div, ":total_cost", ":num_men", 4),
          (else_try),
            (call_script, "script_party_count_fit_for_battle", "p_main_party"),
            (store_sub, ":num_wounded", ":num_men", reg0),
            (store_div, ":total_cost", ":num_men", 4),
            (val_div, ":num_wounded", 2),
            (val_add, ":total_cost", ":num_wounded"),
            #TODO : deal with mounted troop stabling costs?
          (try_end),
          (val_add, ":total_cost", 1), #the player
        (try_end),
        (try_begin),
          (ge, ":gold", ":total_cost"),
          (try_begin),
            (gt, ":total_cost", 0),
            (display_message, "@You pay for accommodation.",message_alert),
            (troop_remove_gold, "trp_player", ":total_cost"),
          (try_end),
          (try_begin), #SB : faction troop morale
            (party_get_slot, ":old_faction", "$g_last_rest_center", slot_center_original_faction),
            (party_get_slot, ":relation", "$g_last_rest_center", slot_center_player_relation),
            (store_random_in_range, ":relation", ":relation", 1100), #spread of 1200 or 1000
            (ge, ":relation", 900),
            (val_sub, ":relation", ":total_cost"), #around 800
            (val_div, ":relation", 100),
            (val_max, ":relation", 1),
            (call_script, "script_change_faction_troop_morale", ":old_faction", ":relation", 0),
          (try_end),
        (else_try),
          (gt, ":gold", 0),
          (troop_remove_gold, "trp_player", ":gold"),
          #SB : stop resting
          (display_message, "@You are unable to pay for accommodation!", message_alert),
          (play_sound, "snd_encounter_nobleman"),
          # (val_mul, ":total_cost", -1),
          # (call_script, "script_change_player_party_morale", ":total_cost"),
          (val_div, ":total_cost", -10),
          (call_script, "script_change_player_relation_with_center", "$g_last_rest_center", ":total_cost"),
          (rest_for_hours, 0, 0, 0),
        (try_end),
     (try_end),

# Read books if player is resting.
     (try_begin),
       (neg|map_free),
       (gt, "$g_player_reading_book", 0),
       (player_has_item, "$g_player_reading_book"),
       (store_attribute_level, ":int", "trp_player", ca_intelligence),
       (item_get_slot, ":int_req", "$g_player_reading_book", slot_item_intelligence_requirement),
       (le, ":int_req", ":int"),
       (item_get_slot, ":book_reading_progress", "$g_player_reading_book", slot_item_book_reading_progress),
       (item_get_slot, ":book_read", "$g_player_reading_book", slot_item_book_read),
       (eq, ":book_read", 0),
       (val_add, ":book_reading_progress", 7),
       (item_set_slot, "$g_player_reading_book", slot_item_book_reading_progress, ":book_reading_progress"),
       (ge, ":book_reading_progress", 1000),
       (item_set_slot, "$g_player_reading_book", slot_item_book_read, 1),
       (str_store_item_name, s1, "$g_player_reading_book"),
       (str_clear, s2),
       (try_begin),
         (eq, "$g_player_reading_book", "itm_book_tactics"),
         (troop_raise_skill, "trp_player", "skl_tactics", 1),
         (str_store_string, s2, "@ Your tactics skill has increased by 1."),
       (else_try),
         (eq, "$g_player_reading_book", "itm_book_persuasion"),
         (troop_raise_skill, "trp_player", "skl_persuasion", 1),
         (str_store_string, s2, "@ Your persuasion skill has increased by 1."),
       (else_try),
         (eq, "$g_player_reading_book", "itm_book_leadership"),
         (troop_raise_skill, "trp_player", "skl_leadership", 1),
         (str_store_string, s2, "@ Your leadership skill has increased by 1."),
       (else_try),
         (eq, "$g_player_reading_book", "itm_book_intelligence"),
         (troop_raise_attribute, "trp_player", ca_intelligence, 1),
         (str_store_string, s2, "@ Your intelligence has increased by 1."),
       (else_try),
         (eq, "$g_player_reading_book", "itm_book_trade"),
         (troop_raise_skill, "trp_player", "skl_trade", 1),
         (str_store_string, s2, "@ Your trade skill has increased by 1."),
       (else_try),
         (eq, "$g_player_reading_book", "itm_book_weapon_mastery"),
         (troop_raise_skill, "trp_player", "skl_weapon_master", 1),
         (str_store_string, s2, "@ Your weapon master skill has increased by 1."),
       (else_try),
         (eq, "$g_player_reading_book", "itm_book_engineering"),
         (troop_raise_skill, "trp_player", "skl_engineer", 1),
         (str_store_string, s2, "@ Your technician skill has increased by 1."),
       (else_try),
         (eq, "$g_player_reading_book", "itm_book_prisoner_management"),
         (troop_raise_skill, "trp_player", "skl_prisoner_management", 1),
         (str_store_string, s2, "@ Your prisoner management skill has increased by 1."),
       (else_try),
         (eq, "$g_player_reading_book", "itm_book_first_aid"),
         (troop_raise_skill, "trp_player", "skl_first_aid", 1),
         (str_store_string, s2, "@ Your first aid skill has increased by 1."),
       (else_try),
         (eq, "$g_player_reading_book", "itm_book_inventory_management"),
         (troop_raise_skill, "trp_player", "skl_inventory_management", 1),
         (str_store_string, s2, "@ Your inventory management skill has increased by 1."),
       (else_try),
         (eq, "$g_player_reading_book", "itm_book_tracking"),
         (troop_raise_skill, "trp_player", "skl_tracking", 1),
         (str_store_string, s2, "@ Your survival skill has increased by 1."),
       (else_try),
         (eq, "$g_player_reading_book", "itm_book_spotting"),
         (troop_raise_skill, "trp_player", "skl_spotting", 1),
         (str_store_string, s2, "@ Your spotting skill has increased by 1."),
       (else_try),
         (eq, "$g_player_reading_book", "itm_book_pathfinding"),
         (troop_raise_skill, "trp_player", "skl_pathfinding", 1),
         (str_store_string, s2, "@ Your navigation skill has increased by 1."),
       (else_try),
         (eq, "$g_player_reading_book", "itm_book_looting"),
         (troop_raise_skill, "trp_player", "skl_looting", 1),
         (str_store_string, s2, "@ Your looting skill has increased by 1."),
       (else_try),
         (eq, "$g_player_reading_book", "itm_book_athletics"),
         (troop_raise_skill, "trp_player", "skl_athletics", 1),
         (str_store_string, s2, "@ Your athletics skill has increased by 1."),
       (else_try),
         (eq, "$g_player_reading_book", "itm_book_shield"),
         (troop_raise_skill, "trp_player", "skl_shield", 1),
         (str_store_string, s2, "@ Your warrior skill has increased by 1."),
       (else_try),
         (eq, "$g_player_reading_book", "itm_book_power_strike"),
         (troop_raise_skill, "trp_player", "skl_power_strike", 1),
         (str_store_string, s2, "@ Your power strike skill has increased by 1."),
       (try_end),

       (unlock_achievement, ACHIEVEMENT_BOOK_WORM),

       (try_begin),
         (eq, "$g_infinite_camping", 0),
         (dialog_box, "@You have finished reading {s1}.{s2}", "@Book Read"),
       (try_end),

       (assign, "$g_player_reading_book", 0),
     (try_end),

#Player scavenges
     (try_begin),
      (ge,"$g_player_scavenging",1),
      (try_begin),
        (neq, "$g_player_is_captive", 0),
        #(rest_for_hours, 0, 0, 0), #stop resting - abort
        (assign,"$g_player_scavenging",0),
      (else_try),
        (map_free), #we have been attacked during raid
        (assign,"$g_player_scavenging",0),
      (else_try),
        # (store_random_in_range,":attracted","pt_looters","pt_ghouls_army"),
        # (store_random_party_of_template, ":new_party", ":attracted"),
        # (ge,":new_party",0),
        # (neg|party_is_in_any_town,":new_party"),

        #(str_store_party_name, s4, ":new_party"),

        # #Old method: no terrain advantage
        # (call_script, "script_party_calculate_strength", ":new_party",0),
        # (assign, "$g_enemy_strength", reg0),
        # (call_script, "script_party_calculate_strength", "p_main_party",0),
        # (assign, "$g_ally_strength", reg0),

        # (store_mul, "$g_strength_ratio", "$g_ally_strength", 100),
        # (assign, ":enemy_strength", "$g_enemy_strength"), #these two lines added to avoid div by zero error
        # (val_max, ":enemy_strength", 1),
        # (val_div, "$g_strength_ratio", ":enemy_strength"),
        # (try_begin),
          # # (is_between,"$g_strength_ratio",50,151),

          # (party_relocate_near_party, ":new_party", "p_main_party"),
          # # (party_relocate_near_party, ":new_party", "p_main_party", 6),
          # (party_set_ai_behavior, ":new_party", ai_bhvr_attack_party),
          # (party_set_ai_object, ":new_party", "p_main_party"),
        (party_get_skill_level, ":player_party_survival_skill", "p_main_party", skl_scavenger),
        (val_mul, ":player_party_survival_skill",2),
        (party_get_skill_level, ":player_party_luck_skill", "p_main_party", skl_luck),
        (store_add, ":max_amount",":player_party_survival_skill",":player_party_luck_skill"),
        (party_get_skill_level, ":player_party_path_skill", "p_main_party", skl_pathfinding),
        (val_add, ":max_amount",":player_party_path_skill"),
        (val_div, ":max_amount",4),
        (val_add, ":max_amount",10),
        (val_max, ":max_amount",1),
        (store_random_in_range,":chance",0,":max_amount"),

        (try_begin),
          (eq,":chance",0),
          (spawn_around_party, "p_main_party", "pt_scavenge_template"),
          (assign, ":new_party", reg0),
          (store_party_size_wo_prisoners, ":max_number_to_add", "p_main_party"),
          # (store_character_level, ":level", "trp_player"),
          # (store_mul, ":max_number_to_add", ":level", 2),
          # (val_add, ":max_number_to_add", 11),
          # (val_mul, ":max_number_to_add", 2),
          # (store_random_in_range, ":number_to_add", 5, ":max_number_to_add"),
		  (val_max, ":max_number_to_add", 10),
          (store_random_in_range,":add",0,":max_number_to_add"), #was 51
          (val_div, ":max_number_to_add", 2),
          (val_add, ":max_number_to_add", ":add"),
          (store_random_in_range,":troop","trp_looter","trp_manhunter"),
          (try_for_range,":unused",0,":max_number_to_add"),
              (party_add_members, ":new_party", ":troop", 1),
          (try_end),
          (store_troop_faction, ":faction", ":troop"),
          (party_set_faction, ":new_party", ":faction"),
          # (party_set_slot, ":new_party", slot_party_type, spt_bandit_party),
          (party_set_ai_behavior, ":new_party", ai_bhvr_attack_party),
          (party_set_ai_object, ":new_party", "p_main_party"),
		  (party_set_aggressiveness, ":new_party", 15),
          (party_set_courage, ":new_party", 15),
		  (str_store_party_name, s4, ":new_party"),
          (display_log_message, "@The scavenging activities attracted a group of {s4}, they seem willing to attack.",message_alert),
        # (else_try),
          # (display_log_message, "@The scavenging activities attracted a group of {s4}, but they seem to avoid confrontation."),
        (try_end),
      (try_end),
     (try_end),

#empty bottles -> rain
     (try_begin),
       (ge,"$g_camp_mode", 1),
       (eq, "$g_infinite_camping", 0),
       (eq,"$g_rain",1),

        (troop_get_inventory_capacity, ":inv_size", "trp_player"),
        (try_for_range, ":item_slot", 0, ":inv_size"),
          (troop_get_inventory_slot, ":item_no", "trp_player", ":item_slot"),
          (eq, ":item_no", "itm_empty_bottles"),
          (troop_set_inventory_slot, "trp_player", ":item_slot", "itm_water"),
        (try_end),
     (try_end),

#removing gasoline
     (try_begin),
        (neq, "$g_player_icon_state", pis_camping),
        (map_free),

        (is_between,"$g_player_party_icon","icon_map_jeep_beige","icon_map_uruk"),
		(store_distance_to_party_from_party, ":distance_check", "p_main_party", "p_zendar"),
		(neq, "$g_distance_check", ":distance_check"),
		(assign, "$g_distance_check", ":distance_check"),
        (troop_get_inventory_capacity, ":capacity", "trp_player"),
        (try_for_range, ":cur_slot", 0, ":capacity"),
          (troop_get_inventory_slot, ":cur_item", "trp_player", ":cur_slot"),
          (ge, ":cur_item", 0),
          (eq, ":cur_item", "itm_gasoline"),
          (assign, ":capacity", 0),
          (troop_inventory_slot_get_item_amount, ":cur_amount", "trp_player", ":cur_slot"),
          (val_sub, ":cur_amount", 1),
          (troop_inventory_slot_set_item_amount, "trp_player", ":cur_slot", ":cur_amount"),
        (try_end),
     (try_end),

     (try_begin),
        (eq,"$info_sys",1),
        # (party_set_extra_icon, "p_main_party", "icon_player_arrow",100, 100, 100, 100),    #  1,0,1,10),
        (party_set_extra_icon, "p_main_party", "icon_player_arrow",1, 0, 100, 10),    #  1,0,1,10),
     (else_try),
        (party_set_extra_icon, "p_main_party", 0, 0, 0, 0, 0),
     (try_end),



    ]),


(2,
	[
#Error check for multiple parties on the map
     (try_begin),
        (eq, "$cheat_mode", 1),
        (assign, ":debug_menu_noted", 0),
        (try_for_parties, ":party_no"),
            (gt, ":party_no", "p_spawn_points_end"),
            (party_stack_get_troop_id, ":commander", ":party_no", 0),
            ##diplomacy start+
            (is_between, ":commander", heroes_begin, heroes_end),
            (this_or_next|troop_slot_eq, ":commander", slot_troop_occupation, slto_kingdom_hero),
            ##diplomacy end+
            (is_between, ":commander", active_npcs_begin, active_npcs_end),
            (troop_get_slot, ":commander_party", ":commander", slot_troop_leaded_party),
            (str_store_troop_name, s3, ":commander"),
            (try_begin),
              (neq, ":party_no", ":commander_party"),
              (assign, reg4, ":party_no"),
              (assign, reg5, ":commander_party"),

              (display_message, "@{!}{s3} commander of party #{reg4} which is not his troop_leaded party {reg5}"),
              ##diplomacy start+ Make it clear what the error was
              (try_begin),
                (gt, reg4, 0),
                (gt, reg5, 0),
                (str_store_party_name, s3, reg4),
                (str_store_party_name, s65, reg5),
                (display_message, "@{!} Commanded party #{reg4} is {s3}, troop_leaded party #{reg5} is {s65}"),
                (str_store_troop_name, s3, ":commander"),
              (try_end),
              ##diplomacy end+
              (str_store_string, s65, "str_party_with_commander_mismatch__check_log_for_details_"),
            # (else_try), #SB : piggyback to check lord wealth
              # (troop_get_slot, reg3, ":commander", slot_troop_wealth),
              # (le, reg3, 0),
              # (party_get_cur_town, ":town_no", ":party_no"),
              # (try_begin),
                # (is_between, ":town_no", centers_begin, centers_end),
                # (str_store_party_name_link, s2, ":town_no"),
              # (else_try),
                # (str_store_string, s2, "@large"),
              # (try_end),
              # (str_store_string, s65, "@{s3} is bankrupt ({reg3} falors) while at {s2}!"),
            # (try_end),

            # (try_begin),
                (eq, ":debug_menu_noted", 0),
                (call_script, "script_add_notification_menu", "mnu_debug_alert_from_s65", 0, 0),
                (assign, ":debug_menu_noted", 1),
            (try_end),
        (try_end),
     (try_end),

# Process village raids
     (try_begin),
       (call_script, "script_process_village_raids"),
     (try_end),

#Increase fort food stores
     # ##diplomacy start+ Change to vary with village prosperity
     # (try_begin),
         # (lt, "$g_dplmc_gold_changes", DPLMC_GOLD_CHANGES_LOW),
         # ##OLD:
         # #unaltered block begin
         # (try_for_range, ":center_no", castles_begin, castles_end),
           # (party_slot_eq, ":center_no", slot_center_is_besieged_by, -1), #fort is not under siege
           # (party_get_slot, ":center_food_store", ":center_no", slot_party_food_store),
           # (val_add, ":center_food_store", 100),
           # (call_script, "script_center_get_food_store_limit", ":center_no"),
           # (assign, ":food_store_limit", reg0),
           # (val_min, ":center_food_store", ":food_store_limit"),
           # (party_set_slot, ":center_no", slot_party_food_store, ":center_food_store"),
         # (try_end),#unaltered block end
     # (else_try),
         # ##NEW:
         # (try_for_range, ":village_no", villages_begin, villages_end),
            # (neg|party_slot_ge, ":village_no", slot_center_is_besieged_by, 0),
            # (party_slot_eq, ":village_no", slot_village_state, svs_normal),
            # (party_get_slot, ":center_no", ":village_no", slot_village_bound_center),
            # (is_between, ":center_no", castles_begin, castles_end),
            # (neg|party_slot_ge, ":center_no", slot_center_is_besieged_by, 0),
            # (party_get_slot, ":center_food_store", ":center_no", slot_party_food_store),
            # (party_get_slot, reg0, ":village_no", slot_town_prosperity),
            # (val_add, reg0, 75),
            # (val_mul, reg0, 100),#base addition is 100
            # (val_add, reg0, 62),
            # (val_div, reg0, 125),#plus or minus 40%
            # (val_add, ":center_food_store", reg0),
            # (call_script, "script_center_get_food_store_limit", ":center_no"),
            # (assign, ":food_store_limit", reg0),
            # (val_min, ":center_food_store", ":food_store_limit"),
            # (party_set_slot, ":center_no", slot_party_food_store, ":center_food_store"),
         # (try_end),
     # (try_end),

#cara trade
     (try_begin),
        (eq, "$has_traded",2),
        (assign,"$has_traded",0),
     (try_end),

#Update how good a target player is for bandits
     (try_begin),
       (store_troop_gold, ":total_value", "trp_player"),
       (store_div, ":bandit_attraction", ":total_value", (10000/100)), #10000 gold = excellent_target

       (troop_get_inventory_capacity, ":inv_size", "trp_player"),
       (try_for_range, ":i_slot", 0, ":inv_size"),
         (troop_get_inventory_slot, ":item_id", "trp_player", ":i_slot"),
         (ge, ":item_id", 0),
         (try_begin),
           (is_between, ":item_id", trade_goods_begin, trade_goods_end),
           (store_item_value, ":item_value", ":item_id"),
           (val_add, ":total_value", ":item_value"),
         (try_end),
       (try_end),
       (val_clamp, ":bandit_attraction", 0, 100),
       #SB : disallow bandit attraction while raiding villages so they don't join on the "side" of villagers
       (try_begin),
         (is_between, "$g_player_raiding_village", villages_begin, villages_end),
         (assign, ":bandit_attraction", 0),
       (try_end),
       (party_set_bandit_attraction, "p_main_party", ":bandit_attraction"),
     (try_end),

     (try_begin),
     (try_end),

	]),


(3,
   [
# Process siege ai
     (try_begin),
        ##diplomacy start+
      (assign, ":save_reg0", reg0),#Save registers
      (assign, ":save_reg1", reg1),
      ##diplomacy end+
        (store_current_hours, ":cur_hours"),
        (try_for_range, ":center_no", walled_centers_begin, walled_centers_end),
          (party_get_slot, ":besieger_party", ":center_no", slot_center_is_besieged_by),
          (gt, ":besieger_party", 0),
          (party_is_active, ":besieger_party"),
          (store_faction_of_party, ":besieger_faction", ":besieger_party"),
          (party_slot_ge, ":center_no", slot_center_is_besieged_by, 1),
          (party_get_slot, ":siege_begin_hours", ":center_no", slot_center_siege_begin_hours),
          (store_sub, ":siege_begin_hours", ":cur_hours", ":siege_begin_hours"),
          (assign, ":launch_attack", 0),
          (assign, ":call_attack_back", 0),
          (assign, ":attacker_strength", 0),
          (assign, ":marshall_attacking", 0),
          (try_for_range, ":troop_no", active_npcs_begin, active_npcs_end),
            (troop_slot_eq, ":troop_no", slot_troop_occupation, slto_kingdom_hero),
            (neg|troop_slot_ge, ":troop_no", slot_troop_prisoner_of_party, 0),
            (troop_get_slot, ":party_no", ":troop_no", slot_troop_leaded_party),
            (gt, ":party_no", 0),
            (party_is_active, ":party_no"),

            (store_troop_faction, ":troop_faction_no", ":troop_no"),
            (eq, ":troop_faction_no", ":besieger_faction"),
            (assign, ":continue", 0),
            (try_begin),
              (party_slot_eq, ":party_no", slot_party_ai_state, spai_besieging_center),
              (party_slot_eq, ":party_no", slot_party_ai_object, ":center_no"),
              (assign, ":continue", 1),
            (else_try),
              (party_slot_eq, ":party_no", slot_party_ai_state, spai_accompanying_army),
              (party_get_slot, ":commander_party", ":party_no", slot_party_ai_object),
              (gt, ":commander_party", 0),
              (party_is_active, ":commander_party"),
              (party_slot_eq, ":commander_party", slot_party_ai_state, spai_besieging_center),
              (party_slot_eq, ":commander_party", slot_party_ai_object, ":center_no"),
              (assign, ":continue", 1),
            (try_end),
            (eq, ":continue", 1),
            (party_get_battle_opponent, ":opponent", ":party_no"),
            (this_or_next|lt, ":opponent", 0),
            (eq, ":opponent", ":center_no"),
            (try_begin),
              (faction_slot_eq, ":besieger_faction", slot_faction_marshall, ":troop_no"),
              (assign, ":marshall_attacking", 1),
            (try_end),
            (call_script, "script_party_calculate_regular_strength", ":party_no"),
        ##diplomacy start+ terrain advantage
        # (try_begin),
        # (ge, "$g_dplmc_terrain_advantage", DPLMC_TERRAIN_ADVANTAGE_ENABLE),
        # (call_script, "script_dplmc_party_calculate_strength_in_terrain", ":party_no", dplmc_terrain_code_siege, 0, 0),
            # (try_end),
        ##diplomacy end+
            (val_add, ":attacker_strength", reg0),
          (try_end),
          (try_begin),
            (gt, ":attacker_strength", 0),
            (party_collect_attachments_to_party, ":center_no", "p_collective_enemy"),
            (call_script, "script_party_calculate_regular_strength", "p_collective_enemy"),
        ##diplomacy start+ terrain advantage
        # (try_begin),
        # (ge, "$g_dplmc_terrain_advantage", DPLMC_TERRAIN_ADVANTAGE_ENABLE),
        # (call_script, "script_dplmc_party_calculate_strength_in_terrain", "p_collective_enemy", dplmc_terrain_code_siege, 0, 0),
            # (try_end),
        ##diplomacy end+
            (assign, ":defender_strength", reg0),
            (try_begin),
              (eq, "$auto_enter_town", ":center_no"),
              (eq, "$g_player_is_captive", 0),
              (call_script, "script_party_calculate_regular_strength", "p_main_party"),
        ##diplomacy start+ terrain advantage
        # (try_begin),
          # (ge, "$g_dplmc_terrain_advantage", DPLMC_TERRAIN_ADVANTAGE_ENABLE),
          # (call_script, "script_dplmc_party_calculate_strength_in_terrain", "p_collective_enemy", dplmc_terrain_code_siege, 0, 0),
        # (try_end),
        ##diplomacy end+
              (val_add, ":defender_strength", reg0),
              (val_mul, ":attacker_strength", 2), #double the power of attackers if the player is in the campaign
            (try_end),
            (party_get_slot, ":siege_hardness", ":center_no", slot_center_siege_hardness),
            (val_add, ":siege_hardness", 100),
            (val_mul, ":defender_strength", ":siege_hardness"),
            (val_div, ":defender_strength", 100),
            (val_max, ":defender_strength", 1),
            (try_begin),
              (eq, ":marshall_attacking", 1),
              (eq, ":besieger_faction", "$players_kingdom"),
              (check_quest_active, "qst_follow_army"),
              (val_mul, ":attacker_strength", 2), #double the power of attackers if the player is in the campaign
            (try_end),
            (store_mul, ":strength_ratio", ":attacker_strength", 100),
            (val_div, ":strength_ratio", ":defender_strength"),
            (store_sub, ":random_up_limit", ":strength_ratio", 250), #was 300 (1.126)

            (try_begin),
              (gt, ":random_up_limit", -100), #never attack if the strength ratio is less than 150%
              (store_div, ":siege_begin_hours_effect", ":siege_begin_hours", 2), #was 3 (1.126)
              (val_add, ":random_up_limit", ":siege_begin_hours_effect"),
            (try_end),

            (val_div, ":random_up_limit", 5),
            (val_max, ":random_up_limit", 0),
            (store_sub, ":random_down_limit", 175, ":strength_ratio"), #was 200 (1.126)
            (val_max, ":random_down_limit", 0),
            (try_begin),
              (store_random_in_range, ":rand", 0, 100),
              (lt, ":rand", ":random_up_limit"),
              (gt, ":siege_begin_hours", 24),#initial preparation
              (assign, ":launch_attack", 1),
            (else_try),
              (store_random_in_range, ":rand", 0, 100),
              (lt, ":rand", ":random_down_limit"),
              (assign, ":call_attack_back", 1),
            (try_end),
          (else_try),
            (assign, ":call_attack_back", 1),
          (try_end),

          #Assault the fort
          (try_begin),
            (eq, ":launch_attack", 1),
            (call_script, "script_begin_assault_on_center", ":center_no"),
          (else_try),
            (eq, ":call_attack_back", 1),
            (try_for_range, ":troop_no", active_npcs_begin, active_npcs_end),
              (troop_slot_eq, ":troop_no", slot_troop_occupation, slto_kingdom_hero),
              (neg|troop_slot_ge, ":troop_no", slot_troop_prisoner_of_party, 0),
              (troop_get_slot, ":party_no", ":troop_no", slot_troop_leaded_party),
              (gt, ":party_no", 0),
              (party_is_active, ":party_no"),

              (party_slot_eq, ":party_no", slot_party_ai_state, spai_besieging_center),
              (party_slot_eq, ":party_no", slot_party_ai_object, ":center_no"),
              (party_slot_eq, ":party_no", slot_party_ai_substate, 1),
              (call_script, "script_party_set_ai_state", ":party_no", spai_undefined, -1),
              (call_script, "script_party_set_ai_state", ":party_no", spai_besieging_center, ":center_no"),
              #resetting siege begin time if at least 1 party retreats
              (party_set_slot, ":center_no", slot_center_siege_begin_hours, ":cur_hours"),
            (try_end),
          (try_end),
        (try_end),
      ##diplomacy start+
      #Revert registers
      (assign, reg0, ":save_reg0"),
      (assign, reg1, ":save_reg1"),
      ##diplomacy end+
     (try_end),


#This is a backup script to activate the player faction if it doesn't happen automatically, for whatever reason
     (try_begin),
      (try_for_range, ":center", walled_centers_begin, walled_centers_end),
        (faction_slot_eq, "fac_player_supporters_faction", slot_faction_state, sfs_inactive),
        (store_faction_of_party, ":center_faction", ":center"),
        (eq, ":center_faction", "fac_player_supporters_faction"),
        (call_script, "script_activate_player_faction", "trp_player"),
      (try_end),
      ##diplomacy start+
      #Piggyback on this: if the minister somehow gets cleared, or wasn't set
      #automatically, reappoint one.
      (try_begin),
        (is_between, "$players_kingdom", kingdoms_begin, kingdoms_end),
        (le, "$g_player_minister", 0),
        (faction_get_slot, ":faction_leader", "$players_kingdom", slot_faction_leader),
        (ge, ":faction_leader", 0),
        (try_begin),
          (this_or_next|eq, ":faction_leader", "trp_player"),
            (troop_slot_eq, "trp_player", slot_troop_spouse, ":faction_leader"),
          (assign, "$g_player_minister", "trp_temporary_minister"),
          (troop_set_faction, "trp_temporary_minister", "fac_player_supporters_faction"),
        (else_try),
          (is_between, ":faction_leader", heroes_begin, heroes_end),
          (troop_slot_eq, ":faction_leader", slot_troop_spouse, "trp_player"),
          (assign, "$g_player_minister", "trp_temporary_minister"),
          (troop_set_faction, "trp_temporary_minister", "fac_player_supporters_faction"),
        (try_end),
      (try_end),
     (try_end),

#weather correctur
     (try_begin),
        (call_script, "script_cf_weather_change"),
     (try_end),

#check to see if player's court has been captured
     (try_begin),
         ##diplomacy start+ The player might be the ruler of another faction
         (assign, ":save_reg0", reg0),
       (assign, ":alt_led_faction", "fac_player_supporters_faction"),
       (try_begin),
        (is_between, "$players_kingdom", npc_kingdoms_begin, npc_kingdoms_end),
        (call_script, "script_dplmc_get_troop_standing_in_faction", "trp_player", "$players_kingdom"),
          (ge, reg0, DPLMC_FACTION_STANDING_LEADER_SPOUSE),
        (assign, ":alt_led_faction", "$players_kingdom"),
       (try_end),
       ##diplomacy end+
         (try_begin), #The old court has been lost
         ##diplomacy begin
           (is_between, "$g_player_court", centers_begin, centers_end),
           (party_slot_eq, "$g_player_court", slot_village_infested_by_bandits, "trp_peasant_woman"),
           (call_script, "script_add_notification_menu", "mnu_notification_court_lost", 0, 0),
         (else_try),
         ##diplomacy end
           (is_between, "$g_player_court", centers_begin, centers_end),
           (store_faction_of_party, ":court_faction", "$g_player_court"),
           (neq, ":court_faction", "fac_player_supporters_faction"),
         ##diplomacy start+ The player might be ruler of a faction other than fac_player_supporters_faction
         (neq, ":court_faction", ":alt_led_faction"),
         ##diplomacy end+
           (call_script, "script_add_notification_menu", "mnu_notification_court_lost", 0, 0),
         (else_try),	#At least one new court has been found
           (lt, "$g_player_court", centers_begin),
           #Will by definition not active until a center is taken by the player faction
           #Player minister must have been appointed at some point
           (this_or_next|faction_slot_eq, "fac_player_supporters_faction", slot_faction_leader, "trp_player"),
        (gt, "$g_player_minister", 0),

           (assign, ":center_found", 0),
           (try_for_range, ":walled_center", walled_centers_begin, walled_centers_end),
             (eq, ":center_found", 0),
             (store_faction_of_party, ":court_faction", ":walled_center"),
           ##diplomacy start+ The player might be ruler of a faction other than fac_player_supporters_faction
           (this_or_next|eq, ":court_faction", ":alt_led_faction"),
           ##diplomacy end+
             (eq, ":court_faction", "fac_player_supporters_faction"),
             (assign, ":center_found", ":walled_center"),
           (try_end),
           (ge, ":center_found", 1),
           (call_script, "script_add_notification_menu", "mnu_notification_court_lost", 0, 0),
         (try_end),
        #Also, piggy-backing on this -- having bandits go to lairs and back
        (try_for_parties, ":party_no"),
          (gt, ":party_no", "p_spawn_points_end"),
          (party_is_active, ":party_no"),
          (party_get_template_id, ":party_template", ":party_no"),
          (try_begin),
            # (is_between, ":party_template", bandit_party_templates_begin, bandit_party_templates_end), #SB : template range
            # (party_template_get_slot, ":bandit_lair", ":party_template", slot_party_template_lair_party),
            # (try_begin),#If party is active and bandit is far away, then move to location
              # (gt, ":bandit_lair", "p_spawn_points_end"),
              # (store_distance_to_party_from_party, ":distance", ":party_no", ":bandit_lair"), #this is the cause of the error
              # (gt, ":distance", 30),
              # #All this needs checking
              # (party_set_ai_behavior, ":party_no", ai_bhvr_travel_to_point),
              # (party_get_position, pos5, ":bandit_lair"),
              # (party_set_ai_target_position, ":party_no", pos5),
            # (else_try), #Otherwise, act freely
              # (get_party_ai_behavior, ":behavior", ":party_no"),
              # (eq, ":behavior", ai_bhvr_travel_to_point),
              # (try_begin),
                # (gt, ":bandit_lair", "p_spawn_points_end"),
                # (store_distance_to_party_from_party, ":distance", ":party_no", ":bandit_lair"),
                # (lt, ":distance", 3),
                # (party_set_ai_behavior, ":party_no", ai_bhvr_patrol_party),
                # (party_template_get_slot, ":spawnpoint", ":party_template", slot_party_template_lair_spawnpoint),
                # (is_between, ":spawnpoint", "p_steppe_bandit_spawn_point", "p_spawn_points_end"),
                # (party_set_ai_object, ":party_no", ":spawnpoint"),
                # (party_set_ai_patrol_radius, ":party_no", 45),
              # (else_try), #why is this identical behavior?
                # (lt, ":bandit_lair", "p_spawn_points_end"),
                # (party_set_ai_behavior, ":party_no", ai_bhvr_patrol_party),
                # (party_template_get_slot, ":spawnpoint", ":party_template", slot_party_template_lair_spawnpoint),
                # (is_between, ":spawnpoint", "p_steppe_bandit_spawn_point", "p_spawn_points_end"),
                # (party_set_ai_object, ":party_no", ":spawnpoint"),
                # (party_set_ai_patrol_radius, ":party_no", 45),
              # (try_end),
            # (try_end),
          # (else_try), #SB : piggyback to handle reinforcements
            (this_or_next|eq, ":party_template", "pt_center_reinforcements"),
            (eq, ":party_template", "pt_routed_warriors"),
            (party_slot_eq, ":party_no", slot_party_type, spt_reinforcement),
             # (store_distance_to_party_from_party, ":distance", ":cur_center", ":party_no"),
            # (party_get_attached_to, ":cur_attached_town", ":party_no"),
            (party_get_cur_town, ":cur_attached_town", ":party_no"),
             # (this_or_next|lt, ":distance", 3),
            (try_begin),
              (eq, ":party_template", "pt_center_reinforcements"),
              (party_get_slot, ":destination", ":party_no", slot_party_ai_object),
              (neq, ":cur_attached_town", ":destination"),
              (assign, ":cur_attached_town", -1),
              (party_detach, ":party_no"),  # stop and detach
              (party_set_ai_behavior,":party_no",ai_bhvr_travel_to_party),
              (party_set_ai_object,":party_no", ":destination"),
              (party_set_flags, ":party_no", pf_default_behavior, 0),
            (try_end),
            (is_between, ":cur_attached_town", walled_centers_begin, walled_centers_end),
            # (eq, ":cur_attached_town", ":cur_center"),

            (try_begin), #weed out undesirables
              (party_get_num_companion_stacks, ":num_stacks", ":party_no"),
              (store_faction_of_party, ":cur_faction", ":cur_attached_town"),
              (try_begin), #player culture
                (this_or_next|eq, ":cur_faction", "fac_player_faction"),
                (this_or_next|eq, ":cur_faction", "fac_player_supporters_faction"),
                (eq, ":cur_faction", "$players_kingdom"),
                (neg|is_between, ":cur_faction", npc_kingdoms_begin, npc_kingdoms_end),
                (is_between, "$g_player_culture", npc_kingdoms_begin, npc_kingdoms_end),
                (assign, ":cur_faction", "$g_player_culture"),
              (try_end),
              (try_for_range_backwards, ":stack_no", 0, ":num_stacks"),
                (party_stack_get_troop_id, ":troop_no", ":party_no", ":stack_no"),
                (neg|troop_is_hero, ":troop_no"),
                (assign, ":cur_relation", 100),
                (try_begin), #routed parties sometimes contain extraneous units, players may also give random stuff to reinforcements
                  (store_faction_of_troop, ":faction_no", ":troop_no"),
                  (is_between, ":faction_no", npc_kingdoms_begin, npc_kingdoms_end),
				  (neg|faction_slot_eq, ":faction_no", slot_faction_state, sfs_defeated),	#added as defeated faction troops weren't joining garrisons - krag
                  (store_relation, ":cur_relation", ":cur_faction", ":faction_no"),
                (try_end),
                (this_or_next|is_between, ":troop_no", "trp_looter", bandits_end), #looters are easy to route, don't let them rejoin
                (lt, ":cur_relation", 0),

                (party_stack_get_size, ":stack_size", ":party_no", ":stack_no"),
                (party_remove_members, ":party_no", ":troop_no", ":stack_size"),
                (party_add_prisoners, ":party_no", ":troop_no", ":stack_size"),
              (try_end),
            (try_end),
            (call_script, "script_party_add_party", ":cur_attached_town", ":party_no"),
             # (try_begin),
               # (eq, "$cheat_mode", 2),
               # (str_store_party_name, s1, ":party_no"),
               # (str_store_party_name_link, s2, ":cur_center"),
               # (display_log_message, "@active {s1} arrived at {s2}"),
             # (try_end),

            (try_begin), #unset slot before deallocating party
              (eq, ":party_template", "pt_center_reinforcements"),
              (party_get_slot, ":village", ":party_no", slot_party_home_center),
              (party_set_slot, ":village", slot_village_reinforcement_party, -1),
            (try_end),
            (party_detach, ":party_no"),
            (remove_party, ":party_no"),
          (try_end),
        (try_end),
         #Piggybacking on trigger:
         (try_begin),
           (troop_get_slot, ":betrothed", "trp_player", slot_troop_betrothed),
           (gt, ":betrothed", 0),
           (neg|check_quest_active, "qst_wed_betrothed"),
           (neg|check_quest_active, "qst_wed_betrothed_female"),
           (str_store_troop_name, s5, ":betrothed"),
           (display_message, "@Betrothal to {s5} expires"),
           (troop_set_slot, "trp_player", slot_troop_betrothed, -1),
           (troop_set_slot, ":betrothed", slot_troop_betrothed, -1),
         (try_end),
       ##diplomacy start+
       (assign, reg0, ":save_reg0"),#revert register ##diplomacy end+
     (try_end),



     (assign, "$g_player_tournament_placement", 0),

    ]),


(4,
    [
#Locate faction ladies
      #change location for all ladies
     (try_begin),
      (try_for_range, ":troop_id", kingdom_ladies_begin, kingdom_ladies_end),
        ##diplomacy start+ do not set the troop's center when the troop is leading a party
        (troop_slot_eq, ":troop_id", slot_troop_occupation, slto_kingdom_lady),
        (troop_get_slot, ":leaded_party", ":troop_id", slot_troop_leaded_party),
		(try_begin),
			(gt, ":leaded_party", 0),
			(neg|party_is_active, ":leaded_party"),
			(assign, ":leaded_party", -1),
		(try_end),
        (lt, ":leaded_party", 1),#if the value is 0, it's a bug, so overlook it
        ##diplomacy end+
        (neg|troop_slot_ge, ":troop_id", slot_troop_prisoner_of_party, 0),
        (call_script, "script_get_kingdom_lady_social_determinants", ":troop_id"),
        (assign, ":location", reg1),
        (troop_set_slot, ":troop_id", slot_troop_cur_center, ":location"),
      (try_end),
     (try_end),

#reset time to spare
     (try_begin),
         (assign, "$g_time_to_spare", 1),

        (try_begin),
            (troop_slot_ge, "trp_player", slot_troop_spouse, active_npcs_begin),
            (assign, "$g_player_banner_granted", 1),
        (try_end),
     (try_end),

     (try_begin),
     (try_end),
	]),


(6,
   [
#Checking if the troops are resting at a half payment point
    (try_begin),
      (store_current_day, ":cur_day"),
      (try_begin),
        (neq, ":cur_day", "$g_last_half_payment_check_day"),
        (assign, "$g_last_half_payment_check_day", ":cur_day"),
        (try_begin),
          (eq, "$g_half_payment_checkpoint", 1),
          (val_add, "$g_cur_week_half_daily_wage_payments", 1), #half payment for yesterday
        (try_end),
        (assign, "$g_half_payment_checkpoint", 1),
      (try_end),
      (assign, ":resting_at_manor_or_walled_center", 0),
      (try_begin),
        (neg|map_free),
        (is_between, "$g_last_rest_center", centers_begin, centers_end), #SB : proper rest conditions
        (this_or_next|party_slot_eq, "$g_last_rest_center", slot_center_has_manor, 1),
        (is_between, "$g_last_rest_center", walled_centers_begin, walled_centers_end),
        (assign, ":resting_at_manor_or_walled_center", 1),
      (try_end),
      (eq, ":resting_at_manor_or_walled_center", 0),
      (assign, "$g_half_payment_checkpoint", 0),
    (try_end),

# Decide faction ais #it was every 23
    (assign, "$g_recalculate_ais", 1),

# Checking escape chances of prisoners that joined the party recently.
    (try_begin),
      (gt, "$g_prisoner_recruit_troop_id", 0),
      (gt, "$g_prisoner_recruit_size", 0),
      (gt, "$g_prisoner_recruit_last_time", 0),
      (is_currently_night),
      (try_begin),
        (store_skill_level, ":leadership", "skl_leadership", "trp_player"),
        (val_mul, ":leadership", 5),
        (store_sub, ":chance", 66, ":leadership"),
        (gt, ":chance", 0),
        (assign, ":num_escaped", 0),
        (try_for_range, ":unused", 0, "$g_prisoner_recruit_size"),
          (store_random_in_range, ":random_no", 0, 100),
          (lt, ":random_no", ":chance"),
          (val_add, ":num_escaped", 1),
        (try_end),
        (party_remove_members, "p_main_party", "$g_prisoner_recruit_troop_id", ":num_escaped"),
        (assign, ":num_escaped", reg0),
        (gt, ":num_escaped", 0),
        (try_begin),
          (gt, ":num_escaped", 1),
          (assign, reg2, 1),
        (else_try),
          (assign, reg2, 0),
        (try_end),
        (assign, reg1, ":num_escaped"),
        (str_store_troop_name_by_count, s1, "$g_prisoner_recruit_troop_id", ":num_escaped"),
        (display_log_message, "@{reg1} {s1} {reg2?have:has} escaped from your party during the night."),
      (try_end),
      (assign, "$g_prisoner_recruit_troop_id", 0),
      (assign, "$g_prisoner_recruit_size", 0),
    (try_end),

    ]),


(7,
    [
# Decide commander ai
     (try_begin),
      (call_script, "script_init_ai_calculation"),
      #(call_script, "script_decide_kingdom_party_ais"),
	  ##diplomacy start+
	  #Also call script_calculate_troop_ai for faction ladies who have become slto_kingdom_heroes
      #(try_for_range, ":troop_no", active_npcs_begin, active_npcs_end),
	  (try_for_range, ":troop_no", heroes_begin, heroes_end),
	  ##diplomacy end+
        (troop_slot_eq, ":troop_no", slot_troop_occupation, slto_kingdom_hero),
        (call_script, "script_calculate_troop_ai", ":troop_no"),
      (try_end),
     (try_end),

      ]),


(8,
    [
#POLITICAL TRIGGERS
#POLITICAL TRIGGER #1`
    (try_begin),
        (call_script, "script_cf_random_political_event"),

        #Added Nov 2010 begins - do this twice
        (call_script, "script_cf_random_political_event"),
        #Added Nov 2010 ends
        #This generates quarrels and occasional reconciliations and interventions
    (try_end),

#Troop AI: Merchants thinking
    (try_begin),
       (game_get_reduce_campaign_ai, ":reduce_campaign_ai"), #SB : moved this up top
       (val_sub, ":reduce_campaign_ai", 1),
       (val_mul, ":reduce_campaign_ai", 10), #pre-calculate amount
       (try_for_parties, ":party_no"),
         (party_slot_eq, ":party_no", slot_party_type, spt_kingdom_caravan),
         (party_is_in_any_town, ":party_no"),

         (store_faction_of_party, ":merchant_faction", ":party_no"),
         (faction_get_slot, ":num_towns", ":merchant_faction", slot_faction_num_towns),
         (try_begin),
           (this_or_next|eq, ":merchant_faction", "fac_infected"),
	       (this_or_next|eq, ":merchant_faction", "fac_mutants"),
		   (le, ":num_towns", 0),
           (remove_party, ":party_no"),
         (else_try),
           (party_get_cur_town, ":cur_center", ":party_no"),

           (store_random_in_range, ":random_no", 0, 100),
           (assign, ":tariff_succeed_limit", 45), #SB : base amount for medium
           (try_begin),
             (this_or_next|party_slot_eq, ":cur_center", slot_town_lord, "trp_player"),
             (eq, ":merchant_faction", "$players_kingdom"),
             (val_add, ":tariff_succeed_limit", ":reduce_campaign_ai"),
           (try_end),
           # (try_begin),
             # (party_slot_eq, ":cur_center", slot_town_lord, "trp_player"),

             # # (game_get_reduce_campaign_ai, ":reduce_campaign_ai"),
             # (try_begin),
               # (eq, ":reduce_campaign_ai", 0), #hard (less money from tariffs)
               # (assign, ":tariff_succeed_limit", 35),
             # (else_try),
               # (eq, ":reduce_campaign_ai", 1), #medium (normal money from tariffs)
               # (assign, ":tariff_succeed_limit", 45),
             # (else_try),
               # (eq, ":reduce_campaign_ai", 2), #easy (more money from tariffs)
               # (assign, ":tariff_succeed_limit", 60),
             # (try_end),
           # (else_try),
             # (assign, ":tariff_succeed_limit", 45),
           # (try_end),

           (lt, ":random_no", ":tariff_succeed_limit"),

           #SB : todo queue caravans so they don't blob together, obvious if same destination
           (assign, ":can_leave", 1),
           (try_begin),
             (store_faction_of_party, ":cur_center_faction", ":cur_center"),
			 (this_or_next|eq, ":cur_center_faction", "fac_infected"),
	         (eq, ":cur_center_faction", "fac_mutants"),
			 (remove_party, ":party_no"),	#remove caravan if center taken by monsters - krag
			 (assign, ":can_leave", 0),
			(else_try),
			 (is_between, ":cur_center", walled_centers_begin, walled_centers_end),
             (neg|party_slot_eq, ":cur_center", slot_center_is_besieged_by, -1),
             (assign, ":can_leave", 0),
           (try_end),
           (eq, ":can_leave", 1),

           (assign, ":do_trade", 0),
           (try_begin),
             (party_get_slot, ":cur_ai_state", ":party_no", slot_party_ai_state),
             (eq, ":cur_ai_state", spai_trading_with_town),
             (party_get_slot, ":cur_ai_object", ":party_no", slot_party_ai_object),
             (eq, ":cur_center", ":cur_ai_object"),
             (assign, ":do_trade", 1),
           (try_end),

           (assign, ":target_center", -1),

           (try_begin), #Make sure escorted caravan continues to its original destination.
             (eq, "$caravan_escort_state", 1),
             (eq, "$caravan_escort_party_id", ":party_no"), #SB : redo globals here
             (assign, ":caravan_distance_to_player", 9999),
             (try_begin), #code from triggers
               (eq, "$caravan_escort_state", 1),
               (eq, ":cur_center", "$caravan_escort_destination_town"),
               #arrived, check if player is nearby to prompt conversation (unless player triggered dialog first)
               (store_distance_to_party_from_party, ":caravan_distance_to_player","p_main_party","$caravan_escort_party_id"),
               (lt, ":caravan_distance_to_player", 5),
               (map_free), #in case player is fighting?
               (start_encounter, "$caravan_escort_party_id"),
             (else_try),
               (ge, ":caravan_distance_to_player", 5), #cancel quest
               (assign, "$caravan_escort_state", 0),
             (else_try),
               # (neg|party_is_in_town, ":party_no", "$caravan_escort_destination_town"),
               (neq, ":cur_center", "$caravan_escort_destination_town"),
               (assign, ":target_center", "$caravan_escort_destination_town"),
             (try_end),
           (else_try),
            ##diplomacy start+ added third parameter "-1" to use the town's location
             (call_script, "script_cf_select_most_profitable_town_at_peace_with_faction_in_trade_route", ":cur_center", ":merchant_faction", -1),
            ##diplomacy end+
             (assign, ":target_center", reg0),
           (try_end),
           (is_between, ":target_center", towns_begin, towns_end),
           (neg|party_is_in_town, ":party_no", ":target_center"),

           (try_begin),
             (eq, ":do_trade", 1),
             (str_store_party_name, s7, ":cur_center"),
             (call_script, "script_do_merchant_town_trade", ":party_no", ":cur_center"),
           (try_end),
           (party_set_ai_behavior, ":party_no", ai_bhvr_travel_to_party),
           (party_set_ai_object, ":party_no", ":target_center"),
           (party_set_flags, ":party_no", pf_default_behavior, 0),
           (party_set_slot, ":party_no", slot_party_ai_state, spai_trading_with_town),
           (party_set_slot, ":party_no", slot_party_ai_object, ":target_center"),
         (try_end),
       (try_end),
    (try_end),

#Troop AI: Village farmers thinking
    (try_begin),
       (try_for_parties, ":party_no"),
         (party_slot_eq, ":party_no", slot_party_type, spt_village_farmer),
         (party_is_in_any_town, ":party_no"),
         (party_get_slot, ":home_center", ":party_no", slot_party_home_center),
         (party_get_cur_town, ":cur_center", ":party_no"),

         (assign, ":can_leave", 1),
         (try_begin),
           (is_between, ":cur_center", walled_centers_begin, walled_centers_end),
           (neg|party_slot_eq, ":cur_center", slot_center_is_besieged_by, -1),
           (assign, ":can_leave", 0),
         (try_end),
         (eq, ":can_leave", 1),
		 
		 (store_faction_of_party, ":villager_party_faction", ":party_no"),
		 (neq, ":villager_party_faction", "fac_infected"),
		 (neq, ":villager_party_faction", "fac_mutants"),

         (try_begin),
           (eq, ":cur_center", ":home_center"),

		   #Peasants trade in their home center
		   (call_script, "script_do_party_center_trade", ":party_no", ":home_center", 3), #this needs to be the same as the center
		   (store_faction_of_party, ":center_faction", ":cur_center"),
           (party_set_faction, ":party_no", ":center_faction"),
           (party_get_slot, ":market_town", ":home_center", slot_village_market_town),
           (party_set_slot, ":party_no", slot_party_ai_object, ":market_town"),
           (party_set_slot, ":party_no", slot_party_ai_state, spai_trading_with_town),
           (party_set_ai_behavior, ":party_no", ai_bhvr_travel_to_party),
           (party_set_ai_object, ":party_no", ":market_town"),
           #SB : pick up up to 5 spare items in elder's inventory
           (try_begin), #technically we can just sell from the inventory directly and skip all this work
             (ge, "$g_dplmc_gold_changes", DPLMC_GOLD_CHANGES_MEDIUM),
             (party_get_slot, ":town_elder", ":home_center", slot_town_elder),
             (try_begin), #reaccumulate wealth, since we can't store the party's gold use a slot
               (party_get_slot, ":cur_wealth", ":party_no", slot_town_wealth),
               (troop_add_gold, ":town_elder", ":cur_wealth"),
               (party_set_slot, ":party_no", slot_town_wealth, 0),
             (try_end),
             (party_get_slot, ":num_items", ":party_no", slot_party_next_looted_item_slot),
             # (this_or_next|eq, ":num_items", 0),
             (lt, ":num_items", num_party_loot_slots), #not capped
             (val_add, ":num_items", slot_party_looted_item_1),
             (troop_get_inventory_capacity, ":inv_cap", ":town_elder"),
             (try_for_range, ":item_slot", 10, ":inv_cap"),
               (troop_get_inventory_slot, ":item_no", ":town_elder", ":item_slot"),
               (gt, ":item_no", -1),
               (item_get_type, ":itp", ":item_no"),
               (neq, ":itp", itp_type_goods), #whatever crap player sells
               (party_set_slot, ":party_no", ":num_items", ":item_no"),
               (store_add, ":imod_slot", ":num_items", num_party_loot_slots),
               (troop_get_inventory_slot_modifier, ":imod_no", ":town_elder", ":item_slot"),
               (party_set_slot, ":party_no", ":imod_slot", ":imod_no"),
               (troop_set_inventory_slot, ":town_elder", ":item_slot", -1), #remove
               (try_begin), #only 5 permited
                 (ge, ":num_items", slot_party_looted_item_1 + num_party_loot_slots),
                 (assign, ":inv_cap", 0),
               (else_try),
                 (val_add, ":num_items", 1),
               (try_end),
             (try_end),
           (try_end),

         (else_try),
           (try_begin),
             (party_get_slot, ":cur_ai_object", ":party_no", slot_party_ai_object),
             (eq, ":cur_center", ":cur_ai_object"),

             (call_script, "script_do_party_center_trade", ":party_no", ":cur_ai_object", 3), #raised from 10
             (assign, ":total_change", reg0),
		     #This is roughly 50% of what a caravan would pay

             #Adding tariffs to the town
             (party_get_slot, ":accumulated_tariffs", ":cur_ai_object", slot_center_accumulated_tariffs),
             (party_get_slot, ":prosperity", ":cur_ai_object", slot_town_prosperity),

			 (assign, ":tariffs_generated", ":total_change"),
			 (val_mul, ":tariffs_generated", ":prosperity"),
			 ##diplomacy start+
			 (val_add, ":tariffs_generated", 50),#round properly
			 ##diplomacy end+
			 (val_div, ":tariffs_generated", 100),
			 ##diplomacy start+
			 (val_div, ":tariffs_generated", 5),#round properly
			 ##diplomacy end+
			 (val_div, ":tariffs_generated", 20), #10 for caravans, 20 for villages
			 (val_add, ":accumulated_tariffs", ":tariffs_generated"),
			 ##diplomacy begin
        (try_begin), #no tariffs for infested villages and towns
          (party_slot_ge, ":cur_ai_object", slot_village_infested_by_bandits, 1),
          (assign,":accumulated_tariffs", 0),
        (try_end),
	     ##diplomacy end
			 (try_begin),
				(ge, "$cheat_mode", 3),
				(assign, reg4, ":tariffs_generated"),
				(str_store_party_name, s4, ":cur_ai_object"),
				(assign, reg5, ":accumulated_tariffs"),
				(display_message, "@{!}New tariffs at {s4} = {reg4}, total = {reg5}"),
			 (try_end),

             (party_set_slot, ":cur_ai_object", slot_center_accumulated_tariffs, ":accumulated_tariffs"),

             #Increasing food stocks of the town
             (party_get_slot, ":town_food_store", ":cur_ai_object", slot_party_food_store),
             (call_script, "script_center_get_food_store_limit", ":cur_ai_object"),
             (assign, ":food_store_limit", reg0),
             (val_add, ":town_food_store", 1000),
             (val_min, ":town_food_store", ":food_store_limit"),
             (party_set_slot, ":cur_ai_object", slot_party_food_store, ":town_food_store"),

             #Adding 1 to village prosperity
             (try_begin),
               (store_random_in_range, ":rand", 0, 100),
               (lt, ":rand", 5), #was 35
               (call_script, "script_change_center_prosperity", ":home_center", 1),
			   (val_add, "$newglob_total_prosperity_from_village_trade", 1),
             (try_end),
           (try_end),

           #Moving farmers to their home village
           (party_set_slot, ":party_no", slot_party_ai_object, ":home_center"),
           (party_set_slot, ":party_no", slot_party_ai_state, spai_trading_with_town),
           (party_set_ai_behavior, ":party_no", ai_bhvr_travel_to_party),
           (party_set_ai_object, ":party_no", ":home_center"),
         (try_end),
       (try_end),
    (try_end),

#rest ai & morale
    (try_begin),
      (try_for_range, ":troop_no", heroes_begin, heroes_end),#promoted lady support
        (troop_slot_eq, ":troop_no", slot_troop_occupation, slto_kingdom_hero),
        (neq,":troop_no","trp_player"),
        (troop_get_slot, ":party_no", ":troop_no", slot_troop_leaded_party),
        (party_is_active, ":party_no"),

        (store_faction_of_party, ":faction_no", ":party_no"),
        (faction_get_slot, ":faction_marshal", ":faction_no", slot_faction_marshall),
        (neq,":troop_no",":faction_marshal"),

        (party_get_attached_to, ":led_party_attached", ":party_no"),
        (le,":led_party_attached",0),
        (party_get_slot, ":ai_state", ":party_no", slot_party_ai_state),

        (try_begin),
          (party_slot_eq, ":party_no", slot_party_needs_rest, rest_state_0),
          # (neq,":ai_state",spai_besieging_center),
          # (neq,":ai_state",spai_holding_center),
          # (neq,":ai_state",spai_engaging_army),
          # (neq,":ai_state",spai_accompanying_army),
          # (neq,":ai_state",spai_screening_army),
          # # (neq,":ai_state",spai_visiting_village),
          # (neq,":ai_state",spai_retreating_to_center),
          # # (neq,":ai_state",spai_trading_with_town),
          # # (neq,":ai_state",spai_raiding_around_center),
          # # (neq,":ai_state",spai_patrolling_around_center),
          (party_set_slot, ":party_no", slot_party_needs_rest, rest_state_1),
        (else_try),
          (party_slot_eq, ":party_no", slot_party_needs_rest, rest_state_1),

          (neq,":ai_state",spai_besieging_center),
          (neq,":ai_state",spai_holding_center),
          (neq,":ai_state",spai_engaging_army),
          (neq,":ai_state",spai_accompanying_army),
          (neq,":ai_state",spai_screening_army),
          # (neq,":ai_state",spai_visiting_village),
          (neq,":ai_state",spai_retreating_to_center),
          # (neq,":ai_state",spai_trading_with_town),
          # (neq,":ai_state",spai_raiding_around_center),
          # (neq,":ai_state",spai_patrolling_around_center),

          (party_set_slot, ":party_no", slot_party_needs_rest, rest_state_2),
          (call_script, "script_change_party_morale", ":party_no", 1),
        (else_try),
          (party_slot_eq, ":party_no", slot_party_needs_rest, rest_state_3),
          (party_set_slot, ":party_no", slot_party_needs_rest, rest_state_0),
        (else_try),
          (this_or_next|eq,":ai_state",spai_besieging_center),
          (this_or_next|eq,":ai_state",spai_engaging_army),
          (this_or_next|eq,":ai_state",spai_accompanying_army),
          (eq,":ai_state",spai_screening_army),

          (call_script, "script_change_party_morale", ":party_no", -1),
        (else_try),
          (eq,":ai_state",spai_retreating_to_center),

          (call_script, "script_change_party_morale", ":party_no", -5),
        (try_end),
      (try_end),
    (else_try),
      (try_for_range, ":troop_no", heroes_begin, heroes_end),#promoted lady support
        (troop_slot_eq, ":troop_no", slot_troop_occupation, slto_kingdom_hero),
        (neq,":troop_no","trp_player"),
        (troop_get_slot, ":party_no", ":troop_no", slot_troop_leaded_party),
        (party_is_active, ":party_no"),

        (store_faction_of_party, ":faction_no", ":party_no"),
        (faction_get_slot, ":faction_marshal", ":faction_no", slot_faction_marshall),
        (eq,":troop_no",":faction_marshal"),

        (party_get_attached_to, ":led_party_attached", ":party_no"),
        (le,":led_party_attached",0),

        (party_slot_ge, ":party_no", slot_party_needs_rest, rest_state_1),
        (party_set_slot, ":party_no", slot_party_needs_rest, rest_state_0),
      (try_end),        
    (try_end),

#map conditions (only night)
     (try_begin),
        (is_currently_night),
        (call_script,"script_map_conditions"),
     (try_end),
	]),

# Checking center upgrades
(12,
   [
   (try_for_range, ":center_no", centers_begin, centers_end),
      (party_get_slot, ":cur_improvement", ":center_no", slot_center_current_improvement),
      (gt, ":cur_improvement", 0),
      (party_get_slot, ":cur_improvement_end_time", ":center_no", slot_center_improvement_end_hour),
      (store_current_hours, ":cur_hours"),
      (ge, ":cur_hours", ":cur_improvement_end_time"),
      (party_set_slot, ":center_no", ":cur_improvement", 1),
      (party_set_slot, ":center_no", slot_center_current_improvement, 0),
      (call_script, "script_get_improvement_details", ":cur_improvement"),
      (try_begin),
        (party_slot_eq, ":center_no", slot_town_lord, "trp_player"),
        (str_store_party_name, s4, ":center_no"),
        (display_log_message, "@Building of {s0} in {s4} has been completed."),
      (try_end),
      (try_begin),
        (is_between, ":center_no", villages_begin, villages_end),
        (try_begin),
          (eq, ":cur_improvement", slot_center_has_fish_pond),
          (call_script, "script_change_center_prosperity", ":center_no", 5),
        (else_try), #SB : show garrison for debug
          (eq, ":cur_improvement", slot_center_has_manor),
          (party_set_flags, ":center_no", pf_hide_defenders, 0),
        # (else_try),
          # (eq, ":cur_improvement", slot_center_has_messenger_post),
        (try_end),
      (try_end),
   (try_end),

   #SB : moved up
   (try_for_range, ":village", villages_begin, villages_end),
      (party_set_slot, ":village", dplmc_slot_village_reserved_by_recruiter, 0),
   (try_end),

# Removing cattle herds if they are way out of range
   (try_for_parties, ":cur_party"),
      (party_slot_eq, ":cur_party", slot_party_type, spt_cattle_herd),
      (store_distance_to_party_from_party, ":dist",":cur_party", "p_main_party"),
      (try_begin),
        (gt, ":dist", 30),
        (remove_party, ":cur_party"),
        (try_begin),
          #Fail quest if the party is the quest party
          (check_quest_active, "qst_move_cattle_herd"),
          (neg|check_quest_concluded, "qst_move_cattle_herd"),
          (quest_slot_eq, "qst_move_cattle_herd", slot_quest_target_party, ":cur_party"),
          (call_script, "script_fail_quest", "qst_move_cattle_herd"),
        (try_end),
      (else_try),
        (gt, ":dist", 10),
        (party_set_slot, ":cur_party", slot_cattle_driven_by_player, 0),
        (party_set_ai_behavior, ":cur_party", ai_bhvr_hold),
      (try_end),
   (try_end),

   (try_begin),
    (neg|check_quest_active, "qst_wanted_fugitive"),
    (assign, "$g_wanted_quest_completed", 0),
    (call_script, "script_setup_wanted_fugitive_quest"),
   (try_end),

    ]),


# Consuming / survival
(14,
   [
    (eq, "$g_player_is_captive", 0),
#hunger
    (try_begin),
        (try_begin),
          (assign, ":number_of_foods_player_has", 0),
          (try_for_range, ":cur_edible", food_begin, food_end),
            (call_script, "script_cf_player_has_item_without_modifier", ":cur_edible", imod_rotten),
            (val_add, ":number_of_foods_player_has", 1),
          (try_end),
          (try_begin),
            (ge, ":number_of_foods_player_has", 6),
            (unlock_achievement, ACHIEVEMENT_ABUNDANT_FEAST),
          (try_end),
        (try_end),

        # (assign, ":consumption_amount", ":num_men"),
        (assign, ":no_food_displayed", 0),
        # (try_for_range, ":unused", 0, ":consumption_amount"),
        (assign, ":available_food", 0),
        (try_for_range, ":cur_food", food_begin, food_end),
            (item_set_slot, ":cur_food", slot_item_is_checked, 0),
            (call_script, "script_cf_player_has_item_without_modifier", ":cur_food", imod_rotten),
            (val_add, ":available_food", 1),
        (try_end),
        (try_begin),
            (troop_slot_ge, "trp_player", slot_troop_condition_hunger, 100),
            (troop_get_slot, ":hunger", "trp_player", slot_troop_condition_hunger),
            (val_sub,":hunger",25),
            (troop_set_slot,"trp_player", slot_troop_condition_hunger, ":hunger"),
        (else_try),
            (gt, ":available_food", 0),

            (store_random_in_range, ":selected_food", 0, ":available_food"),
            # (call_script, "script_consume_food", ":selected_food"),
            (troop_get_inventory_capacity, ":capacity", "trp_player"),
            (try_for_range, ":cur_slot", 0, ":capacity"),
                (troop_get_inventory_slot, ":cur_item", "trp_player", ":cur_slot"),
                (is_between, ":cur_item", food_begin, food_end),
                # (troop_get_inventory_slot_modifier, ":item_modifier", "trp_player", ":cur_slot"),
                # (neq, ":item_modifier", imod_rotten),
                (item_slot_eq, ":cur_item", slot_item_is_checked, 0),
                (item_set_slot, ":cur_item", slot_item_is_checked, 1),
                (val_sub, ":selected_food", 1),
                (lt, ":selected_food", 0),
                (assign, ":capacity", 0),
                (troop_inventory_slot_get_item_amount, ":cur_amount", "trp_player", ":cur_slot"),
                (val_sub, ":cur_amount", 1),
                (troop_inventory_slot_set_item_amount, "trp_player", ":cur_slot", ":cur_amount"),

                (item_get_food_quality,":food_bonus", ":cur_item"),
                (val_div,":food_bonus",10),
                # (item_set_slot, ":food", slot_troop_food_bonus, ":food_bonus"),
                (troop_set_slot, "trp_player", slot_troop_food_bonus,":food_bonus"),

                (troop_get_slot, ":hunger", "trp_player", slot_troop_condition_hunger),
                (val_add,":hunger",25),
                (troop_set_slot,"trp_player", slot_troop_condition_hunger, ":hunger"),

            (try_end),
        (else_try),
            (eq, ":no_food_displayed", 0),
            (display_message, "@You have nothing to eat!", message_defeated), #SB : same colour const
            # (call_script, "script_change_player_party_morale", -3),
            (assign, ":no_food_displayed", 1),

            (troop_get_slot, ":hunger", "trp_player", slot_troop_condition_hunger),
            (val_sub,":hunger",25),
            (troop_set_slot,"trp_player", slot_troop_condition_hunger, ":hunger"),
            (troop_set_slot, "trp_player", slot_troop_food_bonus,0),
        (try_end),
    (try_end),
#thirst
    (try_begin),
        (assign, ":no_drink_displayed", 0),
        (assign, ":available_drink", 0),
        (try_for_range, ":cur_drink", drink_begin, drink_end),
            (item_set_slot, ":cur_drink", slot_item_is_checked, 0),
            (call_script, "script_cf_player_has_item_without_modifier", ":cur_drink", imod_rotten),
            (val_add, ":available_drink", 1),
        (try_end),
        (try_begin),
            (troop_slot_ge, "trp_player", slot_troop_condition_thirst, 100),
            (troop_get_slot, ":thurst", "trp_player", slot_troop_condition_thirst),
            (val_sub,":thurst",25),
            (troop_set_slot,"trp_player", slot_troop_condition_thirst, ":thurst"),
        (else_try),
            (gt, ":available_drink", 0),

            (store_random_in_range, ":selected_drink", 0, ":available_drink"),
            (troop_get_inventory_capacity, ":capacity", "trp_player"),
            (try_for_range, ":cur_slot", 0, ":capacity"),
                (troop_get_inventory_slot, ":cur_item", "trp_player", ":cur_slot"),
                (is_between, ":cur_item", drink_begin, drink_end),
                # (troop_get_inventory_slot_modifier, ":item_modifier", "trp_player", ":cur_slot"),
                # (neq, ":item_modifier", imod_rotten),
                (item_slot_eq, ":cur_item", slot_item_is_checked, 0),
                (item_set_slot, ":cur_item", slot_item_is_checked, 1),
                (val_sub, ":selected_drink", 1),
                (lt, ":selected_drink", 0),
                (assign, ":capacity", 0),
                (troop_inventory_slot_get_item_amount, ":cur_amount", "trp_player", ":cur_slot"),
                (val_sub, ":cur_amount", 1),
                (troop_inventory_slot_set_item_amount, "trp_player", ":cur_slot", ":cur_amount"),

                # (troop_get_slot, ":bonus", "trp_player", slot_troop_food_bonus),
                # (item_get_food_quality,":food_bonus", ":cur_item"),
                # (store_add,":new_bonus",":bonus",":food_bonus"),
                # (val_div,":new_bonus",10),
                # # (item_set_slot, ":food", slot_troop_food_bonus, ":food_bonus"),
                # (troop_set_slot, "trp_player", slot_troop_food_bonus,":new_bonus"),

                (troop_get_slot, ":thurst", "trp_player", slot_troop_condition_thirst),
                (val_add,":thurst",25),
                (troop_set_slot,"trp_player", slot_troop_condition_thirst, ":thurst"),
            (try_end),
        (else_try),
            (eq, ":no_drink_displayed", 0),
            (display_message, "@You have nothing to drink!", message_defeated), #SB : same colour const
            # (call_script, "script_change_player_party_morale", -3),
            (assign, ":no_drink_displayed", 1),

            (troop_get_slot, ":thurst", "trp_player", slot_troop_condition_thirst),
            (val_sub,":thurst",25),
            (troop_set_slot,"trp_player", slot_troop_condition_thirst, ":thurst"),
        (try_end),
    (try_end),

    ]),


(24,
    [
     (try_begin),
        (try_for_range, ":kingdom_no", npc_kingdoms_begin, npc_kingdoms_end),
          (faction_get_slot, ":faction_morale", ":kingdom_no",  slot_faction_morale_of_player_troops),

          (store_sub, ":divisor", 140, "$player_right_to_rule"),
          (val_div, ":divisor", 14),
          (val_max, ":divisor", 1),

          (store_div, ":faction_morale_div_10", ":faction_morale", ":divisor"), #10 is the base, down to 2 for 100 rtr
          (val_sub, ":faction_morale", ":faction_morale_div_10"),

          (faction_set_slot, ":kingdom_no",  slot_faction_morale_of_player_troops, ":faction_morale"),
        (try_end),
     (try_end),

#Kingdom ladies send messages
	(try_begin),
		(neg|check_quest_active, "qst_visit_lady"),
		(neg|troop_slot_ge, "trp_player", slot_troop_prisoner_of_party, 1),
		(neg|troop_slot_ge, "trp_player", slot_troop_spouse, active_npcs_begin),

		(assign, ":lady_not_visited_longest_time", -1),
		(assign, ":longest_time_without_visit", 120), #five days

		(try_for_range, ":troop_id", kingdom_ladies_begin, kingdom_ladies_end),
            ##diplomacy start not dead, exiled, etc.
			(neg|troop_slot_ge, ":troop_id", slot_troop_occupation, slto_retirement),
            #not already betrothed
            (neg|troop_slot_eq, "trp_player", slot_troop_betrothed, ":troop_id"),
			##diplomacy end
			#set up message for ladies the player is courting
			(troop_slot_ge, ":troop_id", slot_troop_met, 2),
			(neg|troop_slot_eq, ":troop_id", slot_troop_met, 4),

			(troop_slot_eq, ":troop_id", slot_lady_no_messages, 0),
			(troop_slot_eq, ":troop_id", slot_troop_spouse, -1),

			(troop_get_slot, ":location", ":troop_id", slot_troop_cur_center),
			(is_between, ":location", walled_centers_begin, walled_centers_end),
			(call_script, "script_troop_get_relation_with_troop", "trp_player", ":troop_id"),
			(gt, reg0, 1),

			(store_current_hours, ":hours_since_last_visit"),
			(troop_get_slot, ":last_visit_hour", ":troop_id", slot_troop_last_talk_time),
			(val_sub, ":hours_since_last_visit", ":last_visit_hour"),

			(gt, ":hours_since_last_visit", ":longest_time_without_visit"),
			(assign, ":longest_time_without_visit", ":hours_since_last_visit"),
			(assign, ":lady_not_visited_longest_time", ":troop_id"),
			(assign, ":visit_lady_location", ":location"),

		(try_end),

		(try_begin),
			(gt, ":lady_not_visited_longest_time", 0),
			(call_script, "script_add_notification_menu", "mnu_notification_lady_requests_visit", ":lady_not_visited_longest_time", ":visit_lady_location"),
		(try_end),
	(try_end),

# Oath fulfilled -- ie, mercenary contract expired?
     (try_begin),
      (le, "$auto_menu", 0),
      (gt, "$players_kingdom", 0),
      (neq, "$players_kingdom", "fac_player_supporters_faction"),
      (eq, "$player_has_homage", 0),

	  (troop_get_slot, ":player_spouse", "trp_player", slot_troop_spouse),

	  #A player bound to a faction by marriage will not have the contract expire. This should no longer be the case, as I've counted wives as having homage, but is in here as a fallback
	  (assign, ":player_has_marriage_in_faction", 0),
	  (try_begin),
		(is_between, ":player_spouse", active_npcs_begin, active_npcs_end),
		(store_faction_of_troop, ":spouse_faction", ":player_spouse"),
		(eq, ":spouse_faction", "$players_kingdom"),
	    (assign, ":player_has_marriage_in_faction", 1),
	  (try_end),
	  (eq, ":player_has_marriage_in_faction", 0),

      (store_current_day, ":cur_day"),
      (gt, ":cur_day", "$mercenary_service_next_renew_day"),
      (jump_to_menu, "mnu_oath_fulfilled"),
     (try_end),

# Banner selection menu
     (try_begin),
        (eq, "$g_player_banner_granted", 1),
        (troop_slot_eq, "trp_player", slot_troop_banner_scene_prop, 0),
        (le,"$auto_menu",0),
        #normal_banner_begin
        (start_presentation, "prsnt_banner_selection"),
        #custom_banner_begin
        #    (start_presentation, "prsnt_custom_banner"),
     (try_end),

# Party Morale: Move morale towards target value.
     (try_begin),
      (call_script, "script_get_player_party_morale_values"),
      (assign, ":target_morale", reg0),
      (party_get_morale, ":cur_morale", "p_main_party"),
      (store_sub, ":dif", ":target_morale", ":cur_morale"),
      (store_div, ":dif_to_add", ":dif", 5),
      (store_mul, ":dif_to_add_correction", ":dif_to_add", 5),
      (try_begin),#finding ceiling of the value
        (neq, ":dif_to_add_correction", ":dif"),
        (try_begin),
          (gt, ":dif", 0),
          (val_add, ":dif_to_add", 1),
        (else_try),
          (val_sub, ":dif_to_add", 1),
        (try_end),
      (try_end),
      (val_add, ":cur_morale", ":dif_to_add"),
      (party_set_morale, "p_main_party", ":cur_morale"),
     (try_end),

#Hiring men with hero wealths (once a day)
#Hiring men with center wealths (once a day)
     (try_begin),
       #SB : move this unscoped variable up
         (options_get_campaign_ai, ":reduce_campaign_ai"),
         ##diplomacy start+
         ##change to allow promoted faction ladies to hire troops
         #(try_for_range, ":troop_no", active_npcs_begin, active_npcs_end),
         (try_for_range, ":troop_no", active_npcs_begin, kingdom_ladies_end),
         ##diplomacy end+
           (troop_slot_eq, ":troop_no", slot_troop_occupation, slto_kingdom_hero),
           (troop_get_slot, ":party_no", ":troop_no", slot_troop_leaded_party),
           (ge, ":party_no", 1),
           (party_is_active, ":party_no"),
           (party_get_attached_to, ":cur_attached_party", ":party_no"),
           (is_between, ":cur_attached_party", centers_begin, centers_end),
           (party_slot_eq, ":cur_attached_party", slot_center_is_besieged_by, -1), #center not under siege

           (store_faction_of_party, ":party_faction", ":party_no"),
           (try_begin),
             (this_or_next|eq, ":party_faction", "fac_player_supporters_faction"),
             (eq, ":party_faction", "$players_kingdom"),
             (assign, ":num_hiring_rounds", 1),
             (store_random_in_range, ":random_value", 0, 2),
             (val_add, ":num_hiring_rounds", ":random_value"),
           (else_try),
             # (game_get_reduce_campaign_ai, ":reduce_campaign_ai"),
             (try_begin),
               (eq, ":reduce_campaign_ai", 0), #hard (2x reinforcing)
               (assign, ":num_hiring_rounds", 2),
             (else_try),
               (eq, ":reduce_campaign_ai", 1), #medium (1x or 2x reinforcing)
               (assign, ":num_hiring_rounds", 1),
               (store_random_in_range, ":random_value", 0, 2),
               (val_add, ":num_hiring_rounds", ":random_value"),
             (else_try),
               (eq, ":reduce_campaign_ai", 2), #easy (1x reinforcing)
               (assign, ":num_hiring_rounds", 1),
             (try_end),
           (try_end),

           (try_begin),
             (faction_slot_eq,  ":party_faction", slot_faction_marshall, ":troop_no"),
             (val_add, ":num_hiring_rounds", 1),
           (try_end),

           (try_for_range, ":unused", 0, ":num_hiring_rounds"),
             (call_script, "script_hire_men_to_kingdom_hero_party", ":troop_no"), #Hiring men with current wealth
           (try_end),
         (try_end),

          (try_for_range, ":center_no", walled_centers_begin, walled_centers_end),
           # (neg|party_slot_eq, ":center_no", slot_town_lord, "trp_player"), #center does not belong to player.
           #SB : useless condition
            (party_slot_ge, ":center_no", slot_town_lord, active_npcs_begin), #center belongs to someone.
            (party_slot_eq, ":center_no", slot_center_is_besieged_by, -1), #center not under siege

            (store_faction_of_party, ":center_faction", ":center_no"),
            ##diplomacy start+ Player culture cleanup (do this once here, instead of separately for each type)
            (try_begin),
              (gt, ":center_faction", "fac_commoners"),
              (this_or_next|eq, ":center_faction", "fac_player_faction"),
              (this_or_next|eq, ":center_faction", "fac_player_supporters_faction"),
              (eq, ":center_faction", "$players_kingdom"),
              (neg|is_between, ":center_faction", npc_kingdoms_begin, npc_kingdoms_end),
              (is_between, "$g_player_culture", npc_kingdoms_begin, npc_kingdoms_end),
              (assign, ":center_faction", "$g_player_culture"),
            (try_end),
            ##diplomacy end+

            (try_begin),
              (this_or_next|eq, ":center_faction", "fac_player_supporters_faction"),
              (eq, ":center_faction", "$players_kingdom"),
              (assign, ":reinforcement_cost", reinforcement_cost_moderate),
              (assign, ":num_hiring_rounds", 1),#player's center is already excluded
            (else_try),
             # (game_get_reduce_campaign_ai, ":reduce_campaign_ai"),
              (assign, ":reinforcement_cost", reinforcement_cost_moderate),
              (try_begin),
                (eq, ":reduce_campaign_ai", 0), #hard (1x or 2x reinforcing)
                (assign, ":reinforcement_cost", reinforcement_cost_hard),
                (store_random_in_range, ":num_hiring_rounds", 0, 2),
                (val_add, ":num_hiring_rounds", 1),
              (else_try),
                (eq, ":reduce_campaign_ai", 1), #moderate (1x reinforcing)
                (assign, ":reinforcement_cost", reinforcement_cost_moderate),
                (assign, ":num_hiring_rounds", 1),
              (else_try),
                (eq, ":reduce_campaign_ai", 2), #easy (none or 1x reinforcing)
                (assign, ":reinforcement_cost", reinforcement_cost_easy),
                (store_random_in_range, ":num_hiring_rounds", 0, 2),
              (try_end),
            (try_end),
            #SB : initial budget to top
            (party_get_slot, ":cur_wealth", ":center_no", slot_town_wealth),

            (faction_get_slot, ":pt_a", ":center_faction", slot_faction_reinforcements_a),
            (faction_get_slot, ":pt_b", ":center_faction", slot_faction_reinforcements_b),
            (faction_get_slot, ":pt_c", ":center_faction", slot_faction_reinforcements_c),
            # do village reinforcement loops
            (try_for_range, ":village_reinforcements", villages_begin, villages_end),

              (gt, ":num_hiring_rounds", 0),
              (party_slot_eq, ":village_reinforcements", slot_village_state, svs_normal), ## Not if the village is being raided or is looted
              (party_slot_eq, ":village_reinforcements", slot_village_bound_center, ":center_no"),
              (store_div, ":hiring_budget", ":cur_wealth", 2),
              (gt, ":hiring_budget", ":reinforcement_cost"),

              (party_get_slot, ":result", ":village_reinforcements", slot_village_reinforcement_party),
              (try_begin), #inactive, etc
                (this_or_next|le, ":result", 0),
                (neg|party_is_active, ":result"),
                (spawn_around_party, ":village_reinforcements", "pt_center_reinforcements"),
                (assign, ":result", reg0),
              (try_end),
              # (party_get_num_companions, ":num_companions", ":result"), #should be 0, unless this is run before current party reaches there
              # (lt, ":num_companions", 25),

              (store_random_in_range, ":rand", 0, 100),
              (try_begin),
                (is_between, ":center_faction", kingdoms_begin, kingdoms_end),
                (faction_get_slot, ":dplmc_quality", ":center_faction", dplmc_slot_faction_quality),
                (val_clamp, ":dplmc_quality", -3, 4),
                (val_add, ":rand", ":dplmc_quality"),
                # (val_clamp, ":rand", 0, 101),
              (try_end),

              # (try_begin),
                # (is_between, ":rand", 0, 45),  ## Get weakest template
                # (party_add_template, ":result", ":pt_a"),
              # (else_try),
                # (is_between, ":rand", 40, 85), ## Get stronger template
                # (party_add_template, ":result", ":pt_b"),
              # (else_try),
                # (ge, ":rand", 85), ## Get strongest template
                # (party_add_template, ":result", ":pt_c"),
              # (try_end),

              (try_begin),
                (lt, ":rand", 65),
                (party_add_template, ":result", ":pt_a"),
              (else_try),
                (lt, ":rand", 100),
                (party_add_template, ":result", ":pt_b"),
              (else_try), #small chance based on faction quality
                (party_add_template, ":result", ":pt_c"),
              (try_end),
              #one reinforcement per village at a time
              (try_begin), #a new party
                (neg|party_slot_eq, ":village_reinforcements", slot_village_reinforcement_party, ":result"),
                (party_set_faction, ":result", ":center_faction"),
                (party_set_slot, ":result", slot_party_type, spt_reinforcement),
                (party_set_slot, ":result", slot_party_ai_object, ":center_no"),
                (party_set_slot, ":result", slot_party_home_center, ":village_reinforcements"),
                (party_set_slot, ":village_reinforcements", slot_village_reinforcement_party, ":result"),
                (str_store_party_name, s5, ":village_reinforcements"),
                (party_set_name, ":result", "str_s5_reinf"),
                # (call_script, "script_party_name_associate", ":result", ":village_reinforcements"),
                (party_set_ai_behavior,":result", ai_bhvr_travel_to_party),
                (party_set_ai_object,":result", ":center_no"),
                (party_set_flags, ":result", pf_default_behavior, 1),
              (try_end),
              (val_sub, ":cur_wealth", ":reinforcement_cost"),
              (val_sub, ":num_hiring_rounds", 1),
            (try_end),
            (try_for_range, ":unused", 0, ":num_hiring_rounds"),
              (store_div, ":hiring_budget", ":cur_wealth", 2),
              (gt, ":hiring_budget", ":reinforcement_cost"),
              (call_script, "script_cf_reinforce_party", ":center_no"),
              (val_sub, ":cur_wealth", ":reinforcement_cost"),
              (party_set_slot, ":center_no", slot_town_wealth, ":cur_wealth"),
            (try_end),
           #SB : move to bottom
            (party_set_slot, ":center_no", slot_town_wealth, ":cur_wealth"),
          (try_end),

         #this is moved up from below , from a 24 x 15 slot to a 24 slot
         (try_for_range, ":center_no", centers_begin, centers_end),
           (store_random_in_range, ":random", 0, 30),
           (le, ":random", 10),

           (call_script, "script_get_center_ideal_prosperity", ":center_no"),
           (assign, ":ideal_prosperity", reg0),
           (party_get_slot, ":prosperity", ":center_no", slot_town_prosperity),
           (try_begin),
             (eq, ":random", 0), #with 3% probability it will gain +10/-10 prosperity even it has higher prosperity than its ideal prosperity.
             (try_begin),
               (store_random_in_range, ":random", 0, 2),
               (try_begin),
                 (eq, ":random", 0),
                 # (neg|is_between, ":center_no", castles_begin, castles_end), #forts always gain positive prosperity from surprise income to balance their prosperity.
                 (call_script, "script_change_center_prosperity", ":center_no", -10),
                 (val_add, "$newglob_total_prosperity_from_convergence", -10),
               (else_try),
                 (call_script, "script_change_center_prosperity", ":center_no", 10),
                 (val_add, "$newglob_total_prosperity_from_convergence", 10),
               (try_end),
             (try_end),
           (else_try),
             (gt, ":prosperity", ":ideal_prosperity"),
             (call_script, "script_change_center_prosperity", ":center_no", -1),
             (val_add, "$newglob_total_prosperity_from_convergence", -1),
           (else_try),
             (lt, ":prosperity", ":ideal_prosperity"),
             (call_script, "script_change_center_prosperity", ":center_no", 1),
             (val_add, "$newglob_total_prosperity_from_convergence", 1),
           (try_end),
         (try_end),
     (try_end),

#diplomatic indices
     (try_begin),
       (call_script, "script_randomly_start_war_peace_new", 1),

       (try_begin),
            (store_random_in_range, ":acting_village", villages_begin, villages_end),
            (store_random_in_range, ":target_village", villages_begin, villages_end),
            (store_faction_of_party, ":acting_faction", ":acting_village"),
            (store_faction_of_party, ":target_faction", ":target_village"), #target faction receives the provocation
            (neq, ":acting_village", ":target_village"),
            (neq, ":acting_faction", ":target_faction"),

            (call_script, "script_diplomacy_faction_get_diplomatic_status_with_faction", ":target_faction", ":acting_faction"),
            (eq, reg0, 0),

            (try_begin),
                (party_slot_eq, ":acting_village", slot_center_original_faction, ":target_faction"),

                (call_script, "script_add_notification_menu", "mnu_notification_border_incident", ":acting_village", -1),
            (else_try),
                (party_slot_eq, ":acting_village", slot_center_ex_faction, ":target_faction"),

                (call_script, "script_add_notification_menu", "mnu_notification_border_incident", ":acting_village", -1),

            (else_try),
                (set_fixed_point_multiplier, 1),
                (store_distance_to_party_from_party, ":distance", ":acting_village", ":target_village"),
                (lt, ":distance", 25),

                (call_script, "script_add_notification_menu", "mnu_notification_border_incident", ":acting_village", ":target_village"),
            (try_end),
       (try_end),

       (try_for_range, ":faction_1", kingdoms_begin, kingdoms_end),
            (faction_slot_eq, ":faction_1", slot_faction_state, sfs_active),
            (try_for_range, ":faction_2", kingdoms_begin, kingdoms_end),
                (neq, ":faction_1", ":faction_2"),
                (faction_slot_eq, ":faction_2", slot_faction_state, sfs_active),

                #remove provocations
                (store_add, ":slot_truce_days", ":faction_2", slot_faction_truce_days_with_factions_begin),
                (val_sub, ":slot_truce_days", kingdoms_begin),
                (faction_get_slot, ":truce_days", ":faction_1", ":slot_truce_days"),
                (try_begin),
                    (ge, ":truce_days", 1),
                    (try_begin),
                        (eq, ":truce_days", 1),
                        (call_script, "script_update_faction_notes", ":faction_1"),
                        (lt, ":faction_1", ":faction_2"),
                        (call_script, "script_add_notification_menu", "mnu_notification_truce_expired", ":faction_1", ":faction_2"),
                    ##diplomacy begin
            ##nested diplomacy start+ Replace "magic numbers" with named constants
            (else_try),
              (eq, ":truce_days", dplmc_treaty_alliance_days_expire + 1),#replaced 61
              (call_script, "script_update_faction_notes", ":faction_1"),
              (lt, ":faction_1", ":faction_2"),
              (call_script, "script_add_notification_menu", "mnu_dplmc_notification_alliance_expired", ":faction_1", ":faction_2"),
            (else_try),
              (eq, ":truce_days",dplmc_treaty_defense_days_expire + 1),#replaced 41
              (call_script, "script_update_faction_notes", ":faction_1"),
              (lt, ":faction_1", ":faction_2"),
              (call_script, "script_add_notification_menu", "mnu_dplmc_notification_defensive_expired", ":faction_1", ":faction_2"),
            (else_try),
              (eq, ":truce_days", dplmc_treaty_trade_days_expire + 1),#replaced 21
              (call_script, "script_update_faction_notes", ":faction_1"),
              (lt, ":faction_1", ":faction_2"),
              (call_script, "script_add_notification_menu", "mnu_dplmc_notification_trade_expired", ":faction_1", ":faction_2"),
            ##nested diplomacy end+
            ##diplomacy end
                    (try_end),
                    (val_sub, ":truce_days", 1),
                    (faction_set_slot, ":faction_1", ":slot_truce_days", ":truce_days"),
                (try_end),

                (store_add, ":slot_provocation_days", ":faction_2", slot_faction_provocation_days_with_factions_begin),
                (val_sub, ":slot_provocation_days", kingdoms_begin),
                (faction_get_slot, ":provocation_days", ":faction_1", ":slot_provocation_days"),
                (try_begin),
                    (ge, ":provocation_days", 1),
                    (try_begin),#factions already at war
                        (store_relation, ":relation", ":faction_1", ":faction_2"),
                        (lt, ":relation", 0),
                        (faction_set_slot, ":faction_1", ":slot_provocation_days", 0),
                    (else_try), #Provocation expires
                        (eq, ":provocation_days", 1),
                        (call_script, "script_add_notification_menu", "mnu_notification_casus_belli_expired", ":faction_1", ":faction_2"),
                        (faction_set_slot, ":faction_1", ":slot_provocation_days", 0),
                    (else_try),
                        (val_sub, ":provocation_days", 1),
                        (faction_set_slot, ":faction_1", ":slot_provocation_days", ":provocation_days"),
                    (try_end),
                (try_end),

                (try_begin), #at war
                    (store_relation, ":relation", ":faction_1", ":faction_2"),
                    (lt, ":relation", 0),
                    (store_add, ":slot_war_damage", ":faction_2", slot_faction_war_damage_inflicted_on_factions_begin),
                    (val_sub, ":slot_war_damage", kingdoms_begin),
                    (faction_get_slot, ":war_damage", ":faction_1", ":slot_war_damage"),
                    (val_add, ":war_damage", 1),
                    (faction_set_slot, ":faction_1", ":slot_war_damage", ":war_damage"),
                (try_end),

            (try_end),
            (call_script, "script_update_faction_notes", ":faction_1"),
        (try_end),
     (try_end),

# Process sieges
     (try_begin),
       (call_script, "script_process_sieges"),
     (try_end),

     (try_begin),
        ##diplomacy start+ Add support for promoted faction ladies
        ##OLD:
        #(try_for_range, ":kingdom_hero", active_npcs_begin, active_npcs_end),
        ##NEW:
        (try_for_range, ":kingdom_hero", heroes_begin, heroes_end),
            (this_or_next|is_between, ":kingdom_hero", active_npcs_begin, active_npcs_end),
            (troop_slot_eq, ":kingdom_hero", slot_troop_occupation, slto_kingdom_hero),
        ##diplomacy end+
            (troop_get_slot, ":impatience", ":kingdom_hero", slot_troop_intrigue_impatience),
            (val_sub, ":impatience", 5),
            (val_max, ":impatience", 0),
            (troop_set_slot, ":kingdom_hero", slot_troop_intrigue_impatience, ":impatience"),
        (try_end),

        (store_random_in_range, ":controversy_deduction", 1, 3),
        (val_min, ":controversy_deduction", 2),
    #	(assign, ":controversy_deduction", 1),

        #This reduces controversy by one each round
        ##diplomacy start+ Add support for promoted faction ladies
        ##OLD:
        #(try_for_range, ":active_npc", active_npcs_begin, active_npcs_end),
        ##NEW:
        (try_for_range, ":active_npc", heroes_begin, heroes_end),
            (this_or_next|is_between, ":active_npc", active_npcs_begin, active_npcs_end),
            (troop_slot_eq, ":active_npc", slot_troop_occupation, slto_kingdom_hero),
            (neg|main_party_has_troop, ":active_npc"),
            # (neg|troop_slot_eq, ":active_npc", slot_troop_occupation, slto_player_companion), #SB : no controversy decay
        ##diplomacy end+
            (troop_get_slot, ":controversy", ":active_npc", slot_troop_controversy),
            (ge, ":controversy", 1),
            (val_sub, ":controversy", ":controversy_deduction"),
            (val_max, ":controversy", 0),
            (troop_set_slot, ":active_npc", slot_troop_controversy, ":controversy"),
        (try_end),

        (troop_get_slot, ":controversy", "trp_player", slot_troop_controversy),
        (val_sub, ":controversy", ":controversy_deduction"),
        (val_max, ":controversy", 0),
        (troop_set_slot, "trp_player", slot_troop_controversy, ":controversy"),
     (try_end),

# Count faction armies #SB : moved to faction defeat check
     (try_begin),
        ##diplomacy start+ Add support for promoted faction ladies
        ##OLD:
        #(try_for_range, ":active_npc", active_npcs_begin, active_npcs_end),
        ##NEW:
        (try_for_range, ":active_npc", heroes_begin, heroes_end),
          (this_or_next|is_between, ":active_npc", active_npcs_begin, active_npcs_end),
          (troop_slot_eq, ":active_npc", slot_troop_occupation, slto_kingdom_hero),
          ##diplomacy end+
          (store_faction_of_troop, ":active_npc_faction", ":active_npc"),
          (neg|faction_slot_eq, ":active_npc_faction", slot_faction_ai_state, sfai_default),
          (neg|faction_slot_eq, ":active_npc_faction", slot_faction_ai_state, sfai_feast),
          (neg|faction_slot_eq, ":active_npc_faction", slot_faction_ai_state, sfai_gathering_army),

          (troop_get_slot, ":active_npc_party", ":active_npc", slot_troop_leaded_party),
          (party_is_active, ":active_npc_party"),

          (val_add, "$total_vassal_days_on_campaign", 1),

          (party_slot_eq, ":active_npc_party", slot_party_ai_state, spai_accompanying_army),
          (val_add, "$total_vassal_days_responding_to_campaign", 1),
        (try_end),
     (try_end),

# Spawn village farmer parties
     (try_begin),
       (try_for_range, ":village_no", villages_begin, villages_end),
         (party_slot_eq, ":village_no", slot_village_state, svs_normal),
         (party_get_slot, ":farmer_party", ":village_no", slot_village_farmer_party),
         (this_or_next|eq, ":farmer_party", 0),
         (neg|party_is_active, ":farmer_party"),
         (store_random_in_range, ":random_no", 0, 100),
         (lt, ":random_no", 10), #tocan 60
         # (lt, ":random_no", 60),
         (call_script, "script_create_village_farmer_party", ":village_no"),
         (party_set_slot, ":village_no", slot_village_farmer_party, reg0),
#         (str_store_party_name, s1, ":village_no"),
#         (display_message, "@Village farmers created at {s1}."),
       (try_end),
     (try_end),

# Offering ransom fees for player's prisoner heroes
     (try_begin),
      (neq, "$g_ransom_offer_rejected", 1),
      (call_script, "script_offer_ransom_amount_to_player_for_prisoners_in_party", "p_main_party"),
      (eq, reg0, 0),#no prisoners offered
      (assign, ":end_cond", walled_centers_end),
      #SB : TODO also offer ransom for spouse/co-ruler's owned centers
      (try_for_range, ":center_no", walled_centers_begin, ":end_cond"),
        (party_slot_eq, ":center_no", slot_town_lord, "trp_player"),
        (call_script, "script_offer_ransom_amount_to_player_for_prisoners_in_party", ":center_no"),
        (eq, reg0, 1),#a prisoner is offered
        (assign, ":end_cond", 0),#break
      (try_end),
     (try_end),

# Setting random walker types
     (try_begin),
      (call_script, "script_update_other_taverngoers"),

      (try_for_range, ":center_no", centers_begin, centers_end),
        (this_or_next|party_slot_eq, ":center_no", slot_party_type, spt_town),
        (             party_slot_eq, ":center_no", slot_party_type, spt_village),
        (call_script, "script_center_remove_walker_type_from_walkers", ":center_no", walkert_needs_money),
        (call_script, "script_center_remove_walker_type_from_walkers", ":center_no", walkert_needs_money_helped),
        (store_random_in_range, ":rand", 0, 100),
        (try_begin),
          (lt, ":rand", 70),
          (neg|party_slot_ge, ":center_no", slot_town_prosperity, 60),
          (call_script, "script_cf_center_get_free_walker", ":center_no"),
          (call_script, "script_center_set_walker_to_type", ":center_no", reg0, walkert_needs_money),
        (try_end),
      (try_end),
     (try_end),

# Adding tournaments to towns
# Adding bandits to towns and villages
     (try_begin),
        # (assign, ":num_active_tournaments", 0),
        # (try_for_range, ":center_no", towns_begin, towns_end),
          # (party_get_slot, ":has_tournament", ":center_no", slot_town_has_tournament),
          # (try_begin),
            # (eq, ":has_tournament", 1),#tournament ended, simulate
            # (call_script, "script_fill_tournament_participants_troop", ":center_no", 0),
            # (call_script, "script_sort_tournament_participant_troops"),#may not be needed
            # (call_script, "script_get_num_tournament_participants"),
            # (store_sub, ":needed_to_remove_randomly", reg0, 1),
            # (call_script, "script_remove_tournament_participants_randomly", ":needed_to_remove_randomly"),
            # (call_script, "script_sort_tournament_participant_troops"),
            # (troop_get_slot, ":winner_troop", "trp_tournament_participants", 0),
            # (try_begin),
              # (is_between, ":winner_troop", active_npcs_begin, active_npcs_end),
              # (str_store_troop_name_link, s1, ":winner_troop"),
              # (str_store_party_name_link, s2, ":center_no"),
              # #SB : log message, change color, add money
              # (display_log_message, "@{s1} has won the tournament at {s2}.", message_alert),
              # (call_script, "script_change_troop_renown", ":winner_troop", dplmc_tournament_renown),
              # (try_begin),
                # (ge, "$g_dplmc_gold_changes", DPLMC_GOLD_CHANGES_MEDIUM),
                # (store_faction_of_party, ":center_faction", ":center_no"),
                # (call_script, "script_dplmc_get_troop_standing_in_faction", ":winner_troop", ":center_faction"),
                # (store_mul, ":reward", reg0, dplmc_tournament_renown), #1200 for leader, 600 for lord etc
                # (val_add, ":reward", 150),
                # (call_script, "script_dplmc_distribute_gold_to_lord_and_holdings", ":reward", ":winner_troop"), #add some wealth
              # (else_try),
                # (call_script, "script_dplmc_distribute_gold_to_lord_and_holdings", 200, ":winner_troop"), #add some wealth
              # (try_end),
            # (try_end),
          # (try_end),
          # (val_sub, ":has_tournament", 1),
          # (val_max, ":has_tournament", 0),
          # (party_set_slot, ":center_no", slot_town_has_tournament, ":has_tournament"),
          # (try_begin),
            # (gt, ":has_tournament", 0),
            # (val_add, ":num_active_tournaments", 1),
          # (try_end),
        # (try_end),

        (try_for_range, ":center_no", centers_begin, centers_end),
          (this_or_next|party_slot_eq, ":center_no", slot_party_type, spt_town),
          (party_slot_eq, ":center_no", slot_party_type, spt_village),
          (party_get_slot, ":has_bandits", ":center_no", slot_center_has_bandits),
          (try_begin),
            (le, ":has_bandits", 0),
            (assign, ":continue", 0),
            (try_begin),
              (check_quest_active, "qst_deal_with_night_bandits"),
              (quest_slot_eq, "qst_deal_with_night_bandits", slot_quest_target_center, ":center_no"),
              (neg|check_quest_succeeded, "qst_deal_with_night_bandits"),
              (assign, ":continue", 1),
            (else_try),
              (store_random_in_range, ":random_no", 0, 100),
              (lt, ":random_no", 3),
              (assign, ":continue", 1),
            (try_end),

            ## SB : add variety to night bandits
            (try_begin),
              (eq, ":continue", 1),
              (call_script, "script_center_get_bandits", ":center_no", 1),
              (assign, ":bandit_troop", reg0),
              (party_set_slot, ":center_no", slot_center_has_bandits, ":bandit_troop"),
              (try_begin),
                (eq, "$cheat_mode", 1),
                (str_store_party_name, s1, ":center_no"),
                (str_store_troop_name_plural, s2, ":bandit_troop"),
                (display_message, "@{!}{s1} is infested by {s2} (at night)."),
              (try_end),
            (try_end),
          (else_try),
            (try_begin),
              (assign, ":random_chance", 40),
              (try_begin),
                (party_slot_eq, ":center_no", slot_party_type, spt_town),
                (assign, ":random_chance", 20),
              (try_end),
              (store_random_in_range, ":random_no", 0, 100),
              (lt, ":random_no", ":random_chance"),
              (party_set_slot, ":center_no", slot_center_has_bandits, 0),
              (try_begin),
                (eq, "$cheat_mode", 1),
                (str_store_party_name, s1, ":center_no"),
                (display_message, "@{s1} is no longer infested by bandits (at night)."),
              (try_end),
            (try_end),
          (try_end),
        (try_end),

        # (try_for_range, ":faction_no", kingdoms_begin, kingdoms_end),
        # (faction_slot_eq, ":faction_no", slot_faction_ai_state, sfai_feast),

        # (faction_get_slot, ":faction_object", ":faction_no", slot_faction_ai_object),
        # (is_between, ":faction_object", towns_begin, towns_end),

        # (party_slot_ge, ":faction_object", slot_town_has_tournament, 1),
        # #continue holding tournaments during the feast
          # (party_set_slot, ":faction_object", slot_town_has_tournament, 2),
        # (try_end),

      # (try_begin),
          # (lt, ":num_active_tournaments", 3),
          # (store_random_in_range, ":random_no", 0, 100),
          # #Add new tournaments with a 30% chance if there are less than 3 tournaments going on
          # (lt, ":random_no", 30),
          # (store_random_in_range, ":random_town", towns_begin, towns_end),
          # (store_random_in_range, ":random_days", 12, 15),
          # (party_set_slot, ":random_town", slot_town_has_tournament, ":random_days"),
          # (try_begin),
            # (eq, "$cheat_mode", 1),
            # (str_store_party_name, s1, ":random_town"),
            # (display_message, "@{!}{s1} is holding a tournament."),
          # (try_end),
        # (try_end),
     (try_end),

# Make parties larger as game progresses.
     (try_begin),
       (call_script, "script_update_party_creation_random_limits"),
     (try_end),

# Check if a faction is defeated every day
     (try_begin),
      (assign, ":num_active_factions", 0),
      (try_for_range, ":cur_kingdom", kingdoms_begin, kingdoms_end),
        (faction_set_slot, ":cur_kingdom", slot_faction_number_of_parties, 0),
      (try_end),
      (try_for_parties, ":cur_party"),
        (store_faction_of_party, ":party_faction", ":cur_party"),
        (is_between, ":party_faction", kingdoms_begin, kingdoms_end),
        (this_or_next|is_between, ":cur_party", centers_begin, centers_end),
        (party_slot_eq, ":cur_party", slot_party_type, spt_kingdom_hero_party),
        (faction_get_slot, ":kingdom_num_parties", ":party_faction", slot_faction_number_of_parties),
        (val_add, ":kingdom_num_parties", 1),
        (faction_set_slot, ":party_faction", slot_faction_number_of_parties, ":kingdom_num_parties"),
      (try_end),
      (try_for_range, ":cur_kingdom", kingdoms_begin, kingdoms_end),
        #(try_begin),
          #(eq, "$cheat_mode", 1),
          #(str_store_faction_name, s1, ":cur_kingdom"),
          #(faction_get_slot, reg1, ":cur_kingdom", slot_faction_number_of_parties),
          #(display_message, "@{!}Number of parties belonging to {s1}: {reg1}"),
        #(try_end),

        (faction_slot_eq, ":cur_kingdom", slot_faction_state, sfs_active),
        #SB : moved strength + stability call every 24 hrs
        (call_script, "script_faction_recalculate_strength", ":cur_kingdom"),
        (call_script, "script_evaluate_realm_stability", ":cur_kingdom"),
        (val_add, ":num_active_factions", 1),
        (faction_slot_eq, ":cur_kingdom", slot_faction_number_of_parties, 0),
        (assign, ":faction_removed", 0),
        (try_begin),
          (eq, ":cur_kingdom", "fac_player_supporters_faction"),
          (try_begin),
            (le, "$supported_pretender", 0),
            (faction_set_slot, ":cur_kingdom", slot_faction_state, sfs_inactive),
            (assign, ":faction_removed", 1),
          (try_end),
        (else_try),
          (neq, "$players_kingdom", ":cur_kingdom"),
          (faction_set_slot, ":cur_kingdom", slot_faction_state, sfs_defeated),
          (try_for_parties, ":cur_party"),
            (store_faction_of_party, ":party_faction", ":cur_party"),
            (eq, ":party_faction", ":cur_kingdom"),
            (party_get_slot, ":home_center", ":cur_party", slot_party_home_center),
            (store_faction_of_party, ":home_center_faction", ":home_center"),
            (party_set_faction, ":cur_party", ":home_center_faction"),
          (try_end),
          # (assign, ":kingdom_pretender", -1),
          # (try_for_range, ":cur_pretender", pretenders_begin, pretenders_end),
            # (troop_slot_eq, ":cur_pretender", slot_troop_original_faction, ":cur_kingdom"),
            # (assign, ":kingdom_pretender", ":cur_pretender"),
          # (try_end),
          # (try_begin),
            # (is_between, ":kingdom_pretender", pretenders_begin, pretenders_end),
            # (neq, ":kingdom_pretender", "$supported_pretender"),
            # (troop_set_slot, ":kingdom_pretender", slot_troop_cur_center, 0), #remove pretender from the world
          # (try_end),
          (assign, ":faction_removed", 1),
          (try_begin),
            (eq, "$players_oath_renounced_against_kingdom", ":cur_kingdom"),
            (assign, "$players_oath_renounced_against_kingdom", 0),
            (assign, "$players_oath_renounced_given_center", 0),
            (assign, "$players_oath_renounced_begin_time", 0),
            (call_script, "script_add_notification_menu", "mnu_notification_oath_renounced_faction_defeated", ":cur_kingdom", 0),
          (try_end),
          #This menu must be at the end because faction banner will change after this menu if the player's supported pretender's original faction is cur_kingdom
          (call_script, "script_add_notification_menu", "mnu_notification_faction_defeated", ":cur_kingdom", 0),

          # (try_begin), #SB : morale dumped
            # (this_or_next|neg|is_between, "$supported_pretender", pretenders_begin, pretenders_end),
            # (neq, "$supported_pretender_old_faction", ":cur_kingdom"),
            (call_script, "script_change_faction_troop_morale", ":cur_kingdom", -5000, 0),
          # (try_end),
        (try_end),
        (try_begin),
          (eq, ":faction_removed", 1),
          (val_sub, ":num_active_factions", 1),
          #(call_script, "script_store_average_center_value_per_faction"),
        (try_end),
        (try_for_range, ":cur_kingdom_2", kingdoms_begin, kingdoms_end),
          (call_script, "script_update_faction_notes", ":cur_kingdom_2"),
        (try_end),
      (try_end),
      (try_begin),
        (eq, ":num_active_factions", 1),
        (eq, "$g_one_faction_left_notification_shown", 0),
        (assign, "$g_one_faction_left_notification_shown", 1),
        (try_for_range, ":cur_kingdom", kingdoms_begin, kingdoms_end),
          (faction_slot_eq, ":cur_kingdom", slot_faction_state, sfs_active),
          (call_script, "script_add_notification_menu", "mnu_notification_one_faction_left", ":cur_kingdom", 0),
        (try_end),
      (try_end),
     (try_end),

     (try_begin),
     (try_end),

    ]),


# Offer player to join faction
# Only if the player is male -- female characters will be told that they should seek out a faction through NPCs, possibly
(32,
   [
     (eq, "$players_kingdom", 0),
     (le, "$g_invite_faction", 0),
     (eq, "$g_player_is_captive", 0),
	 ##diplomacy start+ Use script for gender
	 #(troop_get_type, ":type", "trp_player"),
	 (assign, ":type", "$character_gender"),#<-- this should have been set correctly during character creation
	 ##diplomacy end+
	 (try_begin),
	    ##diplomacy start+ In reduced prejudice mode, female players get the same offers.
		(lt, "$g_disable_condescending_comments", 2),
		##diplomacy end+
		(eq, ":type", tf_woman),
		(eq, "$npc_with_sisterly_advice", 0),
		##diplomacy start+  Make the order less predictable (used below) #SB : fix range
		(store_sub, ":range", companions_end, companions_begin),
		(store_random_in_range, ":random", 0, ":range"),
		##diplomacy end+
		(try_for_range, ":npc", companions_begin, companions_end),
			##diplomacy start+ Make the order less predictable
			(val_add, ":npc", ":random"),
			(try_begin), #SB : fix range
				(ge, ":npc", companions_end),
				(val_sub, ":npc", ":range"),
			(try_end),
			##diplomacy end+
			(main_party_has_troop, ":npc"),
			##diplmacy start+ Use a script for gender
			##OLD:
			#(troop_get_type, ":npc_type", ":npc"),
			#(eq, ":npc_type", 1),
			##NEW:
			# (assign, ":npc_type", 0),
			# (try_begin),
				(call_script, "script_cf_dplmc_troop_is_female", ":npc"),
				# (assign, ":npc_type", 1),
			# (try_end),
			# (eq, ":npc_type", ":type"),
			##diplomacy end+
			(troop_slot_ge, "trp_player", slot_troop_renown, dplmc_command_renown_limit), #SB : const / 2
			(troop_slot_ge, ":npc", slot_troop_woman_to_woman_string, 1),
			(assign, "$npc_with_sisterly_advice", ":npc"),
		(try_end),
	 (else_try),
	     (store_random_in_range, ":kingdom_no", npc_kingdoms_begin, npc_kingdoms_end),
	     (assign, ":min_distance", 999999),
	     (try_for_range, ":center_no", walled_centers_begin, walled_centers_end),
	       (store_faction_of_party, ":center_faction", ":center_no"),
	       (eq, ":center_faction", ":kingdom_no"),
	       (store_distance_to_party_from_party, ":cur_distance", "p_main_party", ":center_no"),
	       (val_min, ":min_distance", ":cur_distance"),
	     (try_end),
	     (lt, ":min_distance", 30),
	     (store_relation, ":kingdom_relation", ":kingdom_no", "fac_player_supporters_faction"),
	     (faction_get_slot, ":kingdom_lord", ":kingdom_no", slot_faction_leader),
	     (call_script, "script_troop_get_player_relation", ":kingdom_lord"),
	     (assign, ":lord_relation", reg0),
	     #(troop_get_slot, ":lord_relation", ":kingdom_lord", slot_troop_player_relation),
	     (call_script, "script_get_number_of_hero_centers", "trp_player"),
	     (assign, ":num_centers_owned", reg0),
	     (eq, "$g_infinite_camping", 0),

	     (assign, ":player_party_size", 0),
	     (try_begin),
	       (ge, "p_main_party", 0),
	       (store_party_size_wo_prisoners, ":player_party_size", "p_main_party"),
	     (try_end),

	     (try_begin),
	       (eq, ":num_centers_owned", 0),
	       (troop_get_slot, ":player_renown", "trp_player", slot_troop_renown),
	       (ge, ":player_renown", 160),
	       (ge, ":kingdom_relation", 0),
	       (ge, ":lord_relation", 0),
	       (ge, ":player_party_size", 45),
	       (store_random_in_range, ":rand", 0, 100),
	       (lt, ":rand", 50),
	       (call_script, "script_get_poorest_village_of_faction", ":kingdom_no"),
	       (assign, "$g_invite_offered_center", reg0),
	       (ge, "$g_invite_offered_center", 0),
	       (assign, "$g_invite_faction", ":kingdom_no"),
	       (jump_to_menu, "mnu_invite_player_to_faction"),
	     (else_try),
	       (gt, ":num_centers_owned", 0),
	       (neq, "$players_oath_renounced_against_kingdom", ":kingdom_no"),
	       (ge, ":kingdom_relation", -40),
	       (ge, ":lord_relation", -20),
	       (ge, ":player_party_size", 30),
	       (store_random_in_range, ":rand", 0, 100),
	       (lt, ":rand", 20),
	       (assign, "$g_invite_faction", ":kingdom_no"),
	       (assign, "$g_invite_offered_center", -1),
	       (jump_to_menu, "mnu_invite_player_to_faction_without_center"),
	     (try_end),
	 (try_end),
    ]),


# Reset hero quest status
# Change hero relation
(36,
   [
     (try_for_range, ":troop_no", heroes_begin, heroes_end),
       (troop_set_slot, ":troop_no", slot_troop_does_not_give_quest, 0),
     (try_end),

     (try_for_range, ":troop_no", village_elders_begin, village_elders_end),
       (troop_set_slot, ":troop_no", slot_troop_does_not_give_quest, 0),
     (try_end),

# Spawn some bandits.
     (try_begin),
       (call_script, "script_spawn_templates"),
       (call_script, "script_sort_created_party"),
       #SB : clean up looters a bit, especially ones running away
       (try_for_parties, ":party_no"),
         (party_is_active, ":party_no"),
         (party_get_template_id, ":cur_party_template", ":party_no"),
         # (this_or_next|eq, ":cur_party_template", "pt_looters"),
         (eq, ":cur_party_template", "pt_looters"),
         # (eq, ":cur_party_template", "pt_leaded_looters"), #in case player lets them run away
         # (neq, ":party_no", ":spawned_party_id"),
         (get_party_ai_behavior, ":bhvr", ":party_no"),
         (eq, ":bhvr", ai_bhvr_avoid_party), #running away
         (get_party_ai_object, ":object", ":party_no"),
         (is_between, ":object", centers_begin, centers_end), #not being chased
         (party_set_ai_behavior, ":party_no", ai_bhvr_patrol_party),
         (party_set_ai_patrol_radius, ":party_no", 22), #half bandit lair radius
       (try_end),
     (try_end),

    ]),


(48,
   [
# Give some xp to hero parties
     (try_begin),
       ##diplomacy start+
       ##change to allow promoted faction ladies to hire troops
       #(try_for_range, ":troop_no", active_npcs_begin, active_npcs_end),
       (try_for_range, ":troop_no", heroes_begin, heroes_end),
       ##diplomacy end+
         (troop_slot_eq, ":troop_no", slot_troop_occupation, slto_kingdom_hero),

         (troop_get_slot, ":hero_party", ":troop_no", slot_troop_leaded_party),
         (gt, ":hero_party", centers_end),
         (party_is_active, ":hero_party"),

         (store_skill_level, ":trainer_level", skl_trainer, ":troop_no"),
         (val_add, ":trainer_level", 5), #average trainer level is 3 for npc lords, worst : 0, best : 6
         (store_mul, ":xp_gain", ":trainer_level", 1000), #xp gain in two days of period for each lord, average : 8000.

         (assign, ":max_accepted_random_value", 30),
         (try_begin),
           (store_troop_faction, ":cur_troop_faction", ":troop_no"),
           (neq, ":cur_troop_faction", "$players_kingdom"),

           (game_get_reduce_campaign_ai, ":reduce_campaign_ai"),
           (try_begin),
             (eq, ":reduce_campaign_ai", 0), #hard (1.5x)
             (assign, ":max_accepted_random_value", 35),
             (val_mul, ":xp_gain", 3),
             (val_div, ":xp_gain", 2),
           (else_try),
             (eq, ":reduce_campaign_ai", 2), #easy (0.5x)
             (assign, ":max_accepted_random_value", 25),
             (val_div, ":xp_gain", 2),
           (try_end),
         (try_end),

         (store_random_in_range, ":rand", 0, 100),
         (le, ":rand", ":max_accepted_random_value"),

         (party_upgrade_with_xp, ":hero_party", ":xp_gain"),
       (try_end),

       (try_for_range, ":center_no", walled_centers_begin, walled_centers_end),
         (party_get_slot, ":center_lord", ":center_no", slot_town_lord),
         (neq, ":center_lord", "trp_player"),

         (assign, ":xp_gain", 3000), #xp gain in two days of period for each center, average : 3000.

         (assign, ":max_accepted_random_value", 30),
         (try_begin),
           (assign, ":cur_center_lord_faction", -1),
           (try_begin),
             (ge, ":center_lord", 0),
             (store_troop_faction, ":cur_center_lord_faction", ":center_lord"),
           (try_end),
           (neq, ":cur_center_lord_faction", "$players_kingdom"),

           (game_get_reduce_campaign_ai, ":reduce_campaign_ai"),
           (try_begin),
             (eq, ":reduce_campaign_ai", 0), #hard (1.5x)
             (assign, ":max_accepted_random_value", 35),
             (val_mul, ":xp_gain", 3),
             (val_div, ":xp_gain", 2),
           (else_try),
             (eq, ":reduce_campaign_ai", 2), #easy (0.5x)
             (assign, ":max_accepted_random_value", 25),
             (val_div, ":xp_gain", 2),
           (try_end),
         (try_end),

         (store_random_in_range, ":rand", 0, 100),
         (le, ":rand", ":max_accepted_random_value"),

         (party_upgrade_with_xp, ":center_no", ":xp_gain"),
       (try_end),
     (try_end),

#Refreshing village defenders
#Clearing slot_village_player_can_not_steal_cattle flags
     (try_begin),
      (try_for_range, ":village_no", villages_begin, villages_end),
        (call_script, "script_refresh_village_defenders", ":village_no"),
        (party_set_slot, ":village_no", slot_village_player_can_not_steal_cattle, 0),
      (try_end),
     (try_end),

# Check escape chances of hero prisoners.
     (try_begin),
         (assign, ":chance", hero_escape_from_player_chance), #50
         (try_begin),  #SB : use consts and apply skill
           (store_skill_level, ":skill", "skl_prisoner_management", "trp_player"),
           (val_sub, ":chance", ":skill"), #50 to 35
         (try_end), #also chance is /1000 not /100
         (call_script, "script_randomly_make_prisoner_heroes_escape_from_party", "p_main_party", ":chance"),
         (try_for_range, ":center_no", walled_centers_begin, walled_centers_end),
  ##         (party_slot_eq, ":center_no", slot_town_lord, "trp_player"),
           (assign, ":chance", hero_escape_from_center_chance),
           (try_begin),
             (party_slot_eq, ":center_no", slot_center_has_prisoner_tower, 1),
             (assign, ":chance", hero_escape_from_tower_chance),
           (try_end),
           (call_script, "script_randomly_make_prisoner_heroes_escape_from_party", ":center_no", ":chance"),
         (try_end),
     (try_end),

# Respawn hero party after faction hero is released from captivity.
     (try_begin),
         ##diplomacy start+ Support promoted faction ladies
         ##OLD:
         #(try_for_range, ":troop_no", active_npcs_begin, active_npcs_end),
         ##NEW:
          (try_for_range, ":troop_no", heroes_begin, heroes_end),
         ##diplomacy end+
           (troop_slot_eq, ":troop_no", slot_troop_occupation, slto_kingdom_hero),

           (str_store_troop_name, s1, ":troop_no"),

           (neg|troop_slot_ge, ":troop_no", slot_troop_prisoner_of_party, 0),
           (neg|troop_slot_ge, ":troop_no", slot_troop_leaded_party, 1),

           (store_troop_faction, ":cur_faction", ":troop_no"),
           (try_begin),
             (this_or_next|eq, ":cur_faction", "fac_outlaws"), #Do nothing
             (eq, ":cur_faction", "fac_commoners"), #Do nothing
           (else_try), #dckplmc
           # (else_try), #SB : faction must be active to spawn
             (is_between, ":cur_faction", kingdoms_begin, kingdoms_end),
             (faction_slot_eq, ":cur_faction", slot_faction_state, sfs_active),
             (try_begin),
               (eq, "$cheat_mode", 2),
               (str_store_troop_name, s4, ":troop_no"),
               (display_message, "str_debug__attempting_to_spawn_s4"),
             (try_end),

             (call_script, "script_cf_select_random_walled_center_with_faction_and_owner_priority_no_siege", ":cur_faction", ":troop_no"),#Can fail
             (assign, ":center_no", reg0),

             (try_begin),
               (eq, "$cheat_mode", 2),
               (str_store_party_name, s7, ":center_no"),
               (str_store_troop_name, s0, ":troop_no"),
               (display_message, "str_debug__s0_is_spawning_around_party__s7"),
             (try_end),

             (call_script, "script_create_kingdom_hero_party", ":troop_no", ":center_no"),

             (try_begin),
               (eq, "$g_there_is_no_avaliable_centers", 0),
               (party_attach_to_party, "$pout_party", ":center_no"),
             (try_end),

             #new
             #(troop_get_slot, ":party_no", ":troop_no", slot_troop_leaded_party),
             #(call_script, "script_npc_decision_checklist_party_ai", ":troop_no"), #This handles AI for both marshal and other parties
             #(call_script, "script_party_set_ai_state", ":party_no", reg0, reg1),
             #new end

             (troop_get_slot, ":party_no", ":troop_no", slot_troop_leaded_party),
             (call_script, "script_party_set_ai_state", ":party_no", spai_holding_center, ":center_no"),

           (else_try),
             (neg|faction_slot_eq, ":cur_faction", slot_faction_state, sfs_active),
             (try_begin),
               (is_between, ":troop_no", kings_begin, kings_end),
               (troop_set_slot, ":troop_no", slot_troop_change_to_faction, "fac_commoners"),
             (else_try),
               (store_random_in_range, ":random_no", 0, 100),
               (lt, ":random_no", 10),
               (call_script, "script_cf_get_random_active_faction_except_player_faction_and_faction", ":cur_faction"),
               (troop_set_slot, ":troop_no", slot_troop_change_to_faction, reg0),
             (try_end),
           (try_end),
         (try_end),
     (try_end),

#center attacker / more assassins / more drunks
     (try_begin),
        (try_for_range, ":center_no", centers_begin, centers_end),
          (this_or_next|party_slot_eq, ":center_no", slot_party_type, spt_town),
          (party_slot_eq, ":center_no", slot_party_type, spt_village),
          (party_get_slot, ":has_bandits", ":center_no", slot_center_has_attacker),
          (try_begin),
            (le, ":has_bandits", 0),
            (assign, ":continue", 0),
            (try_begin),
              (store_random_in_range, ":random_no", 0, 100),
              (le, ":random_no", 25), #extra high for testing
              (assign, ":continue", 1),
            (try_end),
            (eq, ":continue", 1),
            (party_set_slot, ":center_no", slot_center_has_attacker, 1),
          (else_try),
            (party_set_slot, ":center_no", slot_center_has_attacker, -1),
          (try_end),
        (try_end),

        (try_begin),
            (troop_get_slot, ":player_renown", "trp_player", slot_troop_renown),
            (try_begin),
                (eq,"$player_old_renown",-1),
                (assign,"$player_old_renown",":player_renown"),
            (else_try),
                (assign,":player_renown_check",":player_renown"),
                (val_sub,":player_renown_check","$player_old_renown"),
                (gt,":player_renown_check",25),
                (store_random_in_range, ":center_no", towns_begin, towns_end),
                (party_slot_eq, ":center_no", slot_party_type, spt_town),
                (neg|troop_slot_eq, "trp_hired_assassin", slot_troop_cur_center, ":center_no"),
                (troop_set_slot, "trp_hired_assassin", slot_troop_cur_center, ":center_no"),
                (assign,"$player_old_renown",":player_renown"),
            (else_try),
                (assign,"$player_old_renown",":player_renown"),
            (try_end),
        (try_end),

        (store_random_in_range, ":belligerent_drunk_tavern", towns_begin, towns_end),
        (troop_set_slot, "trp_belligerent_drunk", slot_troop_cur_center, ":belligerent_drunk_tavern"),
     (try_end),

     (try_begin),
     (try_end),

    ]),


(72,
   [
#courtship reset
     (assign, "$lady_flirtation_location", 0),

# Updating trade good prices according to the productions
     (call_script, "script_update_trade_good_prices"),
# Updating player odds
     (try_for_range, ":cur_center", centers_begin, centers_end),
       (party_get_slot, ":player_odds", ":cur_center", slot_town_player_odds),
       (try_begin),
         (gt, ":player_odds", 1000),
         (val_mul, ":player_odds", 95),
         (val_div, ":player_odds", 100),
         (val_max, ":player_odds", 1000),
       (else_try),
         (lt, ":player_odds", 1000),
         (val_mul, ":player_odds", 105),
         (val_div, ":player_odds", 100),
         (val_min, ":player_odds", 1000),
       (try_end),
       (party_set_slot, ":cur_center", slot_town_player_odds, ":player_odds"),
     (try_end),

# Exchanging hero prisoners between factions and clearing old ransom offers
     (try_begin),
        (assign, "$g_ransom_offer_rejected", 0),
        (try_for_range, ":center_no", walled_centers_begin, walled_centers_end),
          (party_get_slot, ":town_lord", ":center_no", slot_town_lord),
          (gt, ":town_lord", 0),
          (party_get_num_prisoner_stacks, ":num_stacks", ":center_no"),
          #SB : moved to top
          (store_troop_faction, ":faction_no", ":town_lord"),
          (troop_get_slot, ":wealth", ":town_lord", slot_troop_wealth),
          (str_store_faction_name, s2, ":faction_no"),
          (try_for_range_backwards, ":i_stack", 0, ":num_stacks"),
            (party_prisoner_stack_get_troop_id, ":stack_troop", ":center_no", ":i_stack"),
            (troop_is_hero, ":stack_troop"),
            (troop_slot_eq, ":stack_troop", slot_troop_occupation, slto_kingdom_hero),
            (store_random_in_range, ":random_no", 0, 100),
            (try_begin),
              (le, ":random_no", 10),
              (call_script, "script_calculate_ransom_amount_for_troop", ":stack_troop"),
              (assign, ":ransom_amount", reg0),
              ##diplomacy start+ Remove the wealth from the stack troop
              (call_script, "script_dplmc_remove_gold_from_lord_and_holdings", ":ransom_amount", ":stack_troop"),
              ##diplomacy end+
              (val_add, ":wealth", ":ransom_amount"),

              (party_remove_prisoners, ":center_no", ":stack_troop", 1),
              (call_script, "script_remove_troop_from_prison", ":stack_troop"),

              (store_troop_faction, ":troop_faction", ":stack_troop"),
              (str_store_troop_name, s1, ":stack_troop"),
              (str_store_faction_name, s2, ":faction_no"),
              (str_store_faction_name, s3, ":troop_faction"),
              #SB : colorize faction, add s2 for imprisoning faction
              (faction_get_color, ":color", ":troop_faction"),
              (display_log_message, "@{s1} of {s3} has been released from captivity by {s2}.", ":color"),
            (try_end),
            #SB : moved to bottom
            (troop_set_slot, ":town_lord", slot_troop_wealth, ":wealth"),
          (try_end),
        (try_end),
     (try_end),

# Adding mercenary troops to the towns
     (try_begin),
       (call_script, "script_update_mercenary_units_of_towns"),
       (call_script, "script_update_ransom_brokers"),
       (call_script, "script_update_tavern_travellers"),
       (call_script, "script_update_tavern_minstrels"),
       (call_script, "script_update_booksellers"),
       (call_script, "script_update_villages_infested_by_bandits"),
       (try_for_range, ":village_no", centers_begin, centers_end), #BW replaced villages_begin, villages_end with centers_begin, centers_end
         (call_script, "script_update_volunteer_troops_in_village", ":village_no"),
         (call_script, "script_update_npc_volunteer_troops_in_village", ":village_no"),
       (try_end),
     (try_end),


    ]),


(24 * 7,
   [
    #Pay day.
     (try_begin),
         ##diplomacy begin
         (store_current_hours, "$g_next_pay_time"),
         (val_add, "$g_next_pay_time", 24 * 7),
         ##diplomacy end
         # (assign, "$g_presentation_lines_to_display_begin", 0),
         # (assign, "$g_presentation_lines_to_display_end", 15),
         (assign, "$g_apply_budget_report_to_gold", 1),
         (try_begin),
           (eq, "$g_infinite_camping", 0),
           (start_presentation, "prsnt_budget_report"),
            ##diplomacy begin
            (try_begin),
              (gt, "$g_player_debt_to_party_members", 5000),
              (call_script, "script_add_notification_menu", "mnu_dplmc_deserters",20,0),
            (try_end),
            # #SB : update the info pages coarsely once per week
            # (try_for_range, ":kingdom_no", npc_kingdoms_begin, npc_kingdoms_end),
              # (faction_get_slot, ":faction_morale", ":kingdom_no",  slot_faction_morale_of_player_troops),
              # (store_div, ":value", ":faction_morale", 100),
              # (neq, ":value", 0),
              # (assign, reg6, ":value"),
              # (store_mod, reg7, ":faction_morale", 100),
              # (val_abs, reg7),
              # (str_store_faction_name, s9, ":kingdom_no"),
              # (store_sub, ":faction_offset", ":kingdom_no", kingdoms_begin), #SB : add one to index to not override default string
              # (add_info_page_note_from_sreg, ip_morale, ":faction_offset", "@Morale for {s9} troops: {reg6}", 0),
             # (try_end),
            ##diplomacy end

         (try_end),
     (try_end),

    #Party AI: pruning some of the prisoners in each center (once a week)
     (try_begin),
        #SB : save g_talk_troop
       (assign, ":save_talk_troop", "$g_talk_troop"),
       (assign, "$g_talk_troop", ransom_brokers_begin), #to get the right price
       (try_for_range, ":center_no", centers_begin, centers_end),
         (party_get_num_prisoner_stacks, ":num_prisoner_stacks",":center_no"),
         (try_for_range_backwards, ":stack_no", 0, ":num_prisoner_stacks"),
           (party_prisoner_stack_get_troop_id, ":stack_troop",":center_no",":stack_no"),
           (neg|troop_is_hero, ":stack_troop"),
           (party_prisoner_stack_get_size, ":stack_size",":center_no",":stack_no"),
           (store_random_in_range, ":rand_no", 0, 40),
           (val_mul, ":stack_size", ":rand_no"),
           (val_div, ":stack_size", 100),
           (party_remove_prisoners, ":center_no", ":stack_troop", ":stack_size"),
		   ##diplomacy start+ add prisoner value to center wealth
		   (try_begin),
		      (ge, "$g_dplmc_gold_changes", DPLMC_GOLD_CHANGES_HIGH),#must be explicitly enabled
			  (ge, ":center_no", 1),
			  (this_or_next|party_slot_eq, ":center_no", slot_party_type, spt_town),
				(party_slot_eq, ":center_no", slot_party_type, spt_castle),
			  (party_slot_ge, ":center_no", slot_town_lord, 1),#"wealth" isn't used for player garrisons
			  (party_get_slot, ":cur_wealth", ":center_no", slot_town_wealth),
			  (lt, ":cur_wealth", 6000),
              #SB : calculate real prisoner price
              (call_script, "script_game_get_prisoner_price", ":stack_troop"),
			  (store_mul, ":ransom_profits", ":stack_size", reg0),#a fraction of what it could be sold for (50 would be a rule of thumb)
              (val_div, ":ransom_profits", 10),
              #SB : ransom broker doubles profit
              (try_begin),
                (party_slot_ge, ":center_no", slot_center_ransom_broker, ransom_brokers_begin),
                (val_mul, ":ransom_profits", 5),
                (val_div, ":ransom_profits", 2),
              (try_end),
			  (val_add, ":cur_wealth", ":ransom_profits"),
			  (party_set_slot, ":center_no", slot_town_wealth, ":cur_wealth"),
		   (try_end),
		   ##diplomacy end+
         (try_end),
       (try_end),
       (assign, "$g_talk_troop", ":save_talk_troop"),
     (try_end),

#Adding net incomes to heroes (once a week)
#Increasing debts to heroes by 1% (once a week)
#Adding net incomes to centers (once a week)
     (try_begin),
      ##diplomacy start+ Save register
      (assign, ":save_reg0", reg0),
      ##Change to support faction ladies
       #(try_for_range, ":troop_no", active_npcs_begin, active_npcs_end),
	   (try_for_range, ":troop_no", heroes_begin, heroes_end),
	     (this_or_next|is_between, ":troop_no", active_npcs_begin, active_npcs_end),
		 (troop_slot_eq, ":troop_no", slot_troop_occupation, slto_kingdom_hero),
	   ##diplomacy end+
         (troop_get_slot, ":cur_debt", ":troop_no", slot_troop_player_debt),#Increasing debt
         (lt, ":cur_debt", dplmc_ransom_debt_mask), #qst_rescue_prisoner does not accumulate
         #SB : aristocracy/plutocracy debt modifier
         (store_faction_of_troop, ":faction_no", ":troop_no"),
         (faction_get_slot, ":aristocracy", ":faction_no", dplmc_slot_faction_aristocracy),
         (val_add, ":aristocracy", 205), #1.01x to 1.04x
         (val_mul, ":cur_debt", ":aristocracy"),
         (val_div, ":cur_debt", 200),
         (troop_set_slot, ":troop_no", slot_troop_player_debt, ":cur_debt"),
         (call_script, "script_calculate_hero_weekly_net_income_and_add_to_wealth", ":troop_no"),#Adding net income
       (try_end),

	   ##diplomacy start+
	   (store_current_hours, ":two_weeks_ago"),
	   (val_sub, ":two_weeks_ago", 24 * 14),
	   ##diplomacy end+

       (try_for_range, ":center_no", walled_centers_begin, walled_centers_end),
         #If non-player center, adding income to wealth
         (neg|party_slot_eq, ":center_no", slot_town_lord, "trp_player"), #center does not belong to player.
		 ##diplomacy start+
		 #Defer the ownership check so attrition can still occur for unowned centers.
		 #Give a slight grace period first, though.
		 (neg|party_slot_eq, ":center_no", slot_town_lord, 0),
		 (this_or_next|party_slot_ge, ":center_no", dplmc_slot_center_last_transfer_time, ":two_weeks_ago"),
			(party_slot_ge, ":center_no", slot_town_lord, 1), #center belongs to someone.
		 (this_or_next|ge, "$g_dplmc_gold_changes", DPLMC_GOLD_CHANGES_MEDIUM),
		 ##diplomacy end+
		 (party_slot_ge, ":center_no", slot_town_lord, 1), #center belongs to someone.
         (party_get_slot, ":cur_wealth", ":center_no", slot_town_wealth),
         (party_get_slot, ":prosperity", ":center_no", slot_town_prosperity),
         (store_mul, ":added_wealth", ":prosperity", 15),
         (val_add, ":added_wealth", 700),
         (try_begin),
           (party_slot_eq, ":center_no", slot_party_type, spt_town),
           (val_mul, ":added_wealth", 3),
           (val_div, ":added_wealth", 2),
         (try_end),
         (val_add, ":cur_wealth", ":added_wealth"),
         (call_script, "script_calculate_weekly_party_wage", ":center_no"),
         (val_sub, ":cur_wealth", reg0),
		 ##diplomacy start+ Allow attrition to occur
		 (try_begin),
			(lt, ":cur_wealth", 0),
			(ge, "$g_dplmc_gold_changes", DPLMC_GOLD_CHANGES_MEDIUM),
			(assign, ":cur_weekly_wage", reg0),
			(store_party_size_wo_prisoners, ":garrison_size", ":center_no"),
			(call_script, "script_party_get_ideal_size", ":center_no"),#This script has been modified to support this use
			(val_mul, reg0, 5),
			(val_div, reg0, 4),
			(ge, ":garrison_size", reg0),

			(store_sub, ":percent_under", 0, ":cur_wealth"),
			(val_mul, ":percent_under", 100),
			(val_div, ":percent_under", ":cur_weekly_wage"),
			(val_div, ":percent_under", 5), #Max 20 percent (won't take garrison below ideal size)
			(call_script, "script_party_inflict_attrition", ":center_no", ":percent_under"),
			# (call_script, "script_party_inflict_attrition", ":center_no", ":percent_under", 1),
		 (try_end),
		 (party_slot_ge, ":center_no", slot_town_lord, 1), #center belongs to someone.
		 ##diplomacy end+
         (val_max, ":cur_wealth", 0),
         (party_set_slot, ":center_no", slot_town_wealth, ":cur_wealth"),
       (try_end),
	   ##diplomacy end+
	   (assign, reg0, ":save_reg0"),##diplomacy end+
     (try_end),

# Refresh number of cattle in villages
     (try_begin),
         (try_for_range, ":village_no", centers_begin, centers_end),
        # (neg|is_between, ":village_no", castles_begin, castles_end),
          (party_get_slot, ":num_cattle", ":village_no", slot_center_head_cattle),
          (party_get_slot, ":num_sheep", ":village_no", slot_center_head_sheep),
          (party_get_slot, ":num_acres", ":village_no", slot_center_acres_pasture),
        (val_max, ":num_acres", 1),

        (store_mul, ":grazing_capacity", ":num_cattle", 400),
        (store_mul, ":sheep_addition", ":num_sheep", 200),
        (val_add, ":grazing_capacity", ":sheep_addition"),
        (val_div, ":grazing_capacity", ":num_acres"),
        (try_begin),
        (eq, "$cheat_mode", 1),
          (assign, reg4, ":grazing_capacity"),
        (str_store_party_name, s4, ":village_no"),
          #(display_message, "@{!}DEBUG -- Herd adjustment: {s4} at {reg4}% of grazing capacity"),
        (try_end),


          (store_random_in_range, ":random_no", 0, 100),
          (try_begin), #Disaster
            (eq, ":random_no", 0),#1% chance of epidemic - should happen once every two years
            (val_min, ":num_cattle", 10),

            (try_begin),
    #          (eq, "$cheat_mode", 1),
    #          (str_store_party_name, s1, ":village_no"),
    #          (display_message, "@{!}Cattle in {s1} are exterminated due to famine."),
               ##diplomacy start+ Add display message for the player's own fiefs
           #(store_distance_to_party_from_party, ":dist", "p_main_party", ":village_no"),
           #(this_or_next|lt, ":dist", 30),
                (gt, "$g_player_chamberlain", 0),
           (party_slot_eq, ":village_no", slot_town_lord, "trp_player"),
           (party_get_slot, reg4, ":village_no", slot_center_head_cattle),
           (val_sub, reg4, ":num_cattle"),
           (gt, reg4, 0),
           (str_store_party_name_link, s4, ":village_no"),
           (display_log_message, "@A livestock epidemic has killed {reg4} cattle in {s4}."),
           ##diplomacy end+
            (try_end),

          (else_try), #Overgrazing
          (gt, ":grazing_capacity", 100),

             (val_mul, ":num_sheep", 90), #10% decrease at number of cattles
             (val_div, ":num_sheep", 100),

             (val_mul, ":num_cattle", 90), #10% decrease at number of sheeps
             (val_div, ":num_cattle", 100),

           (else_try), #superb grazing
             (lt, ":grazing_capacity", 30),

             (val_mul, ":num_cattle", 120), #20% increase at number of cattles
             (val_div, ":num_cattle", 100),
             (val_add, ":num_cattle", 1),

             (val_mul, ":num_sheep", 120), #20% increase at number of sheeps
             (val_div, ":num_sheep", 100),
             (val_add, ":num_sheep", 1),

           (else_try), #very good grazing
             (lt, ":grazing_capacity", 60),

             (val_mul, ":num_cattle", 110), #10% increase at number of cattles
             (val_div, ":num_cattle", 100),
        (val_add, ":num_cattle", 1),

             (val_mul, ":num_sheep", 110), #10% increase at number of sheeps
             (val_div, ":num_sheep", 100),
        (val_add, ":num_sheep", 1),

         (else_try), #good grazing
          (lt, ":grazing_capacity", 100),
             (lt, ":random_no", 50),

             (val_mul, ":num_cattle", 105), #5% increase at number of cattles
             (val_div, ":num_cattle", 100),
             (try_begin), #if very low number of cattles and there is good grazing then increase number of cattles also by one
               (le, ":num_cattle", 20),
          (val_add, ":num_cattle", 1),
        (try_end),

             (val_mul, ":num_sheep", 105), #5% increase at number of sheeps
             (val_div, ":num_sheep", 100),
             (try_begin), #if very low number of sheeps and there is good grazing then increase number of sheeps also by one
               (le, ":num_sheep", 20),
          (val_add, ":num_sheep", 1),
        (try_end),


         (try_end),

         (party_set_slot, ":village_no", slot_center_head_cattle, ":num_cattle"),
         (party_set_slot, ":village_no", slot_center_head_sheep, ":num_sheep"),
        (try_end),
     (try_end),

#Accumulate taxes
     (try_begin),
          #Adding earnings to town lords' wealths.
          #Moved to troop does business
          #(try_for_range, ":center_no", centers_begin, centers_end),
          #  (party_get_slot, ":town_lord", ":center_no", slot_town_lord),
          #  (neq, ":town_lord", "trp_player"),
          #  (is_between, ":town_lord", active_npcs_begin, active_npcs_end),
          #  (party_get_slot, ":accumulated_rents", ":center_no", slot_center_accumulated_rents),
          #  (party_get_slot, ":accumulated_tariffs", ":center_no", slot_center_accumulated_tariffs),
          #  (troop_get_slot, ":troop_wealth", ":town_lord", slot_troop_wealth),
          #  (val_add, ":troop_wealth", ":accumulated_rents"),
          #  (val_add, ":troop_wealth", ":accumulated_tariffs"),
          #  (troop_set_slot, ":town_lord", slot_troop_wealth, ":troop_wealth"),
          #  (party_set_slot, ":center_no", slot_center_accumulated_rents, 0),
          #  (party_set_slot, ":center_no", slot_center_accumulated_tariffs, 0),
          #  (try_begin),
          #    (eq, "$cheat_mode", 1),
          #    (assign, reg1, ":troop_wealth"),
          #    (add_troop_note_from_sreg, ":town_lord", 1, "str_current_wealth_reg1", 0),
          #  (try_end),
          #(try_end),

          #Collect taxes for another week
          (game_get_reduce_campaign_ai, ":reduce_campaign_ai"), #SB : moved to top
          (try_for_range, ":center_no", centers_begin, centers_end),
            (try_begin),
              (party_slot_ge, ":center_no", slot_town_lord, 0), #unassigned centers do not accumulate rents

              (party_get_slot, ":accumulated_rents", ":center_no", slot_center_accumulated_rents),

              (assign, ":cur_rents", 0),
              (try_begin),
                (party_slot_eq, ":center_no", slot_party_type, spt_village),
                (try_begin),
                  (party_slot_eq, ":center_no", slot_village_state, svs_normal),
                  (assign, ":cur_rents", 1200),
                (try_end),
              (else_try),
                (party_slot_eq, ":center_no", slot_party_type, spt_castle),
                (assign, ":cur_rents", 1200),
              (else_try),
                (party_slot_eq, ":center_no", slot_party_type, spt_town),
                (assign, ":cur_rents", 2400),
              (try_end),

              (party_get_slot, ":prosperity", ":center_no", slot_town_prosperity), #prosperty changes between 0..100
              (store_add, ":multiplier", 20, ":prosperity"), #multiplier changes between 20..120
              (val_mul, ":cur_rents", ":multiplier"),
              (val_div, ":cur_rents", 120),#Prosperity of 100 gives the default values

              (try_begin),
                (party_slot_eq, ":center_no", slot_town_lord, "trp_player"),

                # (game_get_reduce_campaign_ai, ":reduce_campaign_ai"),
                (try_begin),
                  (eq, ":reduce_campaign_ai", 0), #hard (less money from rents)
                  (val_mul, ":cur_rents", 3),
                  (val_div, ":cur_rents", 4),
                (else_try),
                  (eq, ":reduce_campaign_ai", 1), #medium (normal money from rents)
                  #same
                (else_try),
                  (eq, ":reduce_campaign_ai", 2), #easy (more money from rents)
                  (val_mul, ":cur_rents", 4),
                  (val_div, ":cur_rents", 3),
                (try_end),
              (try_end),

              (val_add, ":accumulated_rents", ":cur_rents"), #cur rents changes between 23..1000

              ##diplomacy begin
              (try_begin),
                (str_store_party_name, s6, ":center_no"),

                (party_get_slot, ":tax_rate", ":center_no", dplmc_slot_center_taxation),
                (neq, ":tax_rate", 0), #SB : swap order of operations for precision
                (store_mul, ":rent_change", ":accumulated_rents", ":tax_rate"),
                (val_div, ":rent_change", 100),

                (try_begin), #debug
                  (eq, "$cheat_mode", 1),
                  (assign, reg0, ":tax_rate"),
                  (display_message, "@{!}DEBUG : tax rate in {s6}: {reg0}"),
                  (assign, reg0, ":accumulated_rents"),
                  (display_message, "@{!}DEBUG : accumulated_rents  in {s6}: {reg0}"),
                  (assign, reg0, ":rent_change"),
                  (display_message, "@{!}DEBUG : rent_change in {s6}: {reg0}  in {s6}"),
                (try_end),

                (val_add, ":accumulated_rents", ":rent_change"),

                (val_div, ":tax_rate", -25),

                (call_script, "script_change_center_prosperity", ":center_no", ":tax_rate"),

                (try_begin),
                  (lt, ":tax_rate", 0), #double negative values
                  (val_mul, ":tax_rate", 2),

                  (try_begin), #debug
                    (eq, "$cheat_mode", 1),
                    (assign, reg0, ":tax_rate"),
                    (display_message, "@{!}DEBUG : tax rate after modi in {s6}: {reg0}"),
                  (try_end),

                  (try_begin),
                    (this_or_next|is_between, ":center_no", villages_begin, villages_end),
                    (is_between, ":center_no", towns_begin, towns_end),
                    #SB : can't have a revolt right when player is in center
                    (neq, ":center_no", "$g_last_rest_center"),
                    (party_get_slot, ":center_relation", ":center_no", slot_center_player_relation),

                    (try_begin), #debug
                      (eq, "$cheat_mode", 1),
                      (assign, reg0, ":center_relation"),
                      (display_message, "@{!}DEBUG : center relation: {reg0}"),
                    (try_end),

                    (le, ":center_relation", -5),
                    (store_random_in_range, ":random",-100, 0),
                    (gt, ":random", ":center_relation"),

                    (neg|party_slot_eq, ":center_no", slot_village_infested_by_bandits, "trp_peasant_woman"),
                    (display_log_message, "@There has been a riot in {s6}!", message_negative), #SB : log message, colorize
                    (party_set_slot, ":center_no", slot_village_infested_by_bandits, "trp_peasant_woman"), #trp_peasant_woman used to simulate riot
                    (call_script, "script_change_center_prosperity", ":center_no", -1),
                    (call_script, "script_add_notification_menu", "mnu_dplmc_notification_riot", ":center_no", 0),

                    #add additional troops
                    (store_character_level, ":player_level", "trp_player"),
                    (store_div, ":player_leveld2", ":player_level", 2),
                    (store_mul, ":player_levelx2", ":player_level", 2),
                    (try_begin),
                      (is_between, ":center_no", villages_begin, villages_end),
                      (store_random_in_range, ":random",0, ":player_level"),
                      (party_add_members, ":center_no", "trp_mercenary_swordsman", ":random"),
                      (store_random_in_range, ":random", 0, ":player_leveld2"),
                      (party_add_members, ":center_no", "trp_hired_blade", ":random"),
                    (else_try),
                      (party_set_banner_icon, ":center_no", 0),
                      (party_get_num_companion_stacks, ":num_stacks",":center_no"),
                      (try_for_range, ":i_stack", 0, ":num_stacks"),
                        (party_stack_get_size, ":stack_size",":center_no",":i_stack"),
                        (val_div, ":stack_size", 2),
                        (party_stack_get_troop_id, ":troop_id", ":center_no", ":i_stack"),
                        (party_remove_members, ":center_no", ":troop_id", ":stack_size"),
                      (try_end),
                      (store_random_in_range, ":random",":player_leveld2", ":player_levelx2"),
                      (party_add_members, ":center_no", "trp_farmer", ":random"),
                      (store_random_in_range, ":random",0, ":player_level"),
                      (party_add_members, ":center_no", "trp_watchman", ":random"),
                      #SB : move some injured to dungeon, rescue/lynch existing ones?
                    (try_end),
                  (try_end),
                (try_end),
                (call_script, "script_change_player_relation_with_center", ":center_no", ":tax_rate"),
              (try_end),

              (try_begin), #no taxes for infested villages and towns
                (party_slot_ge, ":center_no", slot_village_infested_by_bandits, 1),
                (assign,":accumulated_rents", 0),
              (try_end),
              ##diplomacy end
              (party_set_slot, ":center_no", slot_center_accumulated_rents, ":accumulated_rents"),
            (try_end),

        # (try_begin),
          # (is_between, ":center_no", villages_begin, villages_end),
          # (party_get_slot, ":bound_castle", ":center_no", slot_village_bound_center),
          # (party_slot_ge, ":bound_castle", slot_town_lord, 0), #unassigned centers do not accumulate rents
          # (is_between, ":bound_castle", castles_begin, castles_end),
          # (party_get_slot, ":accumulated_rents", ":bound_castle", slot_center_accumulated_rents), #fort's accumulated rents
          # (val_add, ":accumulated_rents", ":cur_rents"), #add village's rent to fort rents
          # (party_set_slot, ":bound_castle", slot_center_accumulated_rents, ":accumulated_rents"),
        # (try_end),
          (try_end),
     (try_end),

#recalculate lord random decision seeds once in every week
     (try_begin),
        ##diplomacy start+ Kingdom ladies should also have their decision seeds updated.
        ##                 Also, use 10000 instead of 9999, since the upper bound for store_random_in_range is exclusive.
        ##OLD:
          #(try_for_range, ":troop_no", active_npcs_begin, active_npcs_end),
          #  (store_random_in_range, ":random", 0, 9999),
        ##NEW:
        (try_for_range, ":troop_no", heroes_begin, heroes_end),
           (store_random_in_range, ":random", 0, 10000),
        ##diplomacy end+
            (troop_set_slot, ":troop_no", slot_troop_temp_decision_seed, ":random"),
          (try_end),

        ##diplomacy start+ Also update the temporary seed for the player
        (store_random_in_range, ":random", 0, 10000),
        (troop_set_slot, "trp_player", slot_troop_temp_decision_seed, ":random"),##diplomacy end+
            #npcs will only change their minds on issues at least 24 hours after speaking to the player
            #(store_current_hours, ":hours"),
            #(try_begin),
            #  (eq, 1, 0), #disabled
            #  (try_for_range, ":npc", active_npcs_begin, active_npcs_end),
            #    (troop_get_slot, ":last_talk", ":npc", slot_troop_last_talk_time),
            #    (val_sub, ":hours", ":last_talk"),
            #    (ge, ":hours", 24),
            #    (store_random_in_range, ":random", 0, 9999),
            #    (troop_set_slot, ":npc", slot_troop_temp_decision_seed, ":random"),
            #  (try_end),
            #(try_end),
     (try_end),

# Reduce renown slightly by 0.5% every week
     (try_begin),
       (troop_get_slot, ":player_renown", "trp_player", slot_troop_renown),
       (store_div, ":renown_decrease", ":player_renown", 200),
       (val_sub, ":player_renown", ":renown_decrease"),
       (troop_set_slot, "trp_player", slot_troop_renown, ":player_renown"),

       #SB : slowly increase renown of minister weekly instead of doing so upon assignment
       (try_begin),
         (gt, "$g_player_minister", 0),
         (neq, "$g_player_minister", "trp_temporary_minister"),
         (call_script, "script_change_troop_renown", "$g_player_minister", 10),
       (try_end),
     (try_end),

#fake events
     (try_begin),
        (call_script, "script_rnd", 0, 100),
        (eq,reg0,1),

        (call_script, "script_rnd", 0, 5),

        (try_begin), #fire
          (eq,reg0,0),
          (store_random_party_in_range, ":center_no", centers_begin, centers_end),
          (str_store_party_name_link, s5, ":center_no"),
          (store_faction_of_party, ":center_faction", ":center_no"),
          (faction_get_color, ":color", ":center_faction"),
          (display_log_message, "@There was a fire in {s5}. It's under control now, but it may take a while until the damage is repaired.", ":color"),
          (call_script, "script_change_center_prosperity", ":center_no", -25),
        (else_try), # good trade
          (eq,reg0,1),

          (store_random_party_in_range, ":center_no", centers_begin, centers_end),
          (str_store_party_name_link, s5, ":center_no"),
          (store_faction_of_party, ":center_faction", ":center_no"),
          (faction_get_color, ":color", ":center_faction"),

          (try_begin),
            (party_slot_eq, ":center_no", slot_party_type, spt_town),
            (display_log_message, "@The merchant caravans of {s5} managed to do very profitable trading recently.", ":color"),
          (else_try),
            (party_slot_eq, ":center_no", slot_party_type, spt_village),
            (display_log_message, "@The settlement of {s5} had many visitors recently and the locals managed to trade well.", ":color"),
          (try_end),
          (call_script, "script_change_center_prosperity", ":center_no", 25),
        (else_try), # art
          (eq,reg0,2),

          (store_random_party_in_range, ":center_no", towns_begin, towns_end),
          (str_store_party_name_link, s5, ":center_no"),
          (store_faction_of_party, ":center_faction", ":center_no"),
          (faction_get_color, ":color", ":center_faction"),
          (display_log_message, "@A famous piece of art, which was long been thought lost, was found near {s5}! It is currently on display in {s5} and people are coming from all over Acron to see it.", ":color"),
          (call_script, "script_change_center_prosperity", ":center_no", 25),
        # (else_try), # comp injured
          # (eq,reg0,3),

          # (call_script, "script_get_random_hero_in_playerparty"),
          # (assign, ":troop_no", reg0),
          # (neq,":troop_no",-1), # skip event if no companion in party
          # (store_troop_health, reg0, ":troop_no"),
          # (ge,reg0,60), # abort if companion is already weak
          # (str_store_troop_name, s5, ":troop_no"),
          # (dialog_box, "@{s5} was accidently injured today. The wounds aren't severe, but it may take some time for {s5} to be in top form again.", "@Accident:"),
          # (call_script, "script_change_troop_health", ":troop_no", -40),
        # (else_try), # injured
          # (eq,reg0,4),

          # (call_script, "script_get_troop_health", "trp_player"), (ge,reg0,60), # abort if player is already weak
          # (dialog_box, "@During today's training, you were accidently injured. While the wounds aren't severe, it may take some time for them to heal.", "@Training accident:"),
          # (call_script, "script_change_troop_health", "trp_player", -40),
        (else_try), # disease
          (eq,reg0,3),

          (store_random_party_in_range, ":center_no", centers_begin, centers_end),
          (str_store_party_name_link, s5, ":center_no"),
          (store_faction_of_party, ":center_faction", ":center_no"),
          (faction_get_color, ":color", ":center_faction"),
          (display_log_message, "@A painful disease had broken out in {s5}. A surgeon was sent, but was unable to find a cure. All he could do, was to contain the plague by seperating the healthy from the sick.", ":color"),
          (call_script, "script_change_center_prosperity", ":center_no", -25),
        (else_try), # disease averted
          (eq,reg0,4),

          (store_random_party_in_range, ":center_no", centers_begin, centers_end),
          (str_store_party_name_link, s5, ":center_no"),
          (store_faction_of_party, ":center_faction", ":center_no"),
          (faction_get_color, ":color", ":center_faction"),
          (display_log_message, "@A painful disease had broken out in {s5}. However, a surgeon was sent and managed to find a cure for the plague.", ":color"),
          (call_script, "script_change_center_prosperity", ":center_no", -5),
        # --- Attacked by Armys ---
        # (else_try),
            # (store_random_in_range, ":rand", 0, 500),
            # (eq, ":rand", 1),
            # (store_random_party_in_range, ":town_no", towns_begin, towns_end),
             # (try_begin),
               # (spawn_around_party,":town_no","pt_sea_raiders_army"),
               # (assign,"$sea_raiders_army",reg(0)),
               # (party_set_ai_behavior, "$sea_raiders_army", ai_bhvr_attack_party),
               # (party_set_ai_object,"$sea_raiders_army",":town_no"),
             # (try_end),
            # (str_store_party_name_link, s5, ":town_no"),
            # (store_faction_of_party, ":center_faction", ":town_no"),
            # # (faction_get_color, ":color", ":center_faction"),
            # (display_log_message, "@Sea raiders gathered togheter to attack {s5}!", 0x6666FF),
        (try_end),
     (try_end),

#leader gift
# #Floris Seafaring Wilderness Check
		# (try_for_parties, ":party_no"),
		    # (party_slot_eq, ":party_no", slot_party_type, spt_ship),
			# (party_slot_eq, ":party_no", slot_ship_center, ship_wild_no_guard),
			# (party_get_slot, ":timer", ":party_no", slot_ship_time),
			# (store_current_hours, ":cur_time"),
			# (ge, ":cur_time", ":timer"),
			# (store_random_in_range, ":luck", 0, 10),
			# (ge, ":luck", 5),
			# (str_store_party_name, s1, ":party_no"),
			# (display_message, "@You have a bad feeling about your ship {s1}."),
			# (remove_party, ":party_no"),
		# (try_end),
###################
   ## Give the player a gift for being a good little commander
        (try_begin),
          # (eq, "$g_vassal_gift", 0),
          (gt, "$players_kingdom", 0),
          (gt, "$player_has_homage", 0),
          (neg|faction_slot_eq, "$players_kingdom", slot_faction_leader, "trp_player"),
          (store_free_inventory_capacity, ":free_inventory"),
          (ge,":free_inventory",1),
          (store_relation, ":relation", "$players_kingdom", "fac_player_faction"),
          (ge,":relation",0),
          (assign,":gift",0),
          (try_begin),
            (eq, "$g_vassal_gift", 0),
            (store_random_in_range,":gift","itm_jeep_beige",vehicles_end),
          (else_try),
            (assign,":gift","itm_gasoline"),
          (try_end),
          (gt,":gift",0),
          # (assign,"$g_vassal_gift",1),
          (call_script, "script_add_notification_menu", "mnu_notification_give_vassal_gift", ":gift", 0),
        (try_end),

# Iron Mine Pay slave labor earnings
    (try_begin),
      (troop_clear_inventory, "trp_salt_mine_merchant"),
      (store_random_in_range, ":amount",5,31),
      (troop_add_items,"trp_salt_mine_merchant", "itm_iron_ore",":amount"),

      # (gt, "$g_num_prisoners", 0),
      # (store_skill_level, ":skill", "skl_prisoner_management", "trp_player"),
      # (store_add, ":earnings", 25, ":skill"), #50 to 35

      # (party_get_num_prisoners, "$g_num_prisoners", "p_salt_mine"),
      # (store_mul,  "$g_earnings", ":earnings", "$g_num_prisoners"),
      # (jump_to_menu,"mnu_slave_labor"),
    (try_end),

#randomly reduce imods
    (try_begin),
        (neq, "$g_player_icon_state", pis_camping),
        (map_free),

        (is_between,"$g_player_party_icon","icon_map_jeep_beige","icon_map_uruk"),
        (store_skill_level, ":mechanic_level", skl_engineer, "trp_player"),
        (val_add, ":mechanic_level",10),
        (call_script, "script_rnd", 0,":mechanic_level"),
        (eq,reg0,1),

        (troop_get_inventory_capacity, ":capacity", "trp_player"),
        (try_for_range, ":item_slot", 0, ":capacity"),
          (troop_get_inventory_slot, ":item_no", "trp_player", ":item_slot"),
          (ge, ":item_no", 0),
          (is_between, ":item_no", vehicles_begin,vehicles_end),
          (assign, ":capacity", 0),
          (troop_get_inventory_slot_modifier, ":slot_item_imod", "trp_player", ":item_slot"),
          (call_script, "script_get_next_lower_imod_for_item", ":item_no", ":slot_item_imod"),
          (assign, ":new_imod", reg0),
          (neq, ":slot_item_imod", ":new_imod"),
          (troop_set_inventory_slot_modifier, "trp_player", ":item_slot", ":new_imod"),
          (str_store_item_name, s1, ":item_no"),
          (dialog_box, "@Your {s1} shows signs of wear and tear!", "@Alert"),
          # (display_message,"@Your {s1} shows signs of wear and tear!",message_alert),
        (try_end),
    (try_end),
    # (try_begin),
      # (troop_get_inventory_capacity, ":inv_size", "trp_player"),
      # (try_for_range, ":item_slot", 0, ":inv_size"),
        # (troop_get_inventory_slot, ":item_no", "trp_player", ":item_slot"),
        # (ge, ":item_no",0),
        # (item_get_type, ":item_type", ":item_no"),
        # (eq, ":item_type", itp_type_goods),
        # # (eq, ":item_type", itp_type_musket),
        # (call_script, "script_rnd", 0,64),
        # (eq,reg0,1),
        # (troop_get_inventory_slot_modifier, ":slot_item_imod", "trp_player", ":item_slot"),
        # (call_script, "script_get_next_lower_imod_for_item", ":item_no", ":slot_item_imod"),
        # (assign, ":new_imod", reg0),
        # (neq, ":slot_item_imod", ":new_imod"),
        # (troop_set_inventory_slot_modifier, "trp_player", ":item_slot", ":new_imod"),
        # (str_store_item_name, s1, ":item_no"),
        # (display_message,"@Your {s1} shows signs of wear and tear!",message_alert),
      # (try_end),
    # (try_end),

    ]),

# Refresh merchant inventories
(168,
   [
      (try_for_range, ":village_no", villages_begin, villages_end),
        (call_script, "script_refresh_village_merchant_inventory", ":village_no"),
      (try_end),
    ]),

(180,
   [
# # Reducing luck by 1 in every 180 hours
     # (val_sub, "$g_player_luck", 1),
     # (val_max, "$g_player_luck", 0),
    ]),

#####!!!!!
# Village upgrade triggers
# School
(15 * 24,
# (30 * 24,
   [(try_for_range, ":cur_village", villages_begin, villages_end),
      # (party_slot_eq, ":cur_village", slot_town_lord, "trp_player"),
      (party_get_slot, ":town_lord", ":cur_village", slot_town_lord),
      #SB : also handle the case where player hands out villages
      (store_faction_of_party, ":faction_no", ":cur_village"),
      (try_begin),
        (eq, ":faction_no", "$players_kingdom"),
        (call_script, "script_dplmc_get_troop_standing_in_faction", "trp_player", ":faction_no"),
        (ge, reg0, DPLMC_FACTION_STANDING_LEADER_SPOUSE),
        (assign, ":town_lord", "trp_player"),
      (try_end),
      (eq, ":town_lord", "trp_player"),

      (party_slot_eq, ":cur_village", slot_center_has_school, 1),
      (party_get_slot, ":cur_relation", ":cur_village", slot_center_player_relation),
      (val_add, ":cur_relation", 1),
      (val_min, ":cur_relation", 100),
      (party_set_slot, ":cur_village", slot_center_player_relation, ":cur_relation"),
    (try_end),
    ]),

# Quest triggers:
# Remaining days text update
(24, [(try_for_range, ":cur_quest", all_quests_begin, all_quests_end),
          (try_begin),
            (check_quest_active, ":cur_quest"),
            (try_begin),
              (neg|check_quest_concluded, ":cur_quest"),
              (quest_slot_ge, ":cur_quest", slot_quest_expiration_days, 1),
              (quest_get_slot, ":exp_days", ":cur_quest", slot_quest_expiration_days),
              (val_sub, ":exp_days", 1),
              (try_begin),
                (eq, ":exp_days", 0),
                (call_script, "script_abort_quest", ":cur_quest", 1),
              (else_try),
                (quest_set_slot, ":cur_quest", slot_quest_expiration_days, ":exp_days"),
                (assign, reg0, ":exp_days"),
                (add_quest_note_from_sreg, ":cur_quest", 7, "@You have {reg0} days to finish this quest.", 0),
              (try_end),
            (try_end),
            #SB : delegate quest progression ticks
          (else_try),
            (quest_slot_ge, ":cur_quest", slot_quest_dont_give_again_remaining_days, 1),
            (quest_get_slot, ":value", ":cur_quest", slot_quest_dont_give_again_remaining_days),
            (val_sub, ":value", 1),
            (quest_set_slot, ":cur_quest", slot_quest_dont_give_again_remaining_days, ":value"),
          (try_end),
        (try_end),
    ]),

# Report to army quest
(2,
   [
     (eq, "$g_infinite_camping", 0),
     (is_between, "$players_kingdom", kingdoms_begin, kingdoms_end),
     (eq, "$g_player_is_captive", 0),

	 (try_begin),
		(check_quest_active, "qst_report_to_army"),
		(faction_slot_eq, "$players_kingdom", slot_faction_marshall, -1),
		(call_script, "script_abort_quest", "qst_report_to_army", 0),
	 (try_end),

	 (faction_get_slot, ":faction_object", "$players_kingdom", slot_faction_ai_object),

     (neg|faction_slot_eq, "$players_kingdom", slot_faction_ai_state, sfai_default),
     (neg|faction_slot_eq, "$players_kingdom", slot_faction_ai_state, sfai_feast),

     (assign, ":continue", 1),
     (try_begin),
       (this_or_next|faction_slot_eq, "$players_kingdom", slot_faction_ai_state, sfai_attacking_enemies_around_center),
       (this_or_next|faction_slot_eq, "$players_kingdom", slot_faction_ai_state, sfai_attacking_center),
       (faction_slot_eq, "$players_kingdom", slot_faction_ai_state, sfai_raiding_village),
       (neg|is_between, ":faction_object", walled_centers_begin, walled_centers_end),
       (assign, ":continue", 0),
     (try_end),
     (eq, ":continue", 1),

	 (assign, ":kingdom_is_at_war", 0),
	 (try_for_range, ":faction", kingdoms_begin, kingdoms_end),
		(neq, ":faction", "$players_kingdom"),
		(store_relation, ":relation", ":faction", "$players_kingdom"),
		(lt, ":relation", 0),
		(assign, ":kingdom_is_at_war", 1),
	 (try_end),
	 (eq, ":kingdom_is_at_war", 1),

     (neg|check_quest_active, "qst_report_to_army"),
     (neg|check_quest_active, "qst_follow_army"),

     (neg|quest_slot_ge, "qst_report_to_army", slot_quest_dont_give_again_remaining_days, 1),
     (faction_get_slot, ":faction_marshall", "$players_kingdom", slot_faction_marshall),
     (gt, ":faction_marshall", 0),
     (troop_get_slot, ":faction_marshall_party", ":faction_marshall", slot_troop_leaded_party),
     (gt, ":faction_marshall_party", 0),
     (party_is_active, ":faction_marshall_party"),

     (store_distance_to_party_from_party, ":distance_to_marshal", ":faction_marshall_party", "p_main_party"),
     (le, ":distance_to_marshal", 96),

     (assign, ":has_no_quests", 1),
     (try_for_range, ":cur_quest", lord_quests_begin, lord_quests_end),
       (check_quest_active, ":cur_quest"),
       (quest_slot_eq, ":cur_quest", slot_quest_giver_troop, ":faction_marshall"),
       (assign, ":has_no_quests", 0),
     (try_end),
     (eq, ":has_no_quests", 1),

     # (try_for_range, ":cur_quest", lord_quests_begin_2, lord_quests_end_2),
       # (check_quest_active, ":cur_quest"),
       # (quest_slot_eq, ":cur_quest", slot_quest_giver_troop, ":faction_marshall"),
       # (assign, ":has_no_quests", 0),
     # (try_end),
     # (eq, ":has_no_quests", 1),

     (try_for_range, ":cur_quest", army_quests_begin, army_quests_end),
       (check_quest_active, ":cur_quest"),
       (assign, ":has_no_quests", 0),
     (try_end),
     (eq, ":has_no_quests", 1),

     (store_character_level, ":level", "trp_player"),
     (ge, ":level", 8),
     (assign, ":cur_target_amount", 2),
     (try_for_range, ":cur_center", centers_begin, centers_end),
       (party_slot_eq, ":cur_center", slot_town_lord, "trp_player"),
       (try_begin),
         (party_slot_eq, ":cur_center", slot_party_type, spt_town),
         (val_add, ":cur_target_amount", 3),
       (else_try),
         (party_slot_eq, ":cur_center", slot_party_type, spt_castle),
         (val_add, ":cur_target_amount", 1),
       (else_try),
         (val_add, ":cur_target_amount", 1),
       (try_end),
     (try_end),

     (val_mul, ":cur_target_amount", 4),
     (val_min, ":cur_target_amount", 60),
     (quest_set_slot, "qst_report_to_army", slot_quest_giver_troop, ":faction_marshall"),
     (quest_set_slot, "qst_report_to_army", slot_quest_target_troop, ":faction_marshall"),
     (quest_set_slot, "qst_report_to_army", slot_quest_target_amount, ":cur_target_amount"),
     (quest_set_slot, "qst_report_to_army", slot_quest_expiration_days, 4),
     (quest_set_slot, "qst_report_to_army", slot_quest_dont_give_again_period, 22),
     (jump_to_menu, "mnu_kingdom_army_quest_report_to_army"),
   ]),

# Army quest initializer
(3,
   [
     (assign, "$g_random_army_quest", -1),
     (check_quest_active, "qst_follow_army", 1),
     (is_between, "$players_kingdom", kingdoms_begin, kingdoms_end),
#Rebellion changes begin
#     (neg|is_between, "$players_kingdom", rebel_factions_begin, rebel_factions_end),
#Rebellion changes end
     (neg|faction_slot_eq, "$players_kingdom", slot_faction_ai_state, sfai_default),
     (faction_get_slot, ":faction_marshall", "$players_kingdom", slot_faction_marshall),
     (neq, ":faction_marshall", "trp_player"),
     (gt, ":faction_marshall", 0),
     (troop_get_slot, ":faction_marshall_party", ":faction_marshall", slot_troop_leaded_party),
     (gt, ":faction_marshall_party", 0),
     (party_is_active, ":faction_marshall_party"),
     (store_distance_to_party_from_party, ":dist", ":faction_marshall_party", "p_main_party"),
     (try_begin),
       (lt, ":dist", 15),
       (assign, "$g_player_follow_army_warnings", 0),
       (store_current_hours, ":cur_hours"),
       (faction_get_slot, ":last_offensive_time", "$players_kingdom", slot_faction_last_offensive_concluded),
       (store_sub, ":passed_time", ":cur_hours", ":last_offensive_time"),

       (assign, ":result", -1),
       (try_begin),
         (store_random_in_range, ":random_no", 0, 100),
         (lt, ":random_no", 30),
         (troop_slot_eq, ":faction_marshall", slot_troop_does_not_give_quest, 0),
         (try_for_range, ":unused", 0, 20), #Repeat trial twenty times
           (eq, ":result", -1),
           (store_random_in_range, ":quest_no", army_quests_begin, army_quests_end),
           (neg|quest_slot_ge, ":quest_no", slot_quest_dont_give_again_remaining_days, 1),
           (try_begin),
             (eq, ":quest_no", "qst_deliver_cattle_to_army"),
			# (eq, 1, 0), #disables temporarily
             (try_begin),
               (faction_slot_eq, "$players_kingdom", slot_faction_ai_state, sfai_attacking_center),
               (gt, ":passed_time", 120),#5 days
               (store_random_in_range, ":quest_target_amount", 5, 10),
               (assign, ":result","qst_deliver_cattle_to_army"),
               (quest_set_slot, ":result", slot_quest_target_amount, ":quest_target_amount"),
               (quest_set_slot, ":result", slot_quest_expiration_days, 10),
               (quest_set_slot, ":result", slot_quest_dont_give_again_period, 30),
             (try_end),
           (else_try),
             (eq, ":quest_no", "qst_join_siege_with_army"),
			 (eq, 1, 0),
             (try_begin),
               (faction_slot_eq, "$players_kingdom", slot_faction_ai_state, sfai_attacking_center),
               (faction_get_slot, ":ai_object", "$players_kingdom", slot_faction_ai_object),
               (is_between, ":ai_object", walled_centers_begin, walled_centers_end),
               (party_get_battle_opponent, ":besieged_center", ":faction_marshall_party"),
               (eq, ":besieged_center", ":ai_object"),
               #army is assaulting the center
               (assign, ":result", ":quest_no"),
               (quest_set_slot, ":result", slot_quest_target_center, ":ai_object"),
               (quest_set_slot, ":result", slot_quest_expiration_days, 2),
               (quest_set_slot, ":result", slot_quest_dont_give_again_period, 15),
             (try_end),
           (else_try),
             (eq, ":quest_no", "qst_scout_waypoints"),
             (try_begin),
               (assign, ":end_cond", 100),
               (assign, "$qst_scout_waypoints_wp_1", -1),
               (assign, "$qst_scout_waypoints_wp_2", -1),
               (assign, "$qst_scout_waypoints_wp_3", -1),
               (assign, ":continue", 0),
               (try_for_range, ":unused", 0, ":end_cond"),
                 (try_begin),
                   (lt, "$qst_scout_waypoints_wp_1", 0),
                   (call_script, "script_cf_get_random_enemy_center_within_range", ":faction_marshall_party", 50),
                   (assign, "$qst_scout_waypoints_wp_1", reg0),
                 (try_end),
                 (try_begin),
                   (lt, "$qst_scout_waypoints_wp_2", 0),
                   (call_script, "script_cf_get_random_enemy_center_within_range", ":faction_marshall_party", 50),
                   (neq, "$qst_scout_waypoints_wp_1", reg0),
                   (assign, "$qst_scout_waypoints_wp_2", reg0),
                 (try_end),
                 (try_begin),
                   (lt, "$qst_scout_waypoints_wp_3", 0),
                   (call_script, "script_cf_get_random_enemy_center_within_range", ":faction_marshall_party", 50),
                   (neq, "$qst_scout_waypoints_wp_1", reg0),
                   (neq, "$qst_scout_waypoints_wp_2", reg0),
                   (assign, "$qst_scout_waypoints_wp_3", reg0),
                 (try_end),
                 (neq, "$qst_scout_waypoints_wp_1", "$qst_scout_waypoints_wp_2"),
                 (neq, "$qst_scout_waypoints_wp_1", "$qst_scout_waypoints_wp_2"),
                 (neq, "$qst_scout_waypoints_wp_2", "$qst_scout_waypoints_wp_3"),
                 (ge, "$qst_scout_waypoints_wp_1", 0),
                 (ge, "$qst_scout_waypoints_wp_2", 0),
                 (ge, "$qst_scout_waypoints_wp_3", 0),
                 (assign, ":end_cond", 0),
                 (assign, ":continue", 1),
               (try_end),
               (eq, ":continue", 1),
               (assign, "$qst_scout_waypoints_wp_1_visited", 0),
               (assign, "$qst_scout_waypoints_wp_2_visited", 0),
               (assign, "$qst_scout_waypoints_wp_3_visited", 0),
               (assign, ":result", "qst_scout_waypoints"),
               (quest_set_slot, ":result", slot_quest_expiration_days, 7),
               (quest_set_slot, ":result", slot_quest_dont_give_again_period, 25),
             (try_end),
           (try_end),
         (try_end),

         (try_begin),
           (neq, ":result", -1),
           (quest_set_slot, ":result", slot_quest_current_state, 0),
           (quest_set_slot, ":result", slot_quest_giver_troop, ":faction_marshall"),
           (try_begin),
             (eq, ":result", "qst_join_siege_with_army"),
             (jump_to_menu, "mnu_kingdom_army_quest_join_siege_order"),
           (else_try),
             (assign, "$g_random_army_quest", ":result"),
             (quest_set_slot, "$g_random_army_quest", slot_quest_giver_troop, ":faction_marshall"),
             (jump_to_menu, "mnu_kingdom_army_quest_messenger"),
           (try_end),
         (try_end),
       (try_end),
     (else_try),
       (val_add, "$g_player_follow_army_warnings", 1),
       (try_begin),
         (lt, "$g_player_follow_army_warnings", 15),
         (try_begin),
           (store_mod, ":follow_mod", "$g_player_follow_army_warnings", 3),
           (eq, ":follow_mod", 0),
           (str_store_troop_name_link, s1, ":faction_marshall"),
           (try_begin),
             (lt, "$g_player_follow_army_warnings", 8),
#             (display_message, "str_marshal_warning"),
           (else_try),
             (display_message, "str_marshal_warning"),
           (try_end),
         (try_end),
       (else_try),
         (jump_to_menu, "mnu_kingdom_army_follow_failed"),
       (try_end),
     (try_end),
    ]),

# Move cattle herd
(0.5, [(check_quest_active,"qst_move_cattle_herd"),
         (neg|check_quest_concluded,"qst_move_cattle_herd"),
         (quest_get_slot, ":target_party", "qst_move_cattle_herd", slot_quest_target_party),
         (quest_get_slot, ":target_center", "qst_move_cattle_herd", slot_quest_target_center),
         (store_distance_to_party_from_party, ":dist",":target_party", ":target_center"),
         (lt, ":dist", 3),
         (remove_party, ":target_party"),
         (call_script, "script_succeed_quest", "qst_move_cattle_herd"),
    ]),

  (2, [
       (try_for_range, ":troop_no", active_npcs_begin, active_npcs_end),
		 (troop_slot_eq, ":troop_no", slot_troop_occupation, slto_kingdom_hero),
		 (troop_get_slot, ":party_no", ":troop_no", slot_troop_leaded_party),
         (ge, ":party_no", 1),
		 (party_is_active, ":party_no"),
         (party_slot_eq, ":party_no", slot_party_following_player, 1),
         (store_current_hours, ":cur_time"),
         (neg|party_slot_ge, ":party_no", slot_party_follow_player_until_time, ":cur_time"),
         (party_set_slot, ":party_no", slot_party_commander_party, -1),
         (party_set_slot, ":party_no", slot_party_following_player, 0),
         (assign,  ":dont_follow_period", 200),
         (store_add, ":dont_follow_time", ":cur_time", ":dont_follow_period"),
         (party_set_slot, ":party_no", slot_party_dont_follow_player_until_time,  ":dont_follow_time"),
       (try_end),
    ]),

# Deliver cattle and deliver cattle to army
(0.5,
   [
     (try_begin),
       (check_quest_active,"qst_deliver_cattle"),
       (neg|check_quest_succeeded, "qst_deliver_cattle"),
       (quest_get_slot, ":target_center", "qst_deliver_cattle", slot_quest_target_center),
       (quest_get_slot, ":target_amount", "qst_deliver_cattle", slot_quest_target_amount),
       (quest_get_slot, ":cur_amount", "qst_deliver_cattle", slot_quest_current_state),
       (store_sub, ":left_amount", ":target_amount", ":cur_amount"),
       (call_script, "script_remove_cattles_if_herd_is_close_to_party", ":target_center", ":left_amount"),
       (val_add, ":cur_amount", reg0),
       (quest_set_slot, "qst_deliver_cattle", slot_quest_current_state, ":cur_amount"),
       (le, ":target_amount", ":cur_amount"),
       (call_script, "script_succeed_quest", "qst_deliver_cattle"),
     (try_end),
     (try_begin),
       (check_quest_active, "qst_deliver_cattle_to_army"),
       (neg|check_quest_succeeded, "qst_deliver_cattle_to_army"),
       (quest_get_slot, ":giver_troop", "qst_deliver_cattle_to_army", slot_quest_giver_troop),
       (troop_get_slot, ":target_party", ":giver_troop", slot_troop_leaded_party),
       (try_begin),
         (gt, ":target_party", 0),
         (quest_get_slot, ":target_amount", "qst_deliver_cattle_to_army", slot_quest_target_amount),
         (quest_get_slot, ":cur_amount", "qst_deliver_cattle_to_army", slot_quest_current_state),
         (store_sub, ":left_amount", ":target_amount", ":cur_amount"),
         (call_script, "script_remove_cattles_if_herd_is_close_to_party", ":target_party", ":left_amount"),
         (val_add, ":cur_amount", reg0),
         (quest_set_slot, "qst_deliver_cattle_to_army", slot_quest_current_state, ":cur_amount"),
         (try_begin),
           (le, ":target_amount", ":cur_amount"),
           (call_script, "script_succeed_quest", "qst_deliver_cattle_to_army"),
         (try_end),
       (else_try),
         (call_script, "script_abort_quest", "qst_deliver_cattle_to_army", 0),
       (try_end),
     (try_end),
     ]),

# Train peasants against bandits
(1,
   [
     (neg|map_free),
     (check_quest_active, "qst_train_peasants_against_bandits"),
     (neg|check_quest_concluded, "qst_train_peasants_against_bandits"),
     (eq, "$qst_train_peasants_against_bandits_currently_training", 1),
     (val_add, "$qst_train_peasants_against_bandits_num_hours_trained", 1),
     (call_script, "script_get_max_skill_of_player_party", "skl_trainer"),
     (assign, ":trainer_skill", reg0),
     (store_sub, ":needed_hours", 20, ":trainer_skill"),
     (val_mul, ":needed_hours", 3),
     (val_div, ":needed_hours", 5),
     (ge, "$qst_train_peasants_against_bandits_num_hours_trained", ":needed_hours"),
     (assign, "$qst_train_peasants_against_bandits_num_hours_trained", 0),
     (rest_for_hours, 0, 0, 0), #stop resting
     (jump_to_menu, "mnu_train_peasants_against_bandits_ready"),
     ]),

# Scout waypoints
(1,
   [
     (check_quest_active,"qst_scout_waypoints"),
     (neg|check_quest_succeeded, "qst_scout_waypoints"),
     (try_begin),
       (eq, "$qst_scout_waypoints_wp_1_visited", 0),
       (store_distance_to_party_from_party, ":distance", "$qst_scout_waypoints_wp_1", "p_main_party"),
       (le, ":distance", 3),
       (assign, "$qst_scout_waypoints_wp_1_visited", 1),
       (str_store_party_name_link, s1, "$qst_scout_waypoints_wp_1"),
       (display_message, "@{s1} is scouted."),
     (try_end),
     (try_begin),
       (eq, "$qst_scout_waypoints_wp_2_visited", 0),
       (store_distance_to_party_from_party, ":distance", "$qst_scout_waypoints_wp_2", "p_main_party"),
       (le, ":distance", 3),
       (assign, "$qst_scout_waypoints_wp_2_visited", 1),
       (str_store_party_name_link, s1, "$qst_scout_waypoints_wp_2"),
       (display_message, "@{s1} is scouted."),
     (try_end),
     (try_begin),
       (eq, "$qst_scout_waypoints_wp_3_visited", 0),
       (store_distance_to_party_from_party, ":distance", "$qst_scout_waypoints_wp_3", "p_main_party"),
       (le, ":distance", 3),
       (assign, "$qst_scout_waypoints_wp_3_visited", 1),
       (str_store_party_name_link, s1, "$qst_scout_waypoints_wp_3"),
       (display_message, "@{s1} is scouted."),
     (try_end),
     (eq, "$qst_scout_waypoints_wp_1_visited", 1),
     (eq, "$qst_scout_waypoints_wp_2_visited", 1),
     (eq, "$qst_scout_waypoints_wp_3_visited", 1),
     (call_script, "script_succeed_quest", "qst_scout_waypoints"),
     ]),

# Kill local merchant
(3, [(neg|map_free),
       (check_quest_active, "qst_kill_local_merchant"),
       (quest_slot_eq, "qst_kill_local_merchant", slot_quest_current_state, 0),
       (quest_set_slot, "qst_kill_local_merchant", slot_quest_current_state, 1),
       (rest_for_hours, 0, 0, 0), #stop resting
       (assign, "$auto_enter_town", "$qst_kill_local_merchant_center"),
       (assign, "$quest_auto_menu", "mnu_kill_local_merchant_begin"),
       ]),

# Collect taxes
(1, [(neg|map_free),
       (check_quest_active, "qst_collect_taxes"),
       (eq, "$g_player_is_captive", 0),
       (eq, "$qst_collect_taxes_currently_collecting", 1),
       #SB : TODO add siege/raid interruption
       (quest_get_slot, ":quest_current_state", "qst_collect_taxes", slot_quest_current_state),
       (this_or_next|eq, ":quest_current_state", 1),
       (this_or_next|eq, ":quest_current_state", 2),
       (eq, ":quest_current_state", 3),
       (quest_get_slot, ":left_hours", "qst_collect_taxes", slot_quest_target_amount),
       (val_sub, ":left_hours", 1),
       (quest_set_slot, "qst_collect_taxes", slot_quest_target_amount, ":left_hours"),
       (call_script, "script_get_max_skill_of_player_party", "skl_trade"),

       (try_begin),
         (lt, ":left_hours", 0),
         (assign, ":quest_current_state", 4),
         (quest_set_slot, "qst_collect_taxes", slot_quest_current_state, 4),
         (rest_for_hours, 0, 0, 0), #stop resting
         (jump_to_menu, "mnu_collect_taxes_complete"),
       (else_try),
         #Continue collecting taxes
         (assign, ":max_collected_tax", "$qst_collect_taxes_hourly_income"),
         (party_get_slot, ":prosperity", "$g_encountered_party", slot_town_prosperity),
         (store_add, ":multiplier", 30, ":prosperity"),
         (val_mul, ":max_collected_tax", ":multiplier"),
         (val_div, ":max_collected_tax", 80),#Prosperity of 50 gives the default values

         (try_begin),
           (eq, "$qst_collect_taxes_halve_taxes", 1),
           (val_div, ":max_collected_tax", 2),
         (try_end),
         (val_max, ":max_collected_tax", 2),
         (store_random_in_range, ":collected_tax", 1, ":max_collected_tax"),
         (quest_get_slot, ":cur_collected", "qst_collect_taxes", slot_quest_gold_reward),
         (val_add, ":cur_collected", ":collected_tax"),
         (quest_set_slot, "qst_collect_taxes", slot_quest_gold_reward, ":cur_collected"),
         (call_script, "script_troop_add_gold", "trp_player", ":collected_tax"),
       (try_end),
       (try_begin),
         (eq, ":quest_current_state", 1),
         (val_sub, "$qst_collect_taxes_menu_counter", 1),
         (le, "$qst_collect_taxes_menu_counter", 0),
         (quest_set_slot, "qst_collect_taxes", slot_quest_current_state, 2),
         (jump_to_menu, "mnu_collect_taxes_revolt_warning"),
       (else_try), #Chance of revolt against player
         (eq, ":quest_current_state", 2),
         (val_sub, "$qst_collect_taxes_unrest_counter", 1),
         (le, "$qst_collect_taxes_unrest_counter", 0),
         (eq, "$qst_collect_taxes_halve_taxes", 0),
         (quest_set_slot, "qst_collect_taxes", slot_quest_current_state, 3),

         (store_div, ":unrest_chance", 10000, "$qst_collect_taxes_total_hours"),
         (val_add, ":unrest_chance",30),

         (store_random_in_range, ":unrest_roll", 0, 1000),
         (try_begin),
           (lt, ":unrest_roll", ":unrest_chance"),
           (jump_to_menu, "mnu_collect_taxes_revolt"),
         (try_end),
       (try_end),
       ]),

#persuade_lords_to_make_peace begin #SB: range check instead of gt 0
(72, [(is_between, "$g_force_peace_faction_1", kingdoms_begin, kingdoms_end),
        (is_between, "$g_force_peace_faction_2", kingdoms_begin, kingdoms_end),
        (try_begin),
          (store_relation, ":relation", "$g_force_peace_faction_1", "$g_force_peace_faction_2"),
          (lt, ":relation", 0),
          (call_script, "script_diplomacy_start_peace_between_kingdoms", "$g_force_peace_faction_1", "$g_force_peace_faction_2", 1),
        (try_end),
        (assign, "$g_force_peace_faction_1", 0),
        (assign, "$g_force_peace_faction_2", 0),
       ]),

#NPC changes begin
#Resolve one issue each hour
(1,
   [
    (str_store_string, s51, "str_no_trigger_noted"),

    # Rejoining party
    (try_begin),
      (gt, "$npc_to_rejoin_party", 0),
      (eq, "$g_infinite_camping", 0),
      (try_begin), #SB : allow hired blade to pass
        (this_or_next|eq, "$npc_to_rejoin_party", "trp_hired_blade"),
        (this_or_next|is_between, "$npc_to_rejoin_party", town_walkers_begin, town_walkers_end),
        (neg|main_party_has_troop, "$npc_to_rejoin_party"),
        (neq, "$g_player_is_captive", 1),
        (str_store_string, s51, "str_triggered_by_npc_to_rejoin_party"),
        (assign, "$npc_map_talk_context", slot_troop_days_on_mission),
        (start_map_conversation, "$npc_to_rejoin_party", -1),
      (else_try),
        (is_between, "$npc_to_rejoin_party", companions_begin, companions_end),
        (troop_set_slot, "$npc_to_rejoin_party", slot_troop_current_mission, npc_mission_rejoin_when_possible),
        (assign, "$npc_to_rejoin_party", 0),
      (try_end),
      # Here do NPC that is quitting
    (else_try),
      (gt, "$npc_is_quitting", 0),
      (eq, "$g_infinite_camping", 0),
      (try_begin),
        #(neg|is_edit_mode_enabled),
		(eq, "$disable_npc_complaints", 0),
		(main_party_has_troop, "$npc_is_quitting"),
        (neq, "$g_player_is_captive", 1),
        ##diplomacy start+ disable spouse quitting to avoid problems
        (neg|troop_slot_eq, "trp_player", slot_troop_spouse, "$npc_is_quitting"),
        (neg|troop_slot_eq, "$npc_is_quitting", slot_troop_spouse, "trp_player"),
        ##diplomacy end+
        (str_store_string, s51, "str_triggered_by_npc_is_quitting"),
        (start_map_conversation, "$npc_is_quitting", -1),
      (else_try),
        (assign, "$npc_is_quitting", 0),
      (try_end),
    #NPC with grievance
    (else_try), #### Grievance
      (gt, "$npc_with_grievance", 0),
      (eq, "$g_infinite_camping", 0),
      (eq, "$disable_npc_complaints", 0),
      (try_begin),
        (main_party_has_troop, "$npc_with_grievance"),
        (neq, "$g_player_is_captive", 1),
        (str_store_string, s51, "str_triggered_by_npc_has_grievance"),
        (assign, "$npc_map_talk_context", slot_troop_morality_state),
        (start_map_conversation, "$npc_with_grievance", -1),
      (else_try),
        (assign, "$npc_with_grievance", 0),
      (try_end),
    (else_try),
      (gt, "$npc_with_personality_clash", 0),
      (eq, "$g_infinite_camping", 0),
      (eq, "$disable_npc_complaints", 0),
      (troop_get_slot, ":object", "$npc_with_personality_clash", slot_troop_personalityclash_object),
      (try_begin),
        (main_party_has_troop, "$npc_with_personality_clash"),
        (main_party_has_troop, ":object"),
        (neq, "$g_player_is_captive", 1),

        (assign, "$npc_map_talk_context", slot_troop_personalityclash_state),
        (str_store_string, s51, "str_triggered_by_npc_has_personality_clash"),
        (start_map_conversation, "$npc_with_personality_clash", -1),
      (else_try),
        (assign, "$npc_with_personality_clash", 0),
      (try_end),
    (else_try), #### Political issue
      (gt, "$npc_with_political_grievance", 0),
      (eq, "$g_infinite_camping", 0),
      (eq, "$disable_npc_complaints", 0),
      (try_begin),
        (main_party_has_troop, "$npc_with_political_grievance"),
        (neq, "$g_player_is_captive", 1),

        (str_store_string, s51, "str_triggered_by_npc_has_political_grievance"),
        (assign, "$npc_map_talk_context", slot_troop_kingsupport_objection_state),
        (start_map_conversation, "$npc_with_political_grievance", -1),
      (else_try),
        (assign, "$npc_with_political_grievance", 0),
      (try_end),
    (else_try),
      (eq, "$disable_sisterly_advice", 0),
      (eq, "$g_infinite_camping", 0),
      (gt, "$npc_with_sisterly_advice", 0),
      (try_begin),
        (main_party_has_troop, "$npc_with_sisterly_advice"),
        (neq, "$g_player_is_captive", 1),

        ##diplomacy start+
        (troop_slot_ge, "$npc_with_sisterly_advice", slot_troop_woman_to_woman_string, 1),
        ##diplomacy end+
        (assign, "$npc_map_talk_context", slot_troop_woman_to_woman_string), #was npc_with_sisterly advice
        (start_map_conversation, "$npc_with_sisterly_advice", -1),
      (else_try),
        (assign, "$npc_with_sisterly_advice", 0),
      (try_end),
    (else_try), #check for regional background
      (eq, "$disable_local_histories", 0),
      (eq, "$g_infinite_camping", 0),
      (try_for_range, ":npc", companions_begin, companions_end),
        (main_party_has_troop, ":npc"),
        (troop_slot_eq, ":npc", slot_troop_home_speech_delivered, 0),
        (troop_get_slot, ":home", ":npc", slot_troop_home),
        (gt, ":home", 0),
        (store_distance_to_party_from_party, ":distance", ":home", "p_main_party"),
        (lt, ":distance", 7),
        (assign, "$npc_map_talk_context", slot_troop_home),
        (str_store_string, s51, "str_triggered_by_local_histories"),
        (start_map_conversation, ":npc", -1),
      (try_end),
    (try_end),

    # #add pretender to party if not active
    # (try_begin),
      # (check_quest_active, "qst_rebel_against_kingdom"),
      # (is_between, "$supported_pretender", pretenders_begin, pretenders_end),
      # (neg|main_party_has_troop, "$supported_pretender"),
      # (neg|troop_slot_eq, "$supported_pretender", slot_troop_occupation, slto_kingdom_hero),
      # (party_add_members, "p_main_party", "$supported_pretender", 1),
    # (try_end),

    # #make player marshal of rebel faction
    # (try_begin),
      # (check_quest_active, "qst_rebel_against_kingdom"),
      # (is_between, "$supported_pretender", pretenders_begin, pretenders_end),
      # (main_party_has_troop, "$supported_pretender"),
      # (neg|faction_slot_eq, "fac_player_supporters_faction", slot_faction_marshall, "trp_player"),
      # (call_script, "script_appoint_faction_marshall", "fac_player_supporters_faction", "trp_player"),
    # (try_end),
    ]),
#NPC changes end

(4,
   ##diplomacy start+ Add support for promoted faction ladies
   ##OLD:
   #[(try_for_range, ":troop_no", active_npcs_begin, active_npcs_end),
   ##NEW:
   [(try_for_range, ":troop_no", heroes_begin, heroes_end),
      (this_or_next|is_between, ":troop_no", active_npcs_begin, active_npcs_end),
      (troop_slot_eq, ":troop_no", slot_troop_occupation, slto_kingdom_hero),
   ##diplomacy end+
      (troop_slot_ge, ":troop_no", slot_troop_change_to_faction, 1),
      (store_troop_faction, ":faction_no", ":troop_no"),
      (troop_get_slot, ":new_faction_no", ":troop_no", slot_troop_change_to_faction),
      (troop_get_slot, ":party_no", ":troop_no", slot_troop_leaded_party),
      (assign, ":continue", 0),
      (try_begin),
        (le, ":party_no", 0),
        #(troop_slot_eq, ":troop_no", slot_troop_is_prisoner, 0),
        (neg|troop_slot_ge, ":troop_no", slot_troop_prisoner_of_party, 0),
        (assign, ":continue", 1),
      (else_try),
        (gt, ":party_no", 0),

        #checking if the party is outside the centers
        (party_get_attached_to, ":cur_center_no", ":party_no"),
        (try_begin),
          (lt, ":cur_center_no", 0),
          (party_get_cur_town, ":cur_center_no", ":party_no"),
        (try_end),
        (this_or_next|neg|is_between, ":cur_center_no", centers_begin, centers_end),
        (party_slot_eq, ":cur_center_no", slot_town_lord, ":troop_no"),

        #checking if the party is away from his original faction parties
        ##diplomacy start+
        ##Add support for promoted faction lades.
        ##OLD:
        #(assign, ":end_cond", active_npcs_end),
        ##NEW:
        (assign, ":end_cond", heroes_end),
        ##diplomacy end+
        (try_for_range, ":enemy_troop_no", heroes_begin, ":end_cond"),
          #SB : self-check prevention
          (neq, ":enemy_troop_no", ":troop_no"),
          (troop_slot_eq, ":enemy_troop_no", slot_troop_occupation, slto_kingdom_hero),
          (troop_get_slot, ":enemy_party_no", ":enemy_troop_no", slot_troop_leaded_party),
          (party_is_active, ":enemy_party_no"),
          (store_faction_of_party, ":enemy_faction_no", ":enemy_party_no"),
          (eq, ":enemy_faction_no", ":faction_no"),
          (store_distance_to_party_from_party, ":dist", ":party_no", ":enemy_party_no"),
          (lt, ":dist", 4),
          (assign, ":end_cond", 0),
        (try_end),
        (neq, ":end_cond", 0),
        (assign, ":continue", 1),
      (try_end),
      (eq, ":continue", 1),

		(try_begin),
			(ge, "$cheat_mode", 1),
			(str_store_troop_name, s4, ":troop_no"),
			(display_message, "@{!}DEBUG - {s4} faction changed from slot_troop_change_to_faction"),
		(try_end),

      (call_script, "script_change_troop_faction", ":troop_no", ":new_faction_no"),
      (troop_set_slot, ":troop_no", slot_troop_change_to_faction, 0),
      (try_begin),
        (is_between, ":new_faction_no", kingdoms_begin, kingdoms_end),
        (str_store_troop_name_link, s1, ":troop_no"),
        (str_store_faction_name_link, s2, ":faction_no"),
        (str_store_faction_name_link, s3, ":new_faction_no"),
        (faction_get_color, ":color", ":new_faction_no"),
        (display_log_message, "@{s1} has switched from {s2} to {s3}.", ":color"), #SB : colorize
        (try_begin),
          (eq, ":faction_no", "$players_kingdom"),
          (call_script, "script_add_notification_menu", "mnu_notification_troop_left_players_faction", ":troop_no", ":new_faction_no"),
        (else_try),
          (eq, ":new_faction_no", "$players_kingdom"),
          (call_script, "script_add_notification_menu", "mnu_notification_troop_joined_players_faction", ":troop_no", ":faction_no"),
        (try_end),
      (try_end),
    (try_end),
    ]),

(1,
   [
     (eq, "$cheat_mode", 1),
     (try_for_range, ":center_no", centers_begin, centers_end),
       (party_get_battle_opponent, ":besieger_party", ":center_no"),
       (try_begin),
         (gt, ":besieger_party", 0),
         (str_store_party_name, s2, ":center_no"),
         (str_store_party_name, s3, ":besieger_party"),
         (display_message, "@{!}DEBUG : {s2} is besieging by {s3}"),
       (try_end),
     (try_end),
     ]),

(1,
   [
     (store_current_day, ":cur_day"),
     (gt, ":cur_day", "$g_last_report_control_day"),
     (store_time_of_day, ":cur_hour"),
     (ge, ":cur_hour", 18),

     (store_random_in_range, ":rand_no", 0, 4),
     (this_or_next|ge, ":cur_hour", 22),
     (eq, ":rand_no", 0),

     (assign, "$g_last_report_control_day", ":cur_day"),

     (store_troop_gold, ":gold", "trp_player"),

     (try_begin),
       (lt, ":gold", 0),
       (store_sub, ":gold_difference", 0, ":gold"),
       (troop_add_gold, "trp_player", ":gold_difference"),
     (try_end),

     (party_get_morale, ":main_party_morale", "p_main_party"),

     #(assign, ":swadian_soldiers_are_upset_message_showed", 0),
     #(assign, ":vaegir_soldiers_are_upset_message_showed", 0),
     #(assign, ":khergit_soldiers_are_upset_message_showed", 0),
     #(assign, ":nord_soldiers_are_upset_message_showed", 0),
     #(assign, ":rhodok_soldiers_are_upset_message_showed", 0),

     (try_begin),
       (str_store_string, s1, "str_party_morale_is_low"),
       (str_clear, s2),

       (party_get_num_companion_stacks, ":num_stacks","p_main_party"),
       (assign, ":num_deserters_total", 0),
       (try_for_range_backwards, ":i_stack", 0, ":num_stacks"),
         (party_stack_get_troop_id, ":stack_troop", "p_main_party", ":i_stack"),
         (neg|troop_is_hero, ":stack_troop"),
         (party_stack_get_size, ":stack_size", "p_main_party", ":i_stack"),

         (store_troop_faction, ":faction_no", ":stack_troop"),

         (assign, ":troop_morale", ":main_party_morale"),
         (try_begin),
           (ge, ":faction_no", npc_kingdoms_begin),
           (lt, ":faction_no", npc_kingdoms_end),

           (faction_get_slot, ":troop_morale_addition", ":faction_no",  slot_faction_morale_of_player_troops),
           (val_div, ":troop_morale_addition", 100),
           (val_add, ":troop_morale", ":troop_morale_addition"),
         (try_end),

         (lt, ":troop_morale", 32),
         (store_sub, ":desert_prob", 36, ":troop_morale"),
         (val_div, ":desert_prob", 4),

         (assign, ":num_deserters_from_that_troop", 0),
         (try_for_range, ":unused", 0, ":stack_size"),
           (store_random_in_range, ":rand_no", 0, 100),
           (lt, ":rand_no", ":desert_prob"),
           (val_add, ":num_deserters_from_that_troop", 1),
           #p.remove_members_from_stack(i_stack,cur_deserters, &main_party_instances);
           (remove_member_from_party, ":stack_troop", "p_main_party"),
         (try_end),
         (try_begin),
           (ge, ":num_deserters_from_that_troop", 1),
           (str_store_troop_name, s2, ":stack_troop"),
           (assign, reg0, ":num_deserters_from_that_troop"),

#           (try_begin),
#             (lt, ":troop_morale_addition", -2),
#             (ge, ":main_party_morale", 28),
#             (try_begin),
#               (eq, ":faction_no", "fac_kingdom_1"),
#               (eq, ":swadian_soldiers_are_upset_message_showed", 0),
#               (str_store_string, s3, "str_swadian_soldiers_are_upset"),
#               (assign, ":swadian_soldiers_are_upset_message_showed", 1),
#             (else_try),
#               (eq, ":faction_no", "fac_kingdom_2"),
#               (eq, ":vaegir_soldiers_are_upset_message_showed", 0),
#               (str_store_string, s3, "str_vaegir_soldiers_are_upset"),
#               (assign, ":vaegir_soldiers_are_upset_message_showed", 1),
#             (else_try),
#               (eq, ":faction_no", "fac_kingdom_3"),
#               (eq, ":khergit_soldiers_are_upset_message_showed", 0),
#               (str_store_string, s3, "str_khergit_soldiers_are_upset"),
#               (assign, ":khergit_soldiers_are_upset_message_showed", 1),
#             (else_try),
#               (eq, ":faction_no", "fac_kingdom_4"),
#               (eq, ":nord_soldiers_are_upset_message_showed", 0),
#               (str_store_string, s3, "str_nord_soldiers_are_upset"),
#               (assign, ":nord_soldiers_are_upset_message_showed", 1),
#             (else_try),
#               (eq, ":faction_no", "fac_kingdom_5"),
#               (eq, ":rhodok_soldiers_are_upset_message_showed", 0),
#               (str_store_string, s3, "str_rhodok_soldiers_are_upset"),
#               (assign, ":rhodok_soldiers_are_upset_message_showed", 1),
#             (try_end),
#             (str_store_string, s1, "@{!}{s1} {s3}"),
#           (try_end),

           (try_begin),
             (ge, ":num_deserters_total", 1),
             (str_store_string, s1, "str_s1_reg0_s2"),
           (else_try),
             (str_store_string, s3, s1),
             (str_store_string, s1, "str_s3_reg0_s2"),
           (try_end),
           (val_add, ":num_deserters_total", ":num_deserters_from_that_troop"),
         (try_end),
       (try_end),

       (try_begin),
         (ge, ":num_deserters_total", 1),

         (try_begin),
           (ge, ":num_deserters_total", 2),
           (str_store_string, s2, "str_have_deserted_the_party"),
         (else_try),
           (str_store_string, s2, "str_has_deserted_the_party"),
         (try_end),

         (str_store_string, s1, "str_s1_s2"),

         (eq, "$g_infinite_camping", 0),

         (tutorial_box, s1, "str_weekly_report"),
       (try_end),
     (try_end),
 ]),
 # reserved for future use. For backward compatibility, we need to use these triggers instead of creating new ones.

# (1,
   # [
     # (call_script, "script_calculate_castle_prosperities_by_using_its_villages"),

     # (store_add, ":fac_kingdom_6_plus_one", "fac_kingdom_6", 1),

     # (try_for_range, ":faction_1", "fac_kingdom_1", ":fac_kingdom_6_plus_one"),
       # (try_for_range, ":faction_2", "fac_kingdom_1", ":fac_kingdom_6_plus_one"),
         # (store_relation, ":faction_relation", ":faction_1", ":faction_2"),
         # (str_store_faction_name, s7, ":faction_1"),
         # (str_store_faction_name, s8, ":faction_2"),
         # (neq, ":faction_1", ":faction_2"),
         # (assign, reg1, ":faction_relation"),
         # #(display_message, "@{s7}-{s8}, relation is {reg1}"),
       # (try_end),
     # (try_end),
   # ]),

(1,
   [
     (try_begin),
       (eq, "$g_player_is_captive", 1),
       (neg|party_is_active, "$capturer_party"),
       (rest_for_hours, 0, 0, 0),
     (try_end),

     ##diplomacy begin
      #seems to be a native bug
     (is_between, "$next_center_will_be_fired", villages_begin, villages_end),
     ##diplomacy end
     (assign, ":village_no", "$next_center_will_be_fired"),
     (party_get_slot, ":is_there_already_fire", ":village_no", slot_village_smoke_added),
     (eq, ":is_there_already_fire", 0),


     (try_begin),
       (party_get_slot, ":bound_center", ":village_no", slot_village_bound_center),
       (party_get_slot, ":last_nearby_fire_time", ":bound_center", slot_town_last_nearby_fire_time),
       (store_current_hours, ":cur_hours"),

	   (try_begin),
		(eq, "$cheat_mode", 1),
		(is_between, ":village_no", centers_begin, centers_end),
		(is_between, ":bound_center", centers_begin, centers_end),
		(str_store_party_name, s4, ":village_no"),
		(str_store_party_name, s5, ":bound_center"),
		(store_current_hours, reg3),
        (party_get_slot, reg4, ":bound_center", slot_town_last_nearby_fire_time),
		(display_message, "@{!}DEBUG - Checking fire at {s4} for {s5} - current time {reg3}, last nearby fire {reg4}"),
	   (try_end),


       (eq, ":cur_hours", ":last_nearby_fire_time"),
       (party_add_particle_system, ":village_no", "psys_map_village_fire"),
       (party_add_particle_system, ":village_no", "psys_map_village_fire_smoke"),
     (else_try),
       (store_add, ":last_nearby_fire_finish_time", ":last_nearby_fire_time", fire_duration),
       (eq, ":last_nearby_fire_finish_time", ":cur_hours"),
       (party_clear_particle_systems, ":village_no"),
     (try_end),


   ]),

(24,
   [
    (val_sub, "$g_dont_give_fief_to_player_days", 1),
    (val_max, "$g_dont_give_fief_to_player_days", -1),
    (val_sub, "$g_dont_give_marshalship_to_player_days", 1),
    (val_max, "$g_dont_give_marshalship_to_player_days", -1),

    # (call_script, "script_dplmc_version_checker"), #SB : moved to script call

    #The following scripts are to end quests which should have cancelled, but did not because of a bug
    (try_begin),
      (check_quest_active, "qst_formal_marriage_proposal"),
      (check_quest_failed, "qst_formal_marriage_proposal"),
      (call_script, "script_end_quest", "qst_formal_marriage_proposal"),
    (try_end),

    (try_begin),
      (check_quest_active, "qst_lend_companion"),
      (quest_get_slot, ":giver_troop", "qst_lend_companion", slot_quest_giver_troop),
      (store_faction_of_troop, ":giver_troop_faction", ":giver_troop"),
      (store_relation, ":faction_relation", ":giver_troop_faction", "$players_kingdom"),
      (this_or_next|lt, ":faction_relation", 0),
      (neg|is_between, ":giver_troop_faction", kingdoms_begin, kingdoms_end),
      (call_script, "script_abort_quest", "qst_lend_companion", 0),
    (try_end),

    (try_begin),
      (is_between, "$players_kingdom", kingdoms_begin, kingdoms_end),
      (neq, "$players_kingdom", "fac_player_supporters_faction"),
      (faction_slot_eq, "$players_kingdom", slot_faction_marshall, "trp_player"),
      (val_add, "$g_player_days_as_marshal", 1),
    (else_try),
      (assign, "$g_player_days_as_marshal", 0),
    (try_end),

    (try_for_range, ":town", towns_begin, towns_end),
      (party_get_slot, ":days_to_completion", ":town", slot_center_player_enterprise_days_until_complete),
      (ge, ":days_to_completion", 1),
      (val_sub, ":days_to_completion", 1),
      (party_set_slot, ":town", slot_center_player_enterprise_days_until_complete, ":days_to_completion"),
    (try_end),
    ]),

(24,
   [
      # Setting food bonuses in every 6 hours again and again because of a bug (we could not find its reason) which decreases especially slot_item_food_bonus slots of items to 0.

      (try_for_range,":food",food_begin,drink_end),
            (item_get_food_quality,":food_bonus", ":food"),
            (val_div,":food_bonus",10),
            # (val_max,":food_bonus",0),
            (item_set_slot, ":food", slot_item_food_bonus, ":food_bonus"),
      (try_end),
   ]),

  ##diplomacy begin
  #Troop AI Spouse: Spouse thinking
  (6,
   [
    (troop_get_slot, ":player_spouse", "trp_player", slot_troop_spouse),
    (ge, ":player_spouse", active_npcs_begin),#<-- skip the rest of the check when there is no spouse
    (try_for_parties, ":spouse_party"),
      (party_slot_eq, ":spouse_party", slot_party_type, dplmc_spt_spouse),

      (party_get_slot, ":spouse_target", ":spouse_party", slot_party_orders_object),
      (party_get_slot, ":home_center", ":spouse_party", slot_party_home_center),
      (store_distance_to_party_from_party, ":distance", ":spouse_party", ":spouse_target"),

      #Moving spouse to home village
      (try_begin),
        (le, ":distance", 1),
        (try_begin),
          (this_or_next|eq, ":spouse_target", "$g_player_court"),
          (eq, ":spouse_target", ":home_center"),
          (remove_party, ":spouse_party"),
          (troop_set_slot, ":player_spouse", slot_troop_cur_center, ":spouse_target"),
        (else_try),
          (try_begin),
            (is_between, ":spouse_target", villages_begin, villages_end),
            (party_get_slot,":cur_merchant",":spouse_target", slot_town_elder),
          (else_try),
            (party_get_slot,":cur_merchant",":spouse_target", slot_town_merchant),
          (try_end),
          (troop_get_slot, ":amount", ":player_spouse", dplmc_slot_troop_mission_diplomacy),
          (troop_remove_items, ":cur_merchant", "itm_bread", ":amount"),
          (party_set_ai_behavior, ":spouse_party", ai_bhvr_travel_to_party),
          (try_begin),
            (gt, "$g_player_court", 0),
            (party_set_slot, ":spouse_party", slot_party_ai_object, "$g_player_court"),
            (party_set_ai_object, ":spouse_party", "$g_player_court"),
          (else_try),
            (party_set_slot, ":spouse_party", slot_party_ai_object, ":home_center"),
            (party_set_ai_object, ":spouse_party", ":home_center"),
          (try_end),

          (troop_add_items, "trp_household_possessions", "itm_bread", ":amount"),
        (try_end),
      (try_end),
    (try_end),
    ]),

#Recruiter kit begin
## This trigger keeps the recruiters moving by assigning them targets.
 (1, #SB : half the number of calls
   [
   (try_for_parties, ":party_no"),
      (party_is_active, ":party_no"),
      (party_slot_eq,":party_no", slot_party_type, dplmc_spt_recruiter),

      (party_get_slot, ":needed", ":party_no", dplmc_slot_party_recruiter_needed_recruits),
      (party_get_slot, ":party_origin", ":party_no", dplmc_slot_party_recruiter_origin),
      (party_get_num_companion_stacks, ":stacks", ":party_no"),
      (assign, ":destruction", 1),
      (assign, ":quit", 0),

      (try_for_range, ":stack_no", 0, ":stacks"),
         (party_stack_get_troop_id, ":troop_id", ":party_no", ":stack_no"),
         (eq, ":troop_id", "trp_dplmc_recruiter"),
         (assign, ":destruction", 0),
      (try_end),
      (try_begin),
         (party_get_battle_opponent, ":opponent", ":party_no"),
         (lt, ":opponent", 0),
         (eq, ":destruction", 1),
         # (party_get_slot, ":party_origin", ":party_no", dplmc_slot_party_recruiter_origin), #SB : moved top
         (str_store_party_name_link, s13, ":party_origin"),
         (assign, reg10, ":needed"),
         #SB : less verbose recruits
         (display_log_message, "@Your recruiter who was commissioned to hire {reg10} recruits for {s13} has been defeated!", message_defeated), #SB : message code
         (remove_party, ":party_no"),
         (assign, ":quit", 1),
      (try_end),

      #waihti
      (try_begin),
        (eq, ":quit", 0),
        # (party_get_slot, ":party_origin", ":party_no", dplmc_slot_party_recruiter_origin), #SB : moved top
        (store_faction_of_party, ":origin_faction", ":party_origin"),
        (neq, ":origin_faction", "$players_kingdom"),
        (str_store_party_name_link, s13, ":party_origin"),
        # (assign, reg10, ":needed"),
        #SB : less verbose message, alternatively actually redirect the recruiter
        (display_log_message, "@{s13} has been taken by the enemy and your commissioned recruiter has vanished without a trace!", message_defeated), #SB : message code
        (remove_party, ":party_no"),
        (assign, ":quit", 1),
      (try_end),
      #waihti

      (eq, ":quit", 0),

      (party_get_num_companions, ":amount", ":party_no"),
      (val_sub, ":amount", 1),   #the recruiter himself doesn't count.

    #daedalus begin
    (party_get_slot, ":recruit_faction", ":party_no", dplmc_slot_party_recruiter_needed_recruits_faction),
    (try_begin),
      #daedalus end
      (lt, ":amount", ":needed"),  #If the recruiter has less troops than player ordered, new village will be set as target.
      (try_begin),
         #(get_party_ai_current_behavior, ":ai_bhvr", ":party_no"),
         #(eq, ":ai_bhvr", ai_bhvr_hold),
         (get_party_ai_object, ":previous_target", ":party_no"),
         (get_party_ai_behavior, ":previous_behavior", ":party_no"),
         (try_begin),
            (neq, ":previous_behavior", ai_bhvr_hold),
            (neq, ":previous_target", -1),
            (party_set_slot, ":previous_target", dplmc_slot_village_reserved_by_recruiter, 0),
         (try_end),
         (assign, ":min_distance", 999999),
         (assign, ":closest_village", -1),
         (try_for_range, ":village", villages_begin, villages_end),
            (store_distance_to_party_from_party, ":distance", ":party_no", ":village"),
            (lt, ":distance", ":min_distance"),
            (try_begin),
               (store_faction_of_party, ":village_current_faction", ":village"),
               (assign, ":faction_relation", 100),
               (try_begin),
                  (neq, ":village_current_faction", "$players_kingdom"),    # faction relation will be checked only if the village doesn't belong to the player's current faction
                  (store_relation, ":faction_relation", "$players_kingdom", ":village_current_faction"),
               (try_end),
               (ge, ":faction_relation", 0),
               (party_get_slot, ":village_relation", ":village", slot_center_player_relation),
               (ge, ":village_relation", 0),
               (party_get_slot, ":volunteers_in_village", ":village", slot_center_volunteer_troop_amount),
               (gt, ":volunteers_in_village", 0),
            #daedalus begin
               (party_get_slot, ":village_faction", ":village", slot_center_original_faction),
               (assign,":stop",1),
               (try_begin), #SB : or
                  (this_or_next|eq,":recruit_faction",-1),
                  (eq, ":village_faction", ":recruit_faction"),
                  (assign,":stop",0),
               (try_end),
               (neq,":stop",1),
            #daedalus end
               # (neg|party_slot_eq, ":village", slot_village_state, svs_looted),
               # (neg|party_slot_eq, ":village", slot_village_state, svs_being_raided),
               # (neg|party_slot_ge, ":village", slot_village_infested_by_bandits, 1),
               (call_script, "script_cf_village_normal_cond", ":village"), #SB : script condition
               (neg|party_slot_eq, ":village", dplmc_slot_village_reserved_by_recruiter, 1),
               (assign, ":min_distance", ":distance"),
               (assign, ":closest_village", ":village"),
            (try_end),
         (try_end),
         (gt, ":closest_village", -1),
         (party_set_ai_behavior, ":party_no", ai_bhvr_travel_to_party),
         (party_set_ai_object, ":party_no", ":closest_village"),
         (party_set_slot, ":party_no", slot_party_ai_object, ":closest_village"),
         (party_set_slot, ":closest_village", dplmc_slot_village_reserved_by_recruiter, 1),
      (try_end),
      (party_get_slot, ":target", ":party_no", slot_party_ai_object),
      (gt, ":target", -1),
      (store_distance_to_party_from_party, ":distance_from_target", ":party_no", ":target"),
      (try_begin),
         (store_faction_of_party, ":target_current_faction", ":target"),
         (assign, ":faction_relation", 100),
         (try_begin),
            (neq, ":target_current_faction", "$players_kingdom"),    # faction relation will be checked only if the target doesn't belong to the player's current faction
            (store_relation, ":faction_relation", "$players_kingdom", ":target_current_faction"),
         (try_end),
         (ge, ":faction_relation", 0),
         (party_get_slot, ":target_relation", ":target", slot_center_player_relation),
         (ge, ":target_relation", 0),
      #daedalus begin
         (party_get_slot, ":target_faction", ":target", slot_center_original_faction),
         (assign,":stop",1),
         (try_begin), #SB : or
            (this_or_next|eq,":recruit_faction",-1),
            # (assign,":stop",0),
         # (else_try),
            (eq, ":target_faction", ":recruit_faction"),
            (assign,":stop",0),
         (try_end),
         (neq,":stop",1),
      #daedalus end
         (call_script, "script_cf_village_normal_cond", ":target"), #SB : script condition
         (le, ":distance_from_target", 0),
         (party_get_slot, ":volunteers_in_target", ":target", slot_center_volunteer_troop_amount),
         (party_get_slot, ":target_volunteer_type", ":target", slot_center_volunteer_troop_type),
         (store_sub, ":still_needed", ":needed", ":amount"), #SB : store sub

         (try_begin), #SB : use store subs
            (gt, ":volunteers_in_target", ":still_needed"),
            (store_sub, ":santas_little_helper", ":volunteers_in_target", ":still_needed"),
            (store_sub, ":amount_to_recruit", ":volunteers_in_target", ":santas_little_helper"),
            (store_sub, ":new_target_volunteer_amount", ":volunteers_in_target", ":amount_to_recruit"),
            (party_set_slot, ":target", slot_center_volunteer_troop_amount, ":new_target_volunteer_amount"),
            (party_add_members, ":party_no", ":target_volunteer_type", ":amount_to_recruit"),
            (party_set_ai_behavior, ":party_no", ai_bhvr_hold),
            (party_set_slot, ":target", dplmc_slot_village_reserved_by_recruiter, 0),
         (else_try),
            (le, ":volunteers_in_target", ":still_needed"),
            (gt, ":volunteers_in_target", 0),
            (party_set_slot, ":target", slot_center_volunteer_troop_amount, -1),
            (party_add_members, ":party_no", ":target_volunteer_type", ":volunteers_in_target"),
            (party_set_ai_behavior, ":party_no", ai_bhvr_hold),
            (party_set_slot, ":target", dplmc_slot_village_reserved_by_recruiter, 0),
            (val_sub, ":still_needed", ":volunteers_in_target"),
            (call_script, "script_dplmc_set_recruiter_extra_text", ":party_no", ":still_needed"),
         (else_try),
            (le, ":volunteers_in_target", 0),
            (party_set_ai_behavior, ":party_no", ai_bhvr_hold),
            (party_set_slot, ":target", dplmc_slot_village_reserved_by_recruiter, 0),
         (else_try),
            (display_message, "@ERROR IN THE RECRUITER KIT SIMPLE TRIGGERS!",message_locked), #SB : color const
            (party_set_slot, ":target", dplmc_slot_village_reserved_by_recruiter, 0),
         (try_end),
      (try_end),
   # (try_end),
   # #SB : merged loops
   # (try_for_parties, ":party_no"),
      # (party_slot_eq,":party_no", slot_party_type, dplmc_spt_recruiter),
      # (party_get_num_companions, ":amount", ":party_no"),
      # (val_sub, ":amount", 1),   #the recruiter himself doesn't count
      # (party_get_slot, ":needed", ":party_no", dplmc_slot_party_recruiter_needed_recruits),
    (else_try),
      (eq, ":amount", ":needed"),
      # (party_get_slot, ":party_origin", ":party_no", dplmc_slot_party_recruiter_origin),  #SB : moved top
      (try_begin),
         (neg|party_slot_eq, ":party_no", slot_party_ai_object, ":party_origin"),
         (party_set_slot, ":party_no", slot_party_ai_object, ":party_origin"),
         (party_set_ai_behavior, ":party_no", ai_bhvr_travel_to_party),
         (party_set_ai_object, ":party_no", ":party_origin"),
         # (party_set_extra_text, ":party_no", "@Returning"), #SB : extra text
         (call_script, "script_dplmc_set_recruiter_extra_text", ":party_no", -1),
      (try_end),
      (store_distance_to_party_from_party, ":distance_from_origin", ":party_no", ":party_origin"),
      (try_begin),
         (le, ":distance_from_origin", 0),
         (party_get_num_companion_stacks, ":stacks", ":party_no"),
         (try_for_range, ":stack_no", 1, ":stacks"),
            (party_stack_get_size, ":size", ":party_no", ":stack_no"),
            (party_stack_get_troop_id, ":troop_id", ":party_no", ":stack_no"),
            (party_add_members, ":party_origin", ":troop_id", ":size"),
         (try_end),
         (str_store_party_name_link, s13, ":party_origin"),
         (assign, reg10, ":amount"),
         (display_log_message, "@A recruiter has brought {reg10} recruits to {s13}.", message_positive), #SB : message code
         (remove_party, ":party_no"),
      (try_end),
    (try_end),
  (try_end), #SB : close loop
   ]),

#This trigger makes sure that no village is left reserved forever.
(12,
   [
   #SB : merged with other 12-hour center loop
   # (try_for_range, ":village", villages_begin, villages_end),
      # (party_set_slot, ":village", dplmc_slot_village_reserved_by_recruiter, 0),
   # (try_end),
   ]),
#Recruiter kit end

#process gift_carvans
(1, #SB : half frequency
 [
  (eq, "$g_player_chancellor", "trp_dplmc_chancellor"),
  ##nested diplomacy start+
  #These gifts are far too efficient.  To be balanced with Native, they
  #should not (at the best case) exceed an efficiency of 1000 gold per point.
  (assign, ":save_reg0", reg0),
  (assign, ":save_reg1", reg1),
  (game_get_reduce_campaign_ai, ":reduce_campaign_ai"),#store for use below
  ##nested diplomacy end+
  (try_for_parties, ":party_no"),
    (party_is_active, ":party_no"),
    (party_slot_eq,":party_no", slot_party_type, dplmc_spt_gift_caravan),
    (party_get_slot, ":target_party", ":party_no", slot_party_ai_object),
    (party_get_slot, ":target_troop", ":party_no", slot_party_orders_object),

    (try_begin),
      (party_is_active, ":target_party"),

      (store_distance_to_party_from_party, ":distance_to_target", ":party_no", ":target_party"),
      (str_store_party_name, s14, ":party_no"),
      (str_store_party_name, s15,":target_party"),

      (try_begin), #debug
        (eq, "$cheat_mode", 1),
        (assign, reg0, ":distance_to_target"),
        (display_message, "@Distance between {s14} and {s15}: {reg0}"),
      (try_end),

      (try_begin),
        (le, ":distance_to_target", 1),

        (party_get_slot, ":gift", ":party_no", dplmc_slot_party_mission_diplomacy),
        (str_store_item_name, s12, ":gift"),

        (try_begin), #SB : string links
          (gt, ":target_troop", 0),
          (str_store_troop_name_link, s13, ":target_troop"),
        (else_try),
          (str_store_party_name_link, s13, ":target_party"),
        (try_end),
        (display_log_message, "@Your caravan has brought {s12} to {s13}.", message_positive), #SB : message_positive

        (assign, ":relation_boost", 0),
        (store_faction_of_party, ":target_faction", ":target_party"),

        (try_begin),
          (gt, ":target_troop", 0),
          (faction_slot_eq,":target_faction",slot_faction_leader,":target_troop"),
          (try_begin),
            (eq, ":gift", "itm_wine"),
            (assign, ":relation_boost", 1),
          (else_try),
            (eq, ":gift", "itm_gasoline"),
            (assign, ":relation_boost", 2),
          (try_end),
        (else_try),
          (store_random_in_range, ":random", 1, 3),
          (try_begin),
            (eq, ":gift", "itm_ale"),
            (val_add, ":relation_boost", ":random"),
          (else_try),
            (eq, ":gift", "itm_wine"),
            (store_add, ":relation_boost", 1, ":random"),
          (else_try),
            (eq, ":gift", "itm_gasoline"),
            (store_add, ":relation_boost", 2, ":random"),
          # (else_try),
            # (eq, ":gift", "itm_raw_dyes"),
            # (val_add, ":relation_boost", 1),
          # (else_try),
            # (eq, ":gift", "itm_raw_silk"),
            # (val_add, ":relation_boost", 2),
          # (else_try),
            # (eq, ":gift", "itm_velvet"),
            # (val_add, ":relation_boost", 4),
          (else_try),
            (eq, ":gift", "itm_smoked_fish"),
            (try_begin),
              (party_slot_eq, ":target_party", slot_party_type, spt_village),
              (val_add, ":relation_boost", 1),
            (try_end),
          (else_try),
            (eq, ":gift", "itm_cheese"),
            (val_add, ":relation_boost", 1),
            (try_begin),
              (party_slot_eq, ":target_party", slot_party_type, spt_village),
              (val_add, ":relation_boost", 1),
            (try_end),
          (else_try),
            (eq, ":gift", "itm_honey"),
            (val_add, ":relation_boost", 2),
            (try_begin),
              (party_slot_eq, ":target_party", slot_party_type, spt_village),
              (val_add, ":relation_boost", 2),
            (try_end),
          (try_end),
        (try_end),

        (try_begin),
          (this_or_next|eq, ":target_faction", "fac_player_supporters_faction"),
          (eq, ":target_faction", "$players_kingdom"),
          (val_add, ":relation_boost", 1),
        (try_end),

		##nested diplomacy start+
		#Determine the gold cost of the gifts.
		(store_item_value, ":gift_value", ":gift"),
		#Determine how many copies of the gift are used
		(party_get_slot, ":gift_value_factor", ":party_no", dplmc_slot_party_mission_parameter_1),
		(try_begin),
			#This should only fail if the game was saved using an old version while
			#a caravan was en route.
			(gt, ":gift_value_factor", 0),
			(val_mul, ":gift_value", ":gift_value_factor"),
		(else_try),
			#Gifts to ladies had no multiplier.
			#Also, don't do anything for non-trade-goods.
			(this_or_next|is_between, ":target_troop", kingdom_ladies_begin, kingdom_ladies_end),
			(neg|is_between, ":gift", trade_goods_begin, trade_goods_end),
		(else_try),
			 #Gifts to lords used 150 copies of an item
			(is_between, ":target_troop", active_npcs_begin, active_npcs_end),
			(val_mul, ":gift_value", 150),
		(else_try),
			#Gifts to centers used 300 copies of an item
			(is_between, ":target_party", centers_begin, centers_end),
			(val_mul, ":gift_value", 300),
		(try_end),
		(assign, ":gift_value_factor", 100),

		#(store_sub, ":gift_slot_no", ":gift", trade_goods_begin),
		#(val_add, ":gift_slot_no", slot_town_trade_good_prices_begin),

		(try_begin),
			#Gift isn't a trade good: this should never happen
			(neg|is_between, ":gift", trade_goods_begin, trade_goods_end),
			(try_begin),
				(this_or_next|gt, ":target_troop", 0),
					(party_slot_eq, ":target_party", slot_party_type, spt_town),
				(assign, ":gift_value_factor", 115),
			(else_try),
				(assign, ":gift_value_factor", 130),
			(try_end),
		(else_try),
			#Given to a lord.
			(gt, ":target_troop", 0),

			(assign, ":global_price_factor", 0),
			(assign, ":faction_price_factor", 0),
			(assign, ":faction_markets", 0),
			(assign, ":personal_price_factor", 0),
			(assign, ":personal_markets", 0),

			(try_for_range, ":center_no", towns_begin, towns_end),
				(call_script, "script_dplmc_get_item_buy_price_factor", ":gift", ":center_no", -2, -2),
				(val_add, ":global_price_factor", reg0),

				(store_faction_of_party, ":center_faction", ":center_no"),
				(eq, ":center_faction", ":target_faction"),
				(val_add, ":faction_price_factor", reg0),
				(val_add, ":faction_markets", 1),

				(party_slot_eq, ":center_no", slot_town_lord, ":target_troop"),
				(val_add, ":personal_price_factor", reg0),
				(val_add, ":personal_markets", 1),
			(try_end),

			(try_begin),
				(eq, ":personal_markets", 0),
				(try_for_range, ":center_no", villages_begin, villages_end),
					(try_begin),
						(party_slot_eq, ":center_no", slot_town_lord, ":target_troop"),
						(call_script, "script_dplmc_get_item_buy_price_factor", ":gift", ":center_no", -2, -2),
						(val_add, ":faction_markets", reg0),
						(val_add, ":personal_markets", 1),
					(try_end),
					#Check for forts (deliberately allow multiple-counting)
					(try_begin),
						(party_get_slot, reg1, ":center_no", slot_village_bound_center),
						(gt, reg1, 0),
						(party_slot_eq, reg1, slot_party_type, spt_castle),
						(party_slot_eq, reg1, slot_town_lord, ":target_troop"),
						(call_script, "script_dplmc_get_item_buy_price_factor", ":gift", ":center_no", -2, -2),
						(val_add, ":faction_markets", reg0),
						(val_add, ":personal_markets", 1),
					(try_end),
				(try_end),
			(try_end),

			(try_begin),
				#First use any markets at or near the target's fiefs
				(gt, ":personal_markets", 0),
				(store_div, ":gift_value_factor", ":personal_price_factor", ":personal_markets"),
			(else_try),
				#Alternately use any faction markets
				(gt, ":faction_markets", 0),
				(val_mul, ":faction_price_factor", 130),#Convert trade penalty from 115% to 130%
				(val_div, ":faction_price_factor", 115),
				(store_div, ":gift_value_factor", ":faction_price_factor", ":faction_markets"),
			(else_try),
				#As a final option use the global average price
				(gt, towns_end, towns_begin),#should always be true (if not, then the gift price factor stays average)
				(store_sub, reg1, towns_end, towns_begin),
				(val_mul, ":global_price_factor", 130),#Convert trade penalty from 115% to 130%
				(val_div, ":global_price_factor", 115),
				(store_div, ":gift_value_factor", ":global_price_factor", reg1),
			(try_end),
		(else_try),
			#Given to a town or village
			(gt, ":target_party", 0),
			(call_script, "script_dplmc_get_item_buy_price_factor", ":gift", ":center_no", -2, -2),
			(assign, ":gift_value_factor", reg0),
		(else_try),
			#This should never happen
			(assign, ":gift_value_factor", 115),
		(try_end),

		(try_begin),
			(ge, "$cheat_mode", 1),
			(assign, reg0, ":gift_value_factor"),
			(store_mul, reg1, ":gift_value", ":gift_value_factor"),
			(val_add, reg1, 50),
			(val_div, reg1, 100),
			(val_add, reg1, 50),
			(display_message, "@{!} Gift price factor {reg0}/100, effective value {reg1}"),
		(try_end),

		(val_mul, ":gift_value", ":gift_value_factor"),
		(val_add, ":gift_value", 50),
		(val_div, ":gift_value", 100),

		(val_add, ":gift_value", 50),#the cost of the messenger
	    (store_random_in_range, ":random", 0, 1000),#randomly round up or down later, when dividing by 1000
		(assign, reg0, ":gift_value"),#<-- see (1) below, store gold value of gift
		(val_add, ":gift_value", ":random"),
		(val_div, ":gift_value", 1000),

		(try_begin),
		   (eq, ":reduce_campaign_ai", 0), #hard: do not exceed 1/1000 efficiency
		   (val_min, ":relation_boost", ":gift_value"),
		   (try_begin),
			  (eq, ":relation_boost", 0),
			  (store_random_in_range, ":random", 0, 1000),
			  (lt, ":random", reg0),#<-- (1) see above, has gold value of gift
			  (assign, ":relation_boost", 1),
		   (try_end),
		(else_try),
		   (eq, ":reduce_campaign_ai", 1), #medium: use a blend of the two
		   (lt, ":gift_value", ":relation_boost"),
		   (val_add, ":relation_boost", ":gift_value"),
		   (val_add, ":relation_boost", 1),
		   (val_div, ":relation_boost", 2),
	    (else_try),
		   (eq, ":reduce_campaign_ai", 2), #easy: do not use
		(try_end),

		(val_max, ":gift_value", 1),
		(val_min, ":relation_boost", ":gift_value"),
		##nested diplomacy end+

        (try_begin),
		##nested diplomacy start+
		#Write a message so the player doesn't think the lack of relation gain is an error.
			(lt, ":relation_boost", 1),
			(try_begin),
				(gt, ":target_troop", 0),
				(display_message, "@{s13} is unimpressed by your paltry gift."),
			(else_try),
				(display_message, "@The people of {s13} are unimpressed by your paltry gift."),
			(try_end),
		(else_try),
		##nested diplomacy+
          (gt, ":target_troop", 0),
		  (call_script, "script_change_player_relation_with_troop", ":target_troop", ":relation_boost"),
        (else_try),
          (call_script, "script_change_player_relation_with_center", ":target_party", ":relation_boost"),
        (try_end),
        (remove_party, ":party_no"),
      (try_end),
    (else_try),
      (display_log_message, "@Your caravan has lost it's way and gave up your mission!", message_defeated), #SB : message code
      (remove_party, ":party_no"),
    (try_end),
  (try_end),
  ##nested diplomacy start+
  (assign, reg0, ":save_reg0"),
  (assign, reg1, ":save_reg1"),
  ##nested diplomacy start+
 ]),

#process messengers
(1, #SB: half as often
 [
  (try_for_parties, ":party_no"),
    (party_slot_eq,":party_no", slot_party_type, spt_messenger),

    (party_get_slot, ":target_party", ":party_no", slot_party_ai_object),
    (party_get_slot, ":orders_object", ":party_no", slot_party_orders_object),

    (try_begin),
      (party_is_active, ":target_party"),
      (store_distance_to_party_from_party, ":distance_to_target", ":party_no", ":target_party"),
      (str_store_party_name, s14, ":party_no"),
      (str_store_party_name, s15,":target_party"),

      (try_begin), #debug
        (eq, "$cheat_mode", 1),
        (assign, reg0, ":distance_to_target"),
        (display_message, "@Distance between {s14} and {s15}: {reg0}"),
      (try_end),

      (try_begin),
        (le, ":distance_to_target", 1),

        (try_begin), # returning to p_main_party
          (eq, ":target_party", "p_main_party"),
          (party_get_slot, ":party_leader", ":party_no", slot_party_orders_object),
          (party_get_slot, ":success", ":party_no", dplmc_slot_party_mission_diplomacy),
          (call_script, "script_add_notification_menu", "mnu_dplmc_messenger", ":party_leader", ":success"),
          (remove_party, ":party_no"),
        (else_try), # patrols
          (party_slot_eq, ":target_party", slot_party_type, spt_patrol),
          (party_get_slot, ":message", ":party_no", dplmc_slot_party_mission_diplomacy),

          #SB : quick string to strings
          (try_begin),
            (eq, ":message", spai_undefined),
            (remove_party, ":target_party"),
          (else_try),
            (eq, ":message", spai_retreating_to_center),
            (str_store_party_name, s5, ":orders_object"),
            (party_set_name, ":target_party", "str_s5_transfer"),
            (party_set_ai_behavior, ":target_party", ai_bhvr_travel_to_party),
            (party_set_ai_object, ":target_party", ":orders_object"),
            (party_set_slot, ":target_party", slot_party_ai_object, ":orders_object"),
            (party_set_slot, ":target_party", slot_party_ai_state, spai_retreating_to_center),
            (party_set_aggressiveness, ":target_party", 0),
            (party_set_courage, ":target_party", 3),
            (party_set_ai_initiative, ":target_party", 100),
          (else_try),
            (str_store_party_name, s5, ":orders_object"),
            (party_set_name, ":target_party", "str_s5_patrol"),
            (party_set_ai_behavior, ":target_party", ai_bhvr_travel_to_party),
            (party_set_ai_object, ":target_party", ":orders_object"),
            (party_set_slot, ":target_party", slot_party_ai_object, ":orders_object"),
            (party_set_slot, ":target_party", slot_party_orders_type, ":message"),
          (try_end),

          (remove_party, ":party_no"),
        (else_try), # SB : reached a center (waypoint) as target troop has not yet spawned
          (is_between, ":target_party", walled_centers_begin, walled_centers_end),
          (party_get_slot, ":target_troop", ":party_no", dplmc_slot_party_origin),
          (try_begin), #retarget
            (troop_get_slot, ":leaded_party", ":target_troop", slot_troop_leaded_party),
            (gt, ":leaded_party", 0),
            (party_is_active, ":leaded_party"),
            (neg|party_is_in_town, ":leaded_party", ":target_party"), #camping for some reason
            (party_set_ai_behavior, ":party_no", ai_bhvr_travel_to_party),
            (party_set_ai_object, ":party_no", ":leaded_party"),
            (party_set_slot, ":party_no", slot_party_ai_object, ":leaded_party"), #drop down to the condition below
          (try_end),
        (else_try), # reached any other target
          (party_stack_get_troop_id, ":party_leader", ":target_party", 0),
          (str_store_troop_name, s13, ":party_leader"),

          (try_begin), #debug
            (eq, "$cheat_mode", 1),
            (display_log_message, "@Your messenger reached {s13}.", 0x00FF00),
            (assign, "$g_talk_troop", ":party_leader"), #debug
          (try_end),

          (party_get_slot, ":message", ":party_no", dplmc_slot_party_mission_diplomacy),
          (assign, ":success", 0),
          (try_begin),
            (party_set_slot, ":target_party", slot_party_commander_party, "p_main_party"),
          	(store_current_hours, ":hours"),
          	(party_set_slot, ":target_party", slot_party_following_orders_of_troop, "trp_kingdom_heroes_including_player_begin"),
          	(party_set_slot, ":target_party", slot_party_orders_object, ":orders_object"),
          	(party_set_slot, ":target_party", slot_party_orders_type, ":message"),

          	(party_set_slot, ":target_party", slot_party_orders_time, ":hours"),
            (call_script, "script_npc_decision_checklist_party_ai", ":party_leader"), #This handles AI for both marshal and other parties


            (try_begin), #debug
              (eq, "$cheat_mode", 1),
              (display_message, "@{s14}"), #debug
            (try_end),

            (try_begin),
              (eq, reg0, ":message"),
              (eq, reg1, ":orders_object"),
              (assign, ":success", 1),
            (try_end),
            (call_script, "script_party_set_ai_state", ":target_party", reg0, reg1),
          (try_end),

          (party_set_ai_behavior, ":party_no", ai_bhvr_travel_to_party),
          (party_set_ai_object, ":party_no", "p_main_party"),
          (party_set_slot, ":party_no", slot_party_ai_object, "p_main_party"),
          (party_set_slot, ":party_no", slot_party_orders_object, ":party_leader"),
          (party_set_slot, ":party_no", dplmc_slot_party_mission_diplomacy, ":success"),
        (try_end),
      (try_end),
    (else_try),
      #SB : it's to its
      (display_log_message, "@Your messenger has lost its way and gave up your mission!", message_defeated),
      (remove_party, ":party_no"),
    (try_end),
  (try_end),
 ]),


# Constable training
(24, [
    (eq, "$g_player_constable", "trp_dplmc_constable"),
    (is_between, "$g_constable_training_center", walled_centers_begin, walled_centers_end),
    (party_slot_eq, "$g_constable_training_center", slot_town_lord, "trp_player"),
    (store_skill_level, ":trainer_level", skl_trainer, "trp_player"),
    (val_add, ":trainer_level", 4),
    (faction_get_slot, ":quality", "$players_kingdom", dplmc_slot_faction_quality),
    (try_begin), #quantity policy
      (is_between, ":quality", -4, 0),
      (val_mul, ":quality", -2), #-6 to -2
      (val_add, ":trainer_level", ":quality"),
    (try_end),
    (store_div, ":xp_gain", ":trainer_level", 2),

    # (try_begin),
      # (ge, "$novice_training_difficulty", 1),
      # (assign, ":max_distance", 50),
      # (game_get_reduce_campaign_ai, ":base_number"), #0, 1, 2
      # (val_add, ":cur_number", "$novice_training_difficulty"), #1 to 6
      # (val_div, ":cur_number", 2),
      # (val_max, ":cur_number", 1),
    (assign, ":num_trainers", "$g_constable_training_improved"),
      # (try_for_range, ":grounds", training_grounds_begin, training_grounds_end),
        # (store_distance_to_party_from_party, ":distance", ":grounds", "$g_constable_training_center"),
        # (lt, ":distance", ":max_distance"),
        # # (assign, ":max_distance", ":distance"),
        # (party_get_slot, ":trainer", slot_grounds_trainer, ":grounds"),
        # (troop_get_slot, ":difficulty", ":trainer", slot_troop_trainer_training_difficulty),
        # # (gt, ":difficulty", 0), #1-6
        # (store_add, ":cur_number", ":base_number", ":difficulty"),
        # (val_div, ":cur_number", 2),
        # (val_max, ":cur_number", 1),
        # (val_add, ":xp_gain", ":cur_number"),
        # (val_add, ":num_trainers", 1),
      # (try_end),
    # (try_end),

   #SB : move calculations up
   (store_mul, ":troop_limit", ":num_trainers", 2), #from 0 to 4, +1 for each nearby ground
   (val_add, ":troop_limit", 25), #base recruit level in Natives + 1, values now can be 7/9/11/13/15

   (store_troop_gold, ":gold", "trp_household_possessions"), #player treasury
   (store_mul, ":total_cost", "$g_constable_training_improved", dplmc_trainers_cost), #base cost
   #probably do a message here notifying trainers have left your service
   (gt, ":gold", ":total_cost"),
   #SB : wtf is this
   # (try_for_parties, ":party_no"),
    # (party_slot_eq, ":party_no", slot_town_lord, "trp_player"),
    # (eq, ":party_no", "$g_constable_training_center"),
    (assign, ":party_no", "$g_constable_training_center"),

    (party_get_num_companion_stacks, ":num_stacks", ":party_no"),

    # (assign, ":trained", 0),
    (try_for_range, ":i_stack", 0, ":num_stacks"),
      # (eq, ":trained", 0),
      (gt, ":xp_gain", 0),
      (party_stack_get_troop_id, ":troop_id", ":party_no", ":i_stack"),
      (neg|troop_is_hero, ":troop_id"),

      #SB : lots of upgrade troop parsing
      (assign, ":upgrade_troop", -1),
      (troop_get_upgrade_troop, ":upgrade_troop_1", ":troop_id", 0),
      (gt, ":upgrade_troop_1", 0), #if first upgrade doesn't exist, it can't upgrade at all
      (try_begin),
        # (troop_get_class, ":grc", ":upgrade_troop_1"),
        # (eq, ":grc", "$g_constable_training_type"),
        (call_script, "script_cf_troop_is_class", "$g_constable_training_type", ":upgrade_troop_1"),
        (assign, ":upgrade_troop", ":upgrade_troop_1"),
      (else_try),
        (troop_get_upgrade_troop, ":upgrade_troop_2", ":troop_id" , 1),
        (call_script, "script_cf_troop_is_class", "$g_constable_training_type", ":upgrade_troop_2"),
        (assign, ":upgrade_troop", ":upgrade_troop_2"),
      (else_try), #do a look-ahead
        (assign, ":upgrade_troop", ":upgrade_troop_1"), #fixed
        (try_begin),
          (troop_get_upgrade_troop, ":upgrade_troop_3", ":upgrade_troop_1" , 0),
          (call_script, "script_cf_troop_is_class", "$g_constable_training_type", ":upgrade_troop_3"),
          (assign, ":upgrade_troop", ":upgrade_troop_3"),
        (else_try),
          (troop_get_upgrade_troop, ":upgrade_troop_4", ":upgrade_troop_1" , 1),
          (call_script, "script_cf_troop_is_class", "$g_constable_training_type", ":upgrade_troop_4"),
          (assign, ":upgrade_troop", ":upgrade_troop_4"),
        (try_end),
        (eq, ":upgrade_troop", ":upgrade_troop_1"), #unchanged, check upgrade_troop_2
        (try_begin),
          (troop_get_upgrade_troop, ":upgrade_troop_3", ":upgrade_troop_2" , 0),
          (call_script, "script_cf_troop_is_class", "$g_constable_training_type", ":upgrade_troop_3"),
          (assign, ":upgrade_troop", ":upgrade_troop_3"),
        (else_try),
          (troop_get_upgrade_troop, ":upgrade_troop_4", ":upgrade_troop_2" , 1),
          (call_script, "script_cf_troop_is_class", "$g_constable_training_type", ":upgrade_troop_4"),
          (assign, ":upgrade_troop", ":upgrade_troop_4"),
        (try_end),
      (try_end),
      #only proceed if troop is upgradable
      (gt, ":upgrade_troop", 0),

      (store_character_level, ":troop_level", ":troop_id"),
      (le, ":troop_level", ":troop_limit"),

      # (party_count_members_of_type,":cur_number",":party_no",":troop_id"),
      (party_stack_get_size, ":cur_number", ":party_no", ":i_stack"),
      (party_stack_get_num_wounded, ":num_wounded",":party_no",":i_stack"),
      (val_sub, ":cur_number", ":num_wounded"),
      (try_begin),
        (ge, "$g_constable_training_improved", 1),
        (le, ":troop_level", 6),
        (val_add, ":cur_number", 2), #more recruits are trained during improved training
      (try_end),
      (val_min, ":cur_number", ":xp_gain"),

      (call_script, "script_game_get_upgrade_cost", ":troop_id"),
      (store_mul, ":upgrade_cost", ":cur_number", reg0),

      # (try_for_range, ":troop_count", 0, ":cur_number"),
        # (gt, ":gold", ":total_cost"),
        # (val_add, ":total_cost", ":upgrade_cost"),
      # (else_try), #break and lower cur_number
        # (val_sub, ":total_cost", ":upgrade_cost"), #can't afford
        # (assign, ":cur_number", ":troop_count"),
      # (try_end),

      # (store_troop_gold, ":gold", "trp_household_possessions"),
      (val_add, ":total_cost", ":upgrade_cost"),
      (try_begin), #if we can only afford partial upgrades
        (lt, ":gold", ":total_cost"),
        (val_sub, ":total_cost", ":upgrade_cost"), #undo
        (val_div, ":upgrade_cost", ":cur_number"), #get original cost
        (store_sub, ":cur_number", ":gold", ":total_cost"), #get remainder
        (val_div, ":cur_number", ":upgrade_cost"), #get however many we can afford
        (val_mul, ":cur_number", ":upgrade_cost"), #then redo
        (val_add, ":total_cost", ":upgrade_cost"),
        (str_store_troop_name_plural, s6, ":troop_id"),
        (display_message, "@Not enough money in treasury to upgrade {s6}."),
      (try_end),

      # (val_add, ":total_cost", ":upgrade_cost"),
      # (call_script, "script_dplmc_withdraw_from_treasury", ":upgrade_cost"),
      (party_remove_members,":party_no",":troop_id",":cur_number"),
      (party_add_members, ":party_no", ":upgrade_troop", ":cur_number"),
      (val_sub, ":xp_gain", ":cur_number"),
      (assign, reg5, ":cur_number"),
      (str_store_troop_name_by_count, s6, ":troop_id", ":cur_number"),
      (str_store_troop_name_by_count, s7, ":upgrade_troop", ":cur_number"),
      (str_store_party_name_link, s8, ":party_no"),
      (display_log_message, "@Your constable upgraded {reg5} {s6} to {s7} in {s8}"),
    (try_end),

    #finalize costs
    (call_script, "script_dplmc_withdraw_from_treasury", ":total_cost"),
   # (try_end),
    ]),

# Patrol wages
(24 * 7,
   [

    (try_for_parties, ":party_no"),
      (party_slot_eq,":party_no", slot_party_type, spt_patrol),



      (party_get_slot, ":ai_state", ":party_no", slot_party_ai_state),
      (eq, ":ai_state", spai_patrolling_around_center),

      (try_begin),
		(party_slot_eq, ":party_no", dplmc_slot_party_mission_diplomacy, "trp_player"),
        (assign, ":total_wage", 0),
        (party_get_num_companion_stacks, ":num_stacks", ":party_no"),
        (try_for_range, ":i_stack", 0, ":num_stacks"),
          (party_stack_get_troop_id, ":stack_troop", ":party_no", ":i_stack"),
          (party_stack_get_size, ":stack_size", ":party_no", ":i_stack"),
          (call_script, "script_game_get_troop_wage", ":stack_troop"),
          # (call_script, "script_game_get_troop_wage", ":stack_troop", 0),
          (val_mul, reg0, ":stack_size"),
          (val_add, ":total_wage", reg0),
        (try_end),
        (store_troop_gold, ":gold", "trp_household_possessions"),
        (try_begin),
          (lt, ":gold", ":total_wage"),
          (party_get_slot, ":target_party", ":party_no", slot_party_ai_object),
          (str_store_party_name, s6, ":target_party"),
          (display_log_message, "@Your soldiers patrolling {s6} disbanded because you can't pay the wages!", message_defeated), #SB : message code
          (remove_party, ":party_no"),
        (try_end),
      (try_end),
    (try_end),
    ]),

#create ai patrols
(24 * 7,
   [
    (try_for_range, ":faction", npc_kingdoms_begin, npc_kingdoms_end),

      (assign, ":max_patrols", 0),
      (try_for_range, ":center", towns_begin, towns_end),
        (store_faction_of_party, ":center_faction", ":center"),
        (eq, ":center_faction", ":faction"),
        (val_add, ":max_patrols", 1),
      (try_end),

      (assign, ":count", 0),
      (try_for_parties, ":party_no"),
        (party_slot_eq, ":party_no", slot_party_type, spt_patrol),
        (store_faction_of_party, ":party_faction", ":party_no"),
        (eq, ":party_faction", ":faction"),
        (neg|party_slot_eq, ":party_no", dplmc_slot_party_mission_diplomacy, "trp_player"), #not player ordered
        (try_begin),
           #Remove patrols above the maximum number allowed.
           (ge, ":count", ":max_patrols"),
           (try_begin),
              (ge, "$cheat_mode", 1),
              (str_store_faction_name, s4, ":faction"),
              (str_store_party_name, s5, ":party_no"),
              (display_message, "@{!}DEBUG - Removed {s5} because {s4} cannot support that many patrols"),
           (try_end),
           (remove_party, ":party_no"),
        (else_try),
           (val_add, ":count", 1),
        (try_end),
      (try_end),

      (try_begin),
        (lt, ":count", ":max_patrols"),

        (store_random_in_range, ":random", 0, 10),
        (le, ":random", 3),

        (assign, ":start_center", -1),
        (assign, ":target_center", -1),

        (try_for_range, ":center", towns_begin, towns_end),
          (store_faction_of_party, ":center_faction", ":center"),
          (eq, ":center_faction", ":faction"),

          (eq, ":start_center", -1),
          (eq, ":target_center", -1),

          (assign, ":continue", 1),
          (try_for_parties, ":party_no"),
            (party_slot_eq, ":party_no", slot_party_type, spt_patrol),
            (store_faction_of_party, ":party_faction", ":party_no"),
            (eq, ":party_faction", ":faction"),
            (party_get_slot, ":target", ":party_no", slot_party_ai_object),
            (eq, ":target", ":center"),
            (assign, ":continue", 0),
          (try_end),
          (eq, ":continue", 1),

          (call_script, "script_cf_select_random_town_with_faction", ":faction"),
          (neq, reg0, -1),

          (assign, ":start_center", reg0),
          (assign, ":target_center", ":center"),
        (try_end),

        (try_begin),
          (neq, ":start_center", -1),
          (neq, ":target_center", -1),
          (store_random_in_range, ":random_size", 0, 3),
          (faction_get_slot, ":faction_leader", ":faction", slot_faction_leader),
          (call_script, "script_dplmc_send_patrol", ":start_center", ":target_center", ":random_size",":faction", ":faction_leader"),
        (try_end),
      (try_end),
    (try_end),
    ]),

# Patrol ai
(2,
   [

    (try_for_parties, ":party_no"),
      (party_slot_eq,":party_no", slot_party_type, spt_patrol),

      # (call_script, "script_party_remove_all_prisoners", ":party_no"), #SB : retain prisoners

      (try_begin),
        (get_party_ai_behavior, ":ai_behavior", ":party_no"),
        (eq, ":ai_behavior", ai_bhvr_travel_to_party),
        (party_get_slot, ":target_party", ":party_no", slot_party_ai_object),

        (try_begin),
          (gt, ":target_party", 0),
          (store_distance_to_party_from_party, ":distance_to_target", ":party_no", ":target_party"),
          (le, ":distance_to_target", 5),
          (try_begin), #SB : drop off prisoners
            (le, ":distance_to_target", 3),
            (is_between, ":target_party", walled_centers_begin, walled_centers_end),
            (call_script, "script_party_prisoners_add_party_prisoners", ":target_party", ":party_no"), #DA 3.10.2019: fix to put prisoners in the dungeon and not in the garrison
            # (call_script, "script_party_add_party_prisoners", ":target_party", ":party_no"),
            (call_script, "script_party_remove_all_prisoners", ":party_no"),
          (try_end),
          (try_begin),
            (party_get_slot, ":ai_state", ":party_no", slot_party_ai_state),
            (eq, ":ai_state", spai_retreating_to_center),
            (try_begin),
              (le, ":distance_to_target", 1),
              (call_script, "script_party_add_party", ":target_party", ":party_no"),
              (remove_party, ":party_no"),
            (try_end),
          (else_try),
            (party_get_position, pos1, ":target_party"),
            (party_set_ai_behavior,":party_no", ai_bhvr_patrol_location),
            (party_set_ai_patrol_radius, ":party_no", 1),
            (party_set_ai_target_position, ":party_no", pos1),
          (try_end),

        # (else_try),
          # #remove party?
        (try_end),

      (try_end),
    (try_end),
    ]),

# Scout ai
(1.5, #SB : moved to 1.5 hr
   [

    (try_for_parties, ":party_no"),
      (party_slot_eq,":party_no", slot_party_type, spt_scout),

      (try_begin),
        (get_party_ai_behavior, ":ai_behavior", ":party_no"),
        (this_or_next|eq, ":ai_behavior", ai_bhvr_travel_to_point),
        (eq, ":ai_behavior", ai_bhvr_travel_to_party),

        (party_get_slot, ":target_party", ":party_no", slot_party_ai_object),
        (store_distance_to_party_from_party, ":distance_to_target", ":party_no", ":target_party"),
        (le, ":distance_to_target", 1),

        (try_begin),
          (eq, ":target_party", "p_main_party"),

          (party_get_slot, ":mission_target", ":party_no", dplmc_slot_party_mission_diplomacy),
          (call_script, "script_add_notification_menu", "mnu_dplmc_scout", ":mission_target", 0),

          (remove_party, ":party_no"),
        (else_try),
          (neq, ":target_party", "p_main_party"),
          (party_get_slot, ":hours", ":party_no", dplmc_slot_party_mission_diplomacy),

          (try_begin),
            (le, ":hours", 100),
            (disable_party, ":party_no"),
            (val_add, ":hours", 1),
            (party_set_slot, ":party_no", dplmc_slot_party_mission_diplomacy, ":hours"),

            (try_begin),
              (store_random_in_range, ":random", 0, 1000),
              (eq, ":random", 0),
              (str_store_party_name, s11, ":target_party"),
              (display_log_message, "@It is rumoured that a spy has been caught in {s11}.", message_defeated), #SB : message code
              (remove_party, ":party_no"),
            (try_end),

          (else_try),
            (enable_party, ":party_no"),
            (party_set_ai_behavior, ":party_no", ai_bhvr_travel_to_party),
            (party_set_ai_object, ":party_no", "p_main_party"),
            (party_set_slot, ":party_no", slot_party_ai_object, "p_main_party"),
            (party_set_slot, ":party_no", dplmc_slot_party_mission_diplomacy, ":target_party"),
          (try_end),

        (try_end),
      (try_end),
    (try_end),
    ]),

# Policy
(30 * 24,
   [
	##nested diplomacy start+
	##If the player is ruler or co-ruler of an NPC faction, make sure the
	#policy matches fac_player_supporters_faction.  (It should be synchronized
	#elsewhere, but do it here in case there has been an error.)
	(assign, ":player_is_coruler_of_npc_faction", 0),
	  (try_begin),
		(neq, "$players_kingdom", "fac_player_supporters_faction"),
		(is_between, "$players_kingdom", npc_kingdoms_begin, npc_kingdoms_end),
		(call_script, "script_dplmc_get_troop_standing_in_faction", "trp_player", "$players_kingdom"),
		(ge, reg0, DPLMC_FACTION_STANDING_LEADER_SPOUSE),

		(assign, ":player_is_coruler_of_npc_faction", 1),

		(faction_get_slot, reg0, "$players_kingdom", dplmc_slot_faction_serfdom),
		(faction_set_slot, "fac_player_supporters_faction", dplmc_slot_faction_serfdom, reg0),

		(faction_get_slot, reg0, "$players_kingdom", dplmc_slot_faction_centralization),
		(faction_set_slot, "fac_player_supporters_faction", dplmc_slot_faction_centralization, reg0),

		(faction_get_slot, reg0, "$players_kingdom", dplmc_slot_faction_quality),
		(faction_set_slot, "fac_player_supporters_faction", dplmc_slot_faction_quality, reg0),

		(faction_get_slot, reg0, "$players_kingdom", dplmc_slot_faction_aristocracy),
		(faction_set_slot, "fac_player_supporters_faction", dplmc_slot_faction_aristocracy, reg0),

		(faction_get_slot, reg0, "$players_kingdom", dplmc_slot_faction_mercantilism),
		(faction_set_slot, "fac_player_supporters_faction", dplmc_slot_faction_mercantilism, reg0),
	(try_end),
	##nested diplomacy end+
  (try_for_range, ":faction", kingdoms_begin, kingdoms_end),
    (faction_slot_eq, ":faction", slot_faction_state, sfs_active),

    (faction_get_slot, ":centralization", ":faction", dplmc_slot_faction_centralization),
    (faction_get_slot, ":aristocracy", ":faction", dplmc_slot_faction_aristocracy),
    (faction_get_slot, ":quality", ":faction", dplmc_slot_faction_quality),
    (faction_get_slot, ":serfdom", ":faction", dplmc_slot_faction_serfdom),
	 ##nested diplomacy start+
    (faction_get_slot, ":mercantilism", ":faction", dplmc_slot_faction_mercantilism),
	 ##nested diplomacy end+

    (try_begin),
      (eq, "$cheat_mode", 1),
      (str_store_faction_name, s9, ":faction"),
      (assign, reg1, ":centralization"),
      (display_message, "@{!}DEBUG - centralization {reg1}"),
      (assign, reg1, ":aristocracy"),
      (display_message, "@{!}DEBUG - aristocracy {reg1}"),
      (assign, reg1, ":quality"),
      (display_message, "@{!}DEBUG - quality {reg1}"),
      (assign, reg1, ":serfdom"),
      (display_message, "@{!}DEBUG - serfdom {reg1}"),
		##nested diplomacy start+
      (assign, reg1, ":mercantilism"),
      (display_message, "@{!}DEBUG - mercantilism {reg1}"),
		##nested diplomacy end+
    (try_end),

    (try_begin),
      (is_between, ":faction", npc_kingdoms_begin, npc_kingdoms_end),
      ##nested diplomacy start+
      ##Ensure the player isn't the faction's ruler or co-ruler
      (this_or_next|neq, ":faction", "$players_kingdom"),
      (eq, ":player_is_coruler_of_npc_faction", 0),
      ##Add the chance to move around mercantilism.
      #(store_random_in_range, ":random", 0, 8),
      (store_random_in_range, ":random", 0, 10),
      ##nested diplomacy end+

      (try_begin),
        ##nested diplomacy start+
        #(is_between, ":random", 1, 5),
        (is_between, ":random", 1, 6),
        ##nested diplomacy end+
        (store_random_in_range, ":change", -1, 2),

        (try_begin),
          (eq, "$cheat_mode", 1),
          (str_store_faction_name, s12, ":faction"),
          (assign, reg1, ":change"),
          (assign, reg2, ":random"),
          (display_message, "@{!}DEBUG - changing {reg1} of {reg2} for {s12}"),
        (try_end),

        (try_begin),
          (eq, ":random", 1),
          (val_add, ":centralization", ":change"),
          (val_max, ":centralization", -3),
          (val_min, ":centralization", 3),
          (faction_set_slot, ":faction", dplmc_slot_faction_centralization, ":centralization"),
        (else_try),
          (eq, ":random", 2),
          (val_add, ":aristocracy", ":change"),
          (val_max, ":aristocracy", -3),
          (val_min, ":aristocracy", 3),
          (faction_set_slot, ":faction", dplmc_slot_faction_aristocracy, ":aristocracy"),
        (else_try),
          (eq, ":random", 3),
          (val_add, ":quality", ":change"),
          (val_max, ":quality", -3),
          (val_min, ":quality", 3),
          (faction_set_slot, ":faction", dplmc_slot_faction_quality, ":quality"),
        (else_try),
          (eq, ":random", 4),
          (val_add, ":serfdom", ":change"),
          (val_max, ":serfdom", -3),
          (val_min, ":serfdom", 3),
          (faction_set_slot, ":faction", dplmc_slot_faction_serfdom, ":serfdom"),
          ##nested diplomacy start+
          (eq, ":random", 5),
          (val_add, ":mercantilism", ":change"),
          (val_clamp, ":mercantilism", -3, 4),#-3 min, +3 max
          (faction_set_slot, ":faction", dplmc_slot_faction_mercantilism, ":mercantilism"),
          ##nested diplomacy end+
        (try_end),
      (try_end),

    (else_try),

      #only player faction is affected by relation hits
      ##nested diplomacy start+
      ##Don't alter the values of centralization and aristocracy, since that's confusing.
      #(store_mul, ":centralization", ":centralization", -1),
      #(store_mul, ":aristocracy", ":aristocracy", 1),
      #(store_add, ":relation_change", ":centralization", ":aristocracy"),

		(store_sub, ":relation_change", ":aristocracy", ":centralization"),
      ##custodian (merchant) lords like plutocracy, unlike ordinary lords
      (store_mul, ":custodian_change", ":aristocracy", -1),
		(val_sub, ":custodian_change", ":centralization"),
      #benefactor lords like freedom and dislike serfdom
		(store_mul, ":benefactor_change", ":serfdom", -1),
		(val_sub, ":custodian_change", ":centralization"),
      ##nested diplomacy end+
      (try_begin),
        ##nested diplomacy start+
        (this_or_next|neq, ":benefactor_change", 0),
        (this_or_next|neq, ":custodian_change", 0),
        ##nested diplomacy end+
        (neq, ":relation_change", 0),

        (try_begin),
          (eq, "$cheat_mode", 1),
          (str_store_faction_name, s9, ":faction"),
          (assign, reg1, ":relation_change"),
          (display_message, "@{!}DEBUG - relation_change =  {reg1} for {s9}"),
        (try_end),

        ##diplomacy start+ also include faction ladies who are faction heroes
        #(try_for_range, ":troop_no", active_npcs_begin, active_npcs_end),
        (try_for_range, ":troop_no", heroes_begin, heroes_end),
        ##diplomacy end+
          (troop_slot_eq, ":troop_no", slot_troop_occupation, slto_kingdom_hero),
          (store_troop_faction, ":faction_no", ":troop_no"),
          (eq, ":faction", ":faction_no"),
          (faction_get_slot, ":faction_leader", ":faction", slot_faction_leader),
          ##diplomacy start+
          (neq, ":troop_no", ":faction_leader"),
          (assign, ":change_for_troop", ":relation_change"),
          (try_begin),
             (troop_slot_eq, ":troop_no", slot_lord_reputation_type, lrep_custodian),
             (assign, ":change_for_troop", ":custodian_change"),
          (else_try),
             (troop_slot_eq, ":troop_no", slot_lord_reputation_type, lrep_benefactor),
             (assign, ":change_for_troop", ":benefactor_change"),
          (try_end),
          ##Extra penalty for going back on a promise, extra bonus for keeping it
          (assign, ":promise_mod", 0),
          (try_begin),
             ##Following are only relevant for companions
				 (is_between, ":troop_no", companions_begin, companions_end),
             (troop_slot_eq, ":troop_no", slot_troop_kingsupport_state, 1),
             (try_begin),
                #Argument: Lords
                (troop_slot_eq, ":troop_no", slot_troop_kingsupport_argument, argument_lords),
                (try_begin),
                  #If more than slightly centralized, or more than slightly balanced against aristocrats
                  (this_or_next|neg|faction_slot_ge, ":faction_no", dplmc_slot_faction_aristocracy, -1),
                     (faction_slot_ge, ":faction_no", dplmc_slot_faction_centralization, 2),
                  (val_sub, ":promise_mod", 1),
                (else_try),
                  #If more than slightly decentralized or more than slightly balanced in favor of aristocrats
                  (this_or_next|faction_slot_ge, ":faction_no", dplmc_slot_faction_aristocracy, 2),
                  (neg|faction_slot_ge, ":faction_no", dplmc_slot_faction_centralization, -2),
                  (faction_slot_ge, ":faction_no", dplmc_slot_faction_aristocracy, -1),#redundant
                  (val_add, ":promise_mod", 1),
                (try_end),
             (else_try),
                  #Argument: Commons
                  (troop_slot_eq, ":troop_no", slot_troop_kingsupport_argument, argument_commons),
                  (try_begin),
                    (faction_slot_ge, ":faction_no", dplmc_slot_faction_serfdom, 2),
                    (val_sub, ":promise_mod", 1),
                  (else_try),
                    (neg|faction_slot_ge, ":faction_no", dplmc_slot_faction_serfdom, 0),
                    (store_add, ":local_temp", ":serfdom", ":aristocracy"),
                    (lt, ":local_temp", 0),
                    (val_add, ":promise_mod", 1),
                  (try_end),
             (try_end),
         (try_end),
         #Check other broken promises
         (try_begin),
             (troop_slot_eq, ":troop_no", slot_lord_recruitment_argument, argument_lords),
             (this_or_next|neg|faction_slot_ge, ":faction_no", dplmc_slot_faction_aristocracy, -1),
                (faction_slot_ge, ":faction_no", dplmc_slot_faction_centralization, 2),
             #Lord must actually have cared about argument
             (neg|troop_slot_eq, ":troop_no", slot_lord_reputation_type, lrep_debauched),
             (neg|troop_slot_eq, ":troop_no", slot_lord_reputation_type, lrep_upstanding),
             (val_sub, ":promise_mod", 1),
         (else_try),
             (troop_slot_eq, ":troop_no", slot_lord_recruitment_argument, argument_commons),
             (faction_slot_ge, ":faction_no", dplmc_slot_faction_serfdom, 2),
             #Lord must actually have cared about argument
             (neg|troop_slot_eq, ":troop_no", slot_lord_reputation_type, lrep_quarrelsome),
             (neg|troop_slot_eq, ":troop_no", slot_lord_reputation_type, lrep_selfrighteous),
             (neg|troop_slot_eq, ":troop_no", slot_lord_reputation_type, lrep_debauched),
             (val_sub, ":promise_mod", 1),
         (try_end),
         (val_clamp, ":promise_mod", -1, 2),#-1, 0, or 1
         (val_add, ":change_for_troop", ":promise_mod"),

		 (neq, ":change_for_troop", 0),
		 (call_script, "script_change_player_relation_with_troop", ":troop_no", ":change_for_troop"),
        ##diplomacy end+
		  (try_begin),
			(ge,":change_for_troop", 1),
			(faction_slot_ge, ":faction_no", dplmc_slot_faction_aristocracy, 2),
			(store_mul, ":gold_change", ":change_for_troop", 100),
			(troop_get_slot, ":wealth", ":troop_no", slot_troop_wealth),
			(val_add, ":wealth", ":gold_change"),
			(troop_set_slot, ":troop_no", slot_troop_wealth, ":wealth"),
			(troop_add_gold, ":troop_no", ":gold_change"),	#if aristocratic add some gold, so landless lords can still hire a few troops
          (try_end),
        (try_end),
      (try_end),
    (try_end),
  (try_end),
  ]),

# affilated family ai
(24 * 7,
   [
	##nested diplomacy start+ (piggyback on this trigger) allow lords to return from exile
	(assign, ":save_reg0", reg0),
	(assign, ":save_reg1", reg1),
	(assign, ":save_reg4", reg4),
	(try_begin),
		#only proceed if setting is enabled
		(ge, "$g_dplmc_lord_recycling", DPLMC_LORD_RECYCLING_ENABLE),
		#Warlords/pretenders do not return in this manner (it should be different if it does happen).
		#Companions have a separate mechanism for return.
		(assign, ":chosen_lord", -1),
		(assign, ":best_score", -101),
		(assign, ":num_exiles", 0),
		#iterate over lords from a random start point, wrapping back to zero
		(store_random_in_range, ":rand_no", lords_begin, lords_end),
        (val_sub, ":rand_no", lords_begin), #overflow fix
		(try_for_range, ":index", lords_begin, lords_end),
		  (store_add, ":troop_no", ":rand_no", ":index"),
		  (try_begin),
			 #wrap back around when you go off the end
			(ge, ":troop_no", lords_end),
			(val_sub, ":troop_no", lords_end),
			(val_add, ":troop_no", lords_begin),
		  (try_end),
		  #Elsewhere we do the bookkeeping of ensuring that when a lord gets exiled
		  #his occupation changes to dplmc_slto_exile, and when loading a Native
		  #saved gamed with diplomacy we make this change for any lords required.
		  (troop_slot_eq, ":troop_no", slot_troop_occupation, dplmc_slto_exile),

		  (store_troop_faction, ":faction_no", ":troop_no"),
		  (this_or_next|eq, ":faction_no", -1),
		  (this_or_next|eq, ":faction_no", "fac_commoners"),
			 (eq, ":faction_no", "fac_outlaws"),
		  (val_add, ":num_exiles", 1),
		  (try_begin),
		     #Pick the lord with the best relation with his original liege.
			  #In most cases this will be the lord that has been in exile
			  #the longest.
			  (troop_get_slot, ":new_faction", ":troop_no", slot_troop_original_faction),
			  (is_between, ":new_faction", kingdoms_begin, kingdoms_end),
			  (faction_get_slot, ":faction_leader", ":new_faction", slot_faction_leader),
			  (gt, ":faction_leader", 0),
			  (call_script, "script_troop_get_relation_with_troop", ":troop_no", ":faction_leader"),
			  (this_or_next|eq, ":chosen_lord", -1),
			     (gt, reg0, ":best_score"),
			  (assign, ":chosen_lord", ":troop_no"),
			  (assign, ":best_score", reg0),
		  (else_try),
		     (eq, ":chosen_lord", -1),
			 (assign, ":chosen_lord", ":troop_no"),
		  (try_end),
		(try_end),
		#search is done
		(try_begin),
		 #no lord found
		 (eq, ":chosen_lord", -1),
		 (try_begin),
			(ge, "$cheat_mode", 1),
			(display_message, "@{!}DEBUG - no eligible lords in exile"),
		 (try_end),
	    (else_try),
			#If there were fewer than 3 lords in exile, random chance that none will return.
			(lt, ":num_exiles", 3),
			(store_random_in_range, ":random", 0, 256),
			(ge, ":random", 128),
			(try_begin),
				(ge, "$cheat_mode", 1),
				(assign, reg0, ":num_exiles"),
				(display_message, "@{!}DEBUG - {reg0} lords found in exile; randomly decided not to try to return anyone."),
			(try_end),
		(else_try),
		 #found a lord
		 (neq, ":chosen_lord", -1),
		 (try_begin),
			(ge, "$cheat_mode", 1),
			(str_store_troop_name, s4, ":chosen_lord"),
			(assign, reg0, ":best_score"),
			(assign, reg1, ":num_exiles"),
			(display_message, "@{!}DEBUG - {reg1} lords found in exile; {s4} chosen to return, score was {reg0}"),
		 (try_end),
		 #To decrease the displeasing fragmentation of lord cultures, bias towards assigning
		 #the lord back to his original faction if possible.
		 (troop_get_slot, ":new_faction", ":chosen_lord", slot_troop_original_faction),
		 (try_begin),
			 #If the original faction is not active, or the lord's relation is too low, use a different faction
			 (this_or_next|lt, ":best_score", -50),
			 (this_or_next|neg|is_between, ":new_faction", kingdoms_begin, kingdoms_end),
			    (neg|faction_slot_eq, ":new_faction", slot_faction_state, sfs_active),
		    (call_script, "script_lord_find_alternative_faction", ":chosen_lord"),
			(assign, ":new_faction", reg0),
		 (try_end),
		 (try_begin),
		   (neg|is_between, ":new_faction", kingdoms_begin, kingdoms_end),
			(ge, "$cheat_mode", 1),
			(str_store_troop_name, s4, ":chosen_lord"),
			(display_message, "@{!}DEBUG - {s4} found no faction to return to!"),
		 (try_end),
		 (is_between, ":new_faction", kingdoms_begin, kingdoms_end),
		 (assign, ":num_inactive", 0),
		 (try_begin),
			(eq, ":new_faction", "$players_kingdom"),
			(call_script, "script_dplmc_get_troop_standing_in_faction", "trp_player", "$players_kingdom"),
			(ge, reg0, DPLMC_FACTION_STANDING_LEADER_SPOUSE),
			(assign, ":num_inactive", 0),
			(try_for_range, ":other_lord", lords_begin, lords_end),
			   (store_troop_faction, ":other_lord_faction", ":other_lord"),
			   (this_or_next|eq, ":other_lord_faction", "fac_player_supporters_faction"),
				(eq, ":other_lord_faction", "$players_kingdom"),
			   (troop_slot_eq, ":other_lord", slot_troop_occupation, slto_inactive),
			   (val_add, ":num_inactive", 1),
			(try_end),
			(gt, ":num_inactive", 1),
			(try_begin),
				(ge, "$cheat_mode", 1),
				(assign, reg0, ":num_inactive"),
				(display_message, "@{!}DEBUG - Not returning a lord to the player's faction, since there are already {reg0} lords waiting for their petitions to be heard."),
			(try_end),
		 (else_try),
			(call_script, "script_dplmc_lord_return_from_exile", ":chosen_lord", ":new_faction"),
		 (try_end),
		(try_end),
	(try_end),
	##More piggybacking
	##
	(assign, reg0, ":save_reg0"),
	(assign, reg1, ":save_reg1"),
	(assign, reg4, ":save_reg4"),
	##nested diplomacy end+
    (is_between, "$g_player_affiliated_troop", lords_begin, kingdom_ladies_end),
	##nested diplomacy start+
	(assign, ":best_relation", -101),
	(assign, ":worst_relation", 101),

	(assign, ":num_at_least_20", 0),
	(assign, ":num_below_0", 0),

	(assign, ":good_relation", 0),
	##nested diplomacy end+

    (assign, ":bad_relation", 0),
    (try_for_range, ":family_member", lords_begin, kingdom_ladies_end),
      (call_script, "script_dplmc_is_affiliated_family_member", ":family_member"),
      (gt, reg0, 0),
      (call_script, "script_troop_get_player_relation", ":family_member"),
	  ##nested diplomacy start+
	  #(le, reg0, -20),
	  #(assign, ":bad_relation", ":family_member"),
  	  (try_begin),
		(lt, reg0, 0),
		(val_add, ":num_below_0", 1),
		(le, reg0, ":worst_relation"),
		(assign, ":bad_relation", ":family_member"),
	  (else_try),
		(ge, reg0, 20),
		(val_add, ":num_at_least_20", 1),
		(gt, reg0, ":best_relation"),
		(assign, ":good_relation", ":family_member"),
	  (try_end),

	  (val_max, ":best_relation", reg0),
	  (val_min, ":worst_relation", reg0),
	  ##nested diplomacy end+
    (try_end),
	##nested diplomacy start+
	(try_begin),
		(gt, ":worst_relation", -15),
		(assign, ":bad_relation", 0),#suppress with no message
	(else_try),
		(gt, ":worst_relation", -20),
		(str_store_troop_name_link, s0, ":bad_relation"),  #SB : link message, no colours
		(display_message, "@{s0} is grumbling against you.  Your affiliation could be jeopardized if this continues."),
		(str_clear, s0),
	(else_try),
		(neq, ":bad_relation", 0),
		(ge, ":num_at_least_20", ":num_below_0"),
		(store_add, reg0, ":worst_relation", ":best_relation"),
		(ge, reg0, 0),
		(str_store_troop_name_link, s0, ":bad_relation"),
		(str_store_troop_name_link, s1, ":good_relation"),  #SB : link message
		(display_message, "@{s0} is grumbling against you, but with {s1}'s support you remain affiliated for now."),
		(str_clear, s0),
		(str_clear, s1),
		(assign, ":bad_relation", 0),
	(try_end),
	##nested diplomacy end+
    (try_begin),
      (eq, ":bad_relation", 0),

      (try_for_range, ":family_member", lords_begin, kingdom_ladies_end),
        (call_script, "script_dplmc_is_affiliated_family_member", ":family_member"),
        (gt, reg0, 0),
        (try_begin),
           (troop_slot_ge, ":family_member", slot_troop_prisoner_of_party, 0),
           ##diplomacy start+ skip relationship decay for imprisonment when the player himself is imprisoned or wounded
           (neg|troop_slot_ge, "trp_player", slot_troop_prisoner_of_party, 1),
           (neg|troop_is_wounded, "trp_player"),
           ##diplomacy end+
           (call_script, "script_change_player_relation_with_troop", ":family_member", -1),
        (else_try),
          (call_script, "script_change_player_relation_with_troop", ":family_member", 1),
        (try_end),
      (try_end),
    (else_try),
      (call_script, "script_add_notification_menu", "mnu_dplmc_affiliate_end", ":bad_relation", 0),
      (call_script, "script_dplmc_affiliate_end", 1),
    (try_end),
    ##nested diplomacy start+
    (assign, reg0, ":save_reg0"),
    (assign, reg1, ":save_reg1"),
    (assign, reg4, ":save_reg4"),
    ##nested diplomacy end+
    ]),

(2,
   [
    (assign, ":has_walled_center", 0),
    (assign, ":has_fief", 0),
    (try_for_range, ":center_no", centers_begin, centers_end),
      (party_get_slot,  ":lord_troop_id", ":center_no", slot_town_lord),
      (eq, ":lord_troop_id", "trp_player"),
      (try_begin),
        (is_between, ":center_no", walled_centers_begin, walled_centers_end),
        (assign, ":has_walled_center", 1),
      (try_end),
      (assign, ":has_fief", 1),
    (try_end),

    (try_begin),
      (eq, ":has_walled_center", 0),
      (this_or_next|neq, "$g_player_constable", 0),
      (neq, "$g_player_chancellor", 0),
      (assign, "$g_player_constable", 0),
      (assign, "$g_player_chancellor", 0),
    (try_end),

    (try_begin),
      (eq, ":has_fief", 0),
      (neq, "$g_player_chamberlain", 0),
      (assign, "$g_player_chamberlain", 0),

      ##nested diplomacy start+
      #Adjust gold loss by difficulty
      (assign, ":save_reg0", reg0),
      (assign, ":save_reg1", reg1),

      (assign, ":loss_numerator", 2),
      (assign, ":loss_denominator", 3),

      (game_get_reduce_campaign_ai, ":reduce_campaign_ai"),
      (try_begin),
        (eq, ":reduce_campaign_ai", 0), #hard, lose 5/6
        (assign, ":loss_numerator", 5),
        (assign, ":loss_denominator", 6),
      (else_try),
        (eq, ":reduce_campaign_ai", 1), #medium, lose 2/3
        (assign, ":loss_numerator", 2),
        (assign, ":loss_denominator", 3),
      (else_try),
        (eq, ":reduce_campaign_ai", 2), #easy, lose 1/2
        (assign, ":loss_numerator", 1),
        (assign, ":loss_denominator", 2),
      (try_end),

      (store_troop_gold, ":cur_gold", "trp_household_possessions"),
      (try_begin),
        (gt, ":cur_gold", 0),
        #(call_script, "script_dplmc_withdraw_from_treasury", ":cur_gold"),
        #(val_div, ":cur_gold", 3),
        #(call_script, "script_troop_add_gold", "trp_player", ":cur_gold"),
        #(display_message, "@Your last fief was captured and you lost 2/3 of your treasury"),
        (store_mul, ":lost_gold", ":cur_gold", ":loss_numerator"),
        (val_div, ":lost_gold", ":loss_denominator"),
        (val_mul, ":lost_gold", -1),
        (call_script, "script_dplmc_withdraw_from_treasury", ":lost_gold"),
        (assign, reg0, ":loss_numerator"),
        (assign, reg1, ":loss_denominator"),
        #SB : colorize
        (display_message, "@Your last fief was captured and you lost {reg0}/{reg1} of your treasury", message_negative),
      (try_end),

      (assign, reg0, ":save_reg0"),
      (assign, reg1, ":save_reg1"),
      ##nested diplomacy end+
    (try_end),
    ]),

 (24,
   [
      (try_for_range, ":faction1", npc_kingdoms_begin, npc_kingdoms_end),
        (assign, ":attitude_change", 2), #positive means good attitude
        (try_for_range, ":faction2", kingdoms_begin, kingdoms_end),
          (neq, ":faction1", ":faction2"),
		  ##diplomacy start+
		  #FIX: Stop the attitude change from carrying over from the previous faction!
		  (assign, ":attitude_change", 2),
		  #Handling for fac_player_supporters_faction & players_kingdom
		  (assign, ":alt_faction", ":faction2"),
		  (try_begin),
		     (eq, ":faction2", "fac_player_supporters_faction"),
			 (neq, ":faction1", "$players_kingdom"),
			 (assign, ":alt_faction", "$players_kingdom"),
		  (else_try),
		     (eq, ":faction2", "$players_kingdom"),
			 (assign, ":alt_faction", "fac_player_supporters_faction"),
		  (try_end),
		  ##Make loop less wasteful.
		  ##OLD:
          #(try_for_parties, ":party"),
          #  (is_between, ":party", centers_begin, centers_end),
		  ##NEW:
		  (try_for_range, ":party", centers_begin, centers_end),
		  ##diplomacy end+
            (store_faction_of_party, ":party_faction", ":party"),
			##diplomacy start+
			##FIX broken slot check!
			##ADD support for player's faction
			##OLD:
            #(eq, ":party_faction", ":faction2"),
            #(party_slot_eq, ":faction1", ":party", slot_center_original_faction),
			##NEW:
			(this_or_next|eq, ":party_faction", ":faction2"),
				(eq, ":party_faction", ":alt_faction"),
			(party_slot_eq, ":party", slot_center_original_faction, ":faction1"),
			#Don't subtract relation when it would be nonsensical
			(this_or_next|neq, ":faction1", "$players_kingdom"),
			(this_or_next|neq, ":faction2", "fac_player_supporters_faction"),
				(party_slot_ge, ":party", dplmc_slot_center_original_lord, 1),
			##diplomacy end+
            (val_sub, ":attitude_change", 1), #less attitude
          (try_end),

          (try_for_range, ":faction3", kingdoms_begin, kingdoms_end),
            (call_script, "script_diplomacy_faction_get_diplomatic_status_with_faction", ":faction2", ":faction3"),
            (eq, reg0, -2), #war between 2 and 3
            (call_script, "script_diplomacy_faction_get_diplomatic_status_with_faction", ":faction1", ":faction3"),
            (eq, reg0, -2), #war between 1 and 3
            (val_add, ":attitude_change", 1), #higher attitude
          (try_end),
        (try_end),

        (store_add, ":faction1_to_faction2_slot", ":faction2", dplmc_slot_faction_attitude_begin),
        (party_set_slot, ":faction1", ":faction1_to_faction2_slot", ":attitude_change"),
      (try_end),
    ]),

  ##diplomacy end

 # (2.5,
   # [
      # (try_for_parties, reg0),
          # # (this_or_next|party_slot_eq, reg0, slot_party_type, spt_village_farmer ),
          # (party_slot_eq, reg0, slot_party_type, spt_kingdom_caravan),

          # (neg|party_is_in_any_town, reg0),

          # # (party_get_current_terrain, ":cur_terrain", reg0),

          # (assign,reg5,0),#":found"

          # (try_for_range, ":map", centers_begin, centers_end),
              # (store_distance_to_party_from_party, ":dist", reg0, ":map"),
              # (ge,":dist", 5),
              # (le,":dist", 25),
              # (val_add,reg5,1),
              # (str_store_party_name, s1, ":map"),
          # (try_end),
          # (ge,reg5,4),

          # (party_get_position, pos1, reg0),
          # (position_get_x, reg1, pos1),
          # (position_get_y, reg2, pos1),
          # (position_get_z, reg3, pos1),
          # (position_get_rotation_around_z, reg4, pos1),

          # (try_begin),
            # (ge, reg5, 5),

            # (display_message, "@#{reg5} ({reg3}z)_(d_city_{reg0},d_city_{reg0},icon_map_dest_city|pf_is_static|pf_always_visible|pf_no_label,no_menu,pt_none,fac_neutral,0,ai_bhvr_hold,0,({reg1},{reg2}),[],{reg4}),"),
          # # (display_message, "@caravan {reg0} is ({reg1},{reg2}),[],{reg4}), near {s1}, near {reg5}"),
          # (else_try),
            # (display_message, "@#{reg5} ({reg3}z)_(old_city_{reg0},old_city_{reg0},icon_map_city_1|pf_is_static|pf_always_visible|pf_no_label,no_menu,pt_none,fac_neutral,0,ai_bhvr_hold,0,({reg1},{reg2}),[],{reg4}),"),
          # (try_end),
      # (try_end),

      # (try_for_parties, reg0),
          # (party_slot_eq, reg0, slot_party_type, spt_kingdom_caravan),

          # (neg|party_is_in_any_town, reg0),

          # (party_get_position, pos1, reg0),

          # (position_get_x, reg1, pos1),
          # (position_get_y, reg2, pos1),
          # (position_get_z, reg3, pos1),
          # (position_get_rotation_around_z, reg4, pos1),

          # (try_begin),
            # (assign,reg5,0),#":found"

            # (try_for_range, ":map", centers_begin, centers_end),
                # (eq,reg5,0),
                # (store_distance_to_party_from_party, ":dist", reg0, ":map"),
                # (le,":dist", 3),
                # (val_add,reg5,1),
                # (str_store_party_name, s1, ":map"),
            # (try_end),
            # (ge,reg5,1),

            # # (party_get_position, pos1, reg0),
            # # (position_get_x, reg1, pos1),
            # # (position_get_y, reg2, pos1),
            # # (position_get_z, reg3, pos1),
            # # (position_get_rotation_around_z, reg4, pos1),

            # (display_message, "@#{s1} ({reg3}z)_(road_{reg0},road_{reg0},icon_map_road_1|pf_is_static|pf_always_visible|pf_no_label,no_menu,pt_none,fac_neutral,0,ai_bhvr_hold,0,({reg1},{reg2}),[],{reg4}),"),
            # # (display_message, "@caravan {reg0} is ({reg1},{reg2}),[],{reg4}), near {s1}, near {reg5}"),
        # (else_try),
          # (party_get_current_terrain, ":cur_terrain", reg0),
          # (this_or_next|eq, ":cur_terrain", rt_water),
          # (this_or_next|eq, ":cur_terrain", rt_bridge),
          # (eq, ":cur_terrain", rt_river),
          # (display_message, "@#on water ({reg3}z)_(road_b_{reg0},road_b_{reg0},icon_bridge_a|pf_is_static|pf_always_visible|pf_no_label,no_menu,pt_none,fac_neutral,0,ai_bhvr_hold,0,({reg1},{reg2}),[],{reg4}),"),

        # (try_end),
      # (try_end),
   # ]),

(24*28,	#choppers
   [
    (try_for_range, ":town", towns_begin, towns_end),
		(party_get_slot, ":town_lord", ":town", slot_town_lord),
		(store_faction_of_party, ":town_faction", ":town"),
		(assign, ":continue", 0),
		(try_begin),
			(is_between, ":town_lord", kings_begin, kings_end),
			(assign, ":continue", 1),
		  (else_try),
			(eq, ":town_lord", "trp_player"),
			(this_or_next|eq, ":town_faction", "fac_player_supporters_faction"),
			(eq, ":town_faction", "fac_player_faction"),
			(assign, ":continue", 1),
		(try_end),
		(eq, ":continue", 1),
		(troop_get_slot, ":troop_party_no", ":town_lord", slot_troop_leaded_party),
		(ge, ":troop_party_no", 0),
		(party_is_active, ":troop_party_no"),
		
		(try_begin),
			# (eq, ":town_faction", "fac_kingdom_1"),
			# (assign, ":mechanic_troop", "trp_"),
		  # (else_try),
			# (eq, ":town_faction", "fac_kingdom_2"),
			# (assign, ":mechanic_troop", "trp_"),
		  # (else_try),
			#(eq, ":town_faction", "fac_"),
			(assign, ":mechanic_troop", "trp_chopper_mechanic"),
		(try_end),
		
		(try_begin),
			(eq, ":town_lord", "trp_player"),
			(party_count_members_of_type, ":mechanics", ":troop_party_no", ":mechanic_troop"),
			(le, ":mechanics", 0),
			(party_count_members_of_type, ":mechanics", ":town", ":mechanic_troop"),
			(le, ":mechanics", 0),
			(party_force_add_members, ":town", ":mechanic_troop", 1),
		  (else_try),	
			(neq, ":town_lord", "trp_player"),
			(party_count_members_of_type, ":mechanics", ":troop_party_no", ":mechanic_troop"),
			(le, ":mechanics", 0),
			(party_force_add_members, ":troop_party_no", ":mechanic_troop", 1),
		(try_end),
    (try_end),
]),
   
(24*14,	#cars
   [
    (try_for_range, ":town", towns_begin, towns_end),
		(party_get_slot, ":town_lord", ":town", slot_town_lord),
		(store_faction_of_party, ":town_faction", ":town"),
		# (assign, ":continue", 0),
		# (try_begin),
			# (is_between, ":town_lord", kings_begin, kings_end),
			# (assign, ":continue", 1),
		  # (else_try),
			# (eq, ":town_lord", "trp_player"),
			# (this_or_next|eq, ":town_faction", "fac_player_supporters_faction"),
			# (eq, ":town_faction", "fac_player_faction"),
			# (assign, ":continue", 1),
		# (try_end),
		# (eq, ":continue", 1),
		(ge, ":town_lord", 0),
		(troop_get_slot, ":troop_party_no", ":town_lord", slot_troop_leaded_party),
		(ge, ":troop_party_no", 0),
		(party_is_active, ":troop_party_no"),
		
		(try_begin),
			(eq, ":town_faction", "fac_kingdom_1"),
			(assign, ":mechanic_troop", "trp_f1_car_mechanic"),
		  (else_try),
			(eq, ":town_faction", "fac_kingdom_2"),
			(assign, ":mechanic_troop", "trp_f2_car_mechanic"),
		  (else_try),
			#(eq, ":town_faction", "fac_"),
			(assign, ":mechanic_troop", "trp_car_mechanic"),
		(try_end),
		
		(try_begin),
			(eq, ":town_lord", "trp_player"),
			(party_count_members_of_type, ":mechanics", ":troop_party_no", ":mechanic_troop"),
			(le, ":mechanics", 3),
			(party_count_members_of_type, ":mechanics", ":town", ":mechanic_troop"),
			(le, ":mechanics", 3),
			(party_force_add_members, ":town", ":mechanic_troop", 1),
		  (else_try),	
			(neq, ":town_lord", "trp_player"),
			(party_count_members_of_type, ":mechanics", ":troop_party_no", ":mechanic_troop"),
			(le, ":mechanics", 3),
			(party_force_add_members, ":troop_party_no", ":mechanic_troop", 1),
		(try_end),
    (try_end),
	(party_set_slot, "p_arena_1", slot_town_has_tournament, 1),
]),

(3,
   [
# convert ghouls/infected
(try_for_parties, ":party_no"),
  (gt, ":party_no", "p_spawn_points_end"),
  (party_is_active, ":party_no"),
  (party_get_template_id, ":party_template", ":party_no"),
  (try_begin),
	(this_or_next|eq, ":party_template", "pt_infected"),
	(this_or_next|eq, ":party_template", "pt_infected_scavengers"),
	(this_or_next|eq, ":party_template", "pt_infected_soldiers"),
	(this_or_next|eq, ":party_template", "pt_ghouls"),
	(eq, ":party_template", "pt_ghouls_army"),
	(try_begin),
	  (this_or_next|eq, ":party_template", "pt_infected"),
	  (this_or_next|eq, ":party_template", "pt_infected_scavengers"),
	  (eq, ":party_template", "pt_infected_soldiers"),
	  (assign, ":replace_troop", "trp_infected_3"),
	 (else_try), 
	  (this_or_next|eq, ":party_template", "pt_ghouls"),
	  (eq, ":party_template", "pt_ghouls_army"),
	  (assign, ":replace_troop", "trp_ghoul_scavenger"),
	(try_end),
	(try_begin), #weed out undesirables
	  (party_get_num_companion_stacks, ":num_stacks", ":party_no"),
	  (try_for_range_backwards, ":stack_no", 0, ":num_stacks"),
		(party_stack_get_troop_id, ":troop_no", ":party_no", ":stack_no"),
		(neg|is_between, ":troop_no", infested_mut_begin, infested_end),
		
		(party_stack_get_size, ":stack_size", ":party_no", ":stack_no"),
		(party_remove_members, ":party_no", ":troop_no", ":stack_size"),
		(party_add_members, ":party_no", ":replace_troop", ":stack_size"),
		#(str_store_troop_name_by_count, s45, ":troop_no"),
		#(str_store_troop_name_by_count, s46, ":replace_troop"),
		#(display_message, "@{s45} changed tp {s46}", message_positive),
	  (try_end),
	(try_end),
  (try_end),
(try_end),

]),   

(84,
   [
# ghouls/infected attack
#(display_message, "@ghouls/infected attack"),
#(assign,":continue",1),
#(try_for_range, ":party_no", towns_begin, towns_end),#why did I do this?!
	(store_random_in_range, ":party_no", towns_begin, towns_end),
	#(eq,":continue",1),
	#(is_between, ":party_no", towns_begin, towns_end),
	(party_slot_eq, ":party_no", slot_center_is_besieged_by, -1),
	(store_faction_of_party, ":party_faction", ":party_no"),
	(neq, ":party_faction", "fac_infected"),
	(neq, ":party_faction", "fac_mutants"),
	(faction_get_slot, ":num_towns", ":party_faction", slot_faction_num_towns),
	
	#(assign, reg5, ":num_towns"),	#don't end factions this way
	#(display_message, "@num towns is {reg5}!", message_negative),
	(gt, ":num_towns", 1),	#don't end factions this way
	
	
	
	(store_random_in_range, ":rand", 0, 50),#was 750 with cycle
	#(assign, reg30, ":rand"),
	(val_sub, ":rand", ":num_towns"),
	#(assign, reg31, ":rand"),
	#(display_message, "@ghoul chance {reg30} - {reg31}"),
	(le, ":rand", 0),
	#(assign,":continue",0),
    
	(set_spawn_radius, 3),
	#(party_get_current_terrain, ":terrain_type", ":party_no"),
    (store_current_day, ":days_passed"),
	(try_begin),
        (gt, ":days_passed", 100),
		(spawn_around_party,":party_no","pt_throd_army"),
		(store_random_in_range, ":no_infected", 100, 850),
		(party_force_add_members, reg0, "trp_throd_tier_0", ":no_infected"),
        (store_random_in_range, ":no_infected", 200, 500),
		(party_force_add_members, reg0, "trp_throd_tier_1", ":no_infected"),
        (store_random_in_range, ":no_infected", 100, 175),
		(party_force_add_members, reg0, "trp_throd_tier_2", ":no_infected"),
        (store_random_in_range, ":no_infected", 80, 150),
		(party_force_add_members, reg0, "trp_throd_tier_3", ":no_infected"),
        (store_random_in_range, ":no_infected", 40, 100),
		(party_force_add_members, reg0, "trp_throd_tier_4", ":no_infected"),
        (store_random_in_range, ":no_infected", 20, 50),
		(party_force_add_members, reg0, "trp_throd_tier_5", ":no_infected"),
        (store_random_in_range, ":no_infected", 5, 15),
		(party_force_add_members, reg0, "trp_throd_rider", ":no_infected"),
		(str_store_string, s6, "@Throd Cultists"),
	  (else_try),
		(spawn_around_party,":party_no","pt_ghouls_army"),
		(store_random_in_range, ":no_infected", 0, 150),
		(party_force_add_members, reg0, "trp_ghoul_scavenger", ":no_infected"),
		(str_store_string, s6, "@Ghouls"),
	(try_end),
	(assign,":ghoul_army",reg0),
	(party_set_slot, ":party_no", slot_center_is_besieged_by, ":ghoul_army"),
	(party_set_ai_behavior, ":ghoul_army", ai_bhvr_attack_party),
	(party_set_ai_object,":ghoul_army",":party_no"),
	(str_store_party_name_link, s5, ":party_no"),
	
	(display_log_message, "@A large group of {s6} is attacking {s5}!", message_negative),
	(try_begin),
		(eq, ":party_faction", "$players_kingdom"),
		(str_store_party_name, s5, ":party_no"),
		(dialog_box, "@A large group of {s6} is attacking {s5}!", "@Abominations attack!"),
		#(store_current_day, reg9),
		#(dialog_box, "@A large group of {s6} is attacking {s5}!^^(Day {reg9})", "@Abominations attack!"),
	(try_end),
#(try_end),

]),   

]# modmerger_start version=201 type=2
try:
    component_name = "simple_triggers"
    var_set = { "simple_triggers" : simple_triggers }
    from modmerger import modmerge
    modmerge(var_set)
except:
    raise
# modmerger_end
